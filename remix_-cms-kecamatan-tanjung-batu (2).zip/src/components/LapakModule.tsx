/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, FormEvent } from "react";
import {
  ShoppingBag,
  Store,
  MessageCircle,
  Tag,
  CheckCircle,
  Clock,
  Plus,
  Compass,
  AlertOctagon,
  X,
  Phone
} from "lucide-react";
import { ProdukLapak, Pelapak, Desa, UserRole } from "../types";

interface LapakModuleProps {
  produk: ProdukLapak[];
  pelapak: Pelapak[];
  villages: Desa[];
  activeRole: UserRole;
  operatorVillageId: string | null;
  selectedVillageId: string | null;
  onSelectVillage: (id: string | null) => void;
  onAddProduk: (newProd: Omit<ProdukLapak, "id">) => void;
  onToggleStock: (prodId: string, status: ProdukLapak["stokStatus"]) => void;
}

export default function LapakModule({
  produk,
  pelapak,
  villages,
  activeRole,
  operatorVillageId,
  selectedVillageId,
  onSelectVillage,
  onAddProduk,
  onToggleStock
}: LapakModuleProps) {
  const [localVillageId, setLocalVillageId] = useState<string>(selectedVillageId || "");
  const [selectedKategori, setSelectedKategori] = useState("");
  const [detailedProduct, setDetailedProduct] = useState<ProdukLapak | null>(produk[0] || null);

  useEffect(() => {
    setLocalVillageId(selectedVillageId || "");
  }, [selectedVillageId]);

  // Form controls
  const [showAddForm, setShowAddForm] = useState(false);
  const [formNama, setFormNama] = useState("");
  const [formKategori, setFormKategori] = useState<ProdukLapak["kategori"]>("Kerajinan");
  const [formPelapakId, setFormPelapakId] = useState(pelapak[0]?.id || "");
  const [formDesaId, setFormDesaId] = useState(villages[0]?.id || "");
  const [formHarga, setFormHarga] = useState("");
  const [formSatuan, setFormSatuan] = useState("Buah");
  const [formDeskripsi, setFormDeskripsi] = useState("");

  const categories = ["Makanan", "Minuman", "Pertanian", "Kerajinan", "Jasa", "Hasil Perikanan", "Hasil Peternakan", "UMKM"];

  const filteredProduk = produk.filter((p) => {
    const matchesVillage = !localVillageId || p.desaId === localVillageId;
    const matchesKategori = !selectedKategori || p.kategori === selectedKategori;
    return matchesVillage && matchesKategori;
  });

  const canEditLapak = (vId: string) => {
    if (activeRole === "Camat/Admin Kecamatan") return true;
    if (activeRole === "Operator Desa" && operatorVillageId === vId) return true;
    return false;
  };

  const getWhatsAppLink = (p: ProdukLapak, merchant: Pelapak) => {
    const textMsg = `Halo ${merchant.namaPelapak}, saya melihat produk unggulan [${p.namaProduk}] di Portal CMS Kecamatan Belitang Mulya. Apakah produk ini masih tersedia untuk pemesanan? Terima kasih.`;
    return `https://wa.me/${merchant.noWhatsApp}?text=${encodeURIComponent(textMsg)}`;
  };

  const handleCreateProduct = (e: FormEvent) => {
    e.preventDefault();
    if (!formNama || !formHarga) return;

    onAddProduk({
      desaId: formDesaId,
      pelapakId: formPelapakId,
      namaProduk: formNama,
      kategori: formKategori,
      harga: parseFloat(formHarga),
      satuanJual: formSatuan,
      stokStatus: "Tersedia",
      fotoUrl: "https://images.unsplash.com/photo-1544816155-12df9643f363?auto=format&fit=crop&q=80&w=400",
      deskripsi: formDeskripsi,
      isUnggulanKecamatan: false
    });

    setFormNama("");
    setFormHarga("");
    setFormDeskripsi("");
    setShowAddForm(false);
  };

  return (
    <div className="space-y-6">
      {/* 7.1 Filter & Header */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm space-y-4">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-slate-900 border-l-2 border-yellow-500 px-2.5 py-0.5">
              7.0 Galeri Lapak & UMKM Desa
            </span>
            <h3 className="text-lg font-bold text-slate-800 mt-1">
              Etalase Produk Unggulan & Katalog Pedagang
            </h3>
            <p className="text-xs text-slate-500">
              Katalog produk rill yang diproduksi dan siap dijual oleh penenun, pemahat kayu, maupun penjual kemplang lokal.
            </p>
          </div>

          <div className="flex gap-2 self-stretch sm:self-auto">
            {activeRole !== "Publik/Pengunjung" && (
              <button
                onClick={() => {
                  if (activeRole === "Operator Desa" && operatorVillageId) {
                    setFormDesaId(operatorVillageId);
                  }
                  setShowAddForm(!showAddForm);
                }}
                className="bg-[#0F172A] hover:bg-[#1E293B] text-white text-xs font-semibold px-4 py-2 rounded-lg transition-all flex items-center gap-1.5 shrink-0 shadow-sm"
              >
                <Plus className="w-4 h-4" /> Tambah Katalog
              </button>
            )}
            <select
              value={localVillageId}
              onChange={(e) => {
                const val = e.target.value;
                setLocalVillageId(val);
                onSelectVillage(val || null);
              }}
              className="text-xs border border-slate-200 rounded-lg py-2 px-3 focus:outline-none cursor-pointer bg-slate-50"
            >
              <option value="">Semua Asal Desa</option>
              {villages.map((v) => (
                <option key={v.id} value={v.id}>
                  {v.nama}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Add Product Form */}
      {showAddForm && (
        <form onSubmit={handleCreateProduct} className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm grid grid-cols-1 md:grid-cols-12 gap-5">
          <div className="md:col-span-12 border-b border-slate-100 pb-3 flex justify-between items-center">
            <h4 className="text-sm font-bold text-slate-800">Daftarkan Produk Baru ke Etalase</h4>
            <button type="button" onClick={() => setShowAddForm(false)} className="text-xs text-slate-400 hover:text-slate-600">Batal</button>
          </div>

          <div className="md:col-span-4">
            <label className="block text-[10px] uppercase font-bold text-slate-500 mb-1">Nama Produk</label>
            <input
              required
              type="text"
              placeholder="Contoh: Beras Organik Belitang"
              value={formNama}
              onChange={(e) => setFormNama(e.target.value)}
              className="w-full text-xs border border-slate-200 rounded-lg p-2.5 focus:outline-none focus:border-yellow-500"
            />
          </div>

          <div className="md:col-span-4">
            <label className="block text-[10px] uppercase font-bold text-slate-500 mb-1">Kategori Lapak</label>
            <select
              value={formKategori}
              onChange={(e) => setFormKategori(e.target.value as ProdukLapak["kategori"])}
              className="w-full text-xs border border-slate-200 rounded-lg p-2.5 focus:outline-none"
            >
              {categories.map((c) => (
                <option key={c} value={c}>{c}</option>
              ))}
            </select>
          </div>

          <div className="md:col-span-4">
            <label className="block text-[10px] uppercase font-bold text-slate-500 mb-1">Hubungkan Nama Pelapak (7.3)</label>
            <select
              value={formPelapakId}
              onChange={(e) => setFormPelapakId(e.target.value)}
              className="w-full text-xs border border-slate-200 rounded-lg p-2.5 focus:outline-none"
            >
              {pelapak.map((pl) => (
                <option key={pl.id} value={pl.id}>{pl.namaPelapak}</option>
              ))}
            </select>
          </div>

          <div className="md:col-span-4">
            <label className="block text-[10px] uppercase font-bold text-slate-500 mb-1">Harga Jual (Rupiah)</label>
            <input
              required
              type="number"
              placeholder="Contoh: 35000"
              value={formHarga}
              onChange={(e) => setFormHarga(e.target.value)}
              className="w-full text-xs border border-slate-200 rounded-lg p-2.5 focus:outline-none"
            />
          </div>

          <div className="md:col-span-4">
            <label className="block text-[10px] uppercase font-bold text-slate-500 mb-1">Satuan Jual</label>
            <input
              type="text"
              placeholder="Contoh: Porsi, Unit, Bungkus, Set"
              value={formSatuan}
              onChange={(e) => setFormSatuan(e.target.value)}
              className="w-full text-xs border border-slate-200 rounded-lg p-2.5 focus:outline-none"
            />
          </div>

          {activeRole !== "Operator Desa" && (
            <div className="md:col-span-4">
              <label className="block text-[10px] uppercase font-bold text-slate-500 mb-1">Asal Desa</label>
              <select
                value={formDesaId}
                onChange={(e) => setFormDesaId(e.target.value)}
                className="w-full text-xs border border-slate-200 p-2 focus:outline-none"
              >
                {villages.map((v) => (
                  <option key={v.id} value={v.id}>{v.nama}</option>
                ))}
              </select>
            </div>
          )}

          <div className="md:col-span-12">
            <label className="block text-[10px] uppercase font-bold text-slate-500 mb-1">Deskripsi & Cara Pemesanan</label>
            <textarea
              placeholder="Tulis bahan baku, warna, motif tenunan, atau lokasi pengerjaan..."
              value={formDeskripsi}
              onChange={(e) => setFormDeskripsi(e.target.value)}
              className="w-full text-xs border border-slate-200 rounded-lg p-2.5 focus:outline-none h-20"
            />
          </div>

          <div className="md:col-span-12 flex justify-end gap-2">
            <button
              type="button"
              onClick={() => setShowAddForm(false)}
              className="px-4 py-2 border border-slate-200 text-xs text-slate-600 rounded-lg hover:bg-slate-50"
            >
              Batal
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-[#0F172A] hover:bg-[#1E293B] text-white rounded-lg text-xs font-black shadow-sm"
            >
              Simpan Katalog UMKM
            </button>
          </div>
        </form>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* 7.4 Katalog Produk Grid Layout */}
        <div className="lg:col-span-7 bg-white rounded-2xl border border-slate-200 p-6 shadow-sm space-y-4">
          <div className="flex justify-between items-center pb-2 border-b border-slate-100">
            <h4 className="text-xs font-bold uppercase text-slate-400 tracking-wider flex items-center gap-1.5 animate-pulse">
              <ShoppingBag className="w-4 h-4 text-amber-600" />
              7.4 Etalase Katalog Produk Lapak Desa
            </h4>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {filteredProduk.length > 0 ? (
              filteredProduk.map((p) => {
                const parentDesa = villages.find((v) => v.id === p.desaId);
                const merchant = pelapak.find((pl) => pl.id === p.pelapakId);
                const isSelected = detailedProduct?.id === p.id;

                return (
                  <div
                    key={p.id}
                    onClick={() => setDetailedProduct(p)}
                    className={`border rounded-xl overflow-hidden cursor-pointer transition-all ${
                      isSelected
                        ? "border-yellow-500 bg-yellow-500/[0.04] shadow-sm ring-1 ring-yellow-500/20"
                        : "border-slate-100 hover:border-yellow-300 hover:bg-slate-50"
                    }`}
                  >
                    <div className="h-32 bg-slate-900 border-b relative">
                      <img
                        referrerPolicy="no-referrer"
                        src={p.fotoUrl}
                        alt={p.namaProduk}
                        className="w-full h-full object-cover opacity-90"
                      />
                      {p.isUnggulanKecamatan && (
                        <span className="absolute top-2 left-2 bg-amber-500 text-white text-[8px] font-black uppercase px-2 py-0.5 rounded shadow">
                          Unggulan Camat
                        </span>
                      )}
                      <span className={`absolute bottom-2 right-2 text-[9px] font-bold px-2 py-0.5 rounded shadow-sm ${
                        p.stokStatus === "Tersedia"
                          ? "bg-slate-900 text-white"
                          : p.stokStatus === "Terbatas"
                          ? "bg-amber-500 text-white"
                          : "bg-rose-500 text-white"
                      }`}>
                        {p.stokStatus}
                      </span>
                    </div>

                    <div className="p-3.5 space-y-2 font-sans">
                      <div>
                        <span className="text-[9px] font-bold uppercase text-slate-400 tracking-tight block">
                          {p.kategori} • {parentDesa?.nama}
                        </span>
                        <h5 className="text-xs font-bold text-slate-800 line-clamp-1 mt-0.5">
                          {p.namaProduk}
                        </h5>
                      </div>

                      <div className="flex justify-between items-center text-xs font-bold text-slate-800">
                        <span className="text-yellow-600 font-black font-mono">
                          Rp {p.harga.toLocaleString("id-ID")}
                        </span>
                        <span className="text-slate-400 text-[10px] font-medium">/{p.satuanJual}</span>
                      </div>
                    </div>
                  </div>
                );
              })
            ) : (
              <p className="col-span-2 text-center py-12 text-slate-400 text-xs text-medium">Etalase kosong untuk filter desa aktif.</p>
            )}
          </div>
        </div>

        {/* 7.5 Rincian Detail Produk & WhatsApp Chat Linkage */}
        <div className="lg:col-span-5">
          {detailedProduct ? (() => {
            const merchant = pelapak.find((p) => p.id === detailedProduct.pelapakId);
            const parentDesa = villages.find((v) => v.id === detailedProduct.desaId);
            const isRestricted = !canEditLapak(detailedProduct.desaId);

            return (
              <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm space-y-4">
                <div className="border-b border-slate-100 pb-3">
                  <span className="text-[9px] uppercase font-mono text-slate-400">7.5 LAPAK DETAIL INSPECTOR</span>
                  <h4 className="text-base font-black text-slate-800 mt-0.5">{detailedProduct.namaProduk}</h4>
                  <p className="text-xs text-slate-500">Asal Produksi: <strong>{parentDesa?.nama}</strong></p>
                </div>

                <div className="grid grid-cols-2 gap-3.5 text-xs">
                  <div className="p-2.5 bg-slate-50 rounded-xl">
                    <span className="text-[9px] text-slate-400 font-bold uppercase">Harga Resmi</span>
                    <strong className="text-slate-900 text-sm block mt-0.5">Rp {detailedProduct.harga.toLocaleString("id-ID")}</strong>
                  </div>
                  <div className="p-2.5 bg-slate-50 rounded-xl">
                    <span className="text-[9px] text-slate-400 font-bold uppercase">Satuan Layanan</span>
                    <strong className="text-slate-800 text-sm block mt-0.5">per {detailedProduct.satuanJual}</strong>
                  </div>
                </div>

                <div className="space-y-1.5">
                  <h6 className="text-xs font-bold text-slate-700">Keterangan Spesifikasi:</h6>
                  <p className="text-xs text-slate-600 leading-relaxed bg-slate-50 p-3 rounded-lg border">
                    {detailedProduct.deskripsi}
                  </p>
                </div>

                {/* 7.3 Data Pelapak */}
                {merchant && (
                  <div className="bg-yellow-50/40 p-4 rounded-xl border border-yellow-200/60 space-y-2">
                    <div className="flex justify-between items-center">
                      <div className="text-[9px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1">
                        <Store className="w-3 h-3 text-amber-600" /> Data Pelapak Terkait (7.3)
                      </div>
                      <span className="text-[10px] text-yellow-800 font-bold">UMKM Terdaftar</span>
                    </div>
                    <div>
                      <h5 className="font-bold text-xs text-slate-800">{merchant.namaPelapak}</h5>
                      <p className="text-[10px] text-slate-600 leading-tight mt-0.5">{merchant.deskripsiUsia}</p>
                      <p className="text-[10px] text-slate-400 mt-1 flex items-center gap-1"><Compass className="w-3 h-3" /> {merchant.alamat}</p>
                    </div>

                    {/* Integrated WhatsApp direct link */}
                    <a
                      href={getWhatsAppLink(detailedProduct, merchant)}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-full mt-2 bg-[#25D366] hover:bg-[#128C7E] text-white py-2 px-3 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 text-center shadow-sm hover:scale-[1.01]"
                    >
                      <Phone className="w-4 h-4 fill-white" />
                      Hubungi Pelapak via WhatsApp (Pesan Otomatis)
                    </a>
                  </div>
                )}

                {/* Status Toggle 7.7 */}
                {!isRestricted ? (
                  <div className="pt-2 border-t border-slate-100 space-y-1.5">
                    <label className="block text-[10px] uppercase font-bold text-slate-400">Atur Ketersediaan Stok (7.7)</label>
                    <div className="flex gap-1.5">
                      {["Tersedia", "Terbatas", "Kosong"].map((st) => (
                        <button
                          key={st}
                          onClick={() => onToggleStock(detailedProduct.id, st as ProdukLapak["stokStatus"])}
                          className={`flex-1 text-center py-1.5 text-[10px] font-bold rounded-lg border transition-all uppercase ${
                            detailedProduct.stokStatus === st
                              ? "bg-[#0F172A] border-[#0F172A] text-white"
                              : "bg-white border-slate-200 text-slate-600 hover:bg-slate-50"
                          }`}
                        >
                          {st}
                        </button>
                      ))}
                    </div>
                  </div>
                ) : (
                  <div className="bg-slate-100 text-[10px] text-slate-500 p-2.5 rounded-lg text-center leading-snug">
                    Anda masuk sebagai {activeRole}. Hanya operator {parentDesa?.nama} yang diizinkan untuk merubah status stok.
                  </div>
                )}
              </div>
            );
          })() : (
            <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm text-center py-16 flex flex-col items-center">
              <Store className="w-10 h-10 text-slate-300 mb-2" />
              <p className="text-xs">Klik salah satu kartu katalog produk di kiri untuk menginspeksi lapak pedagang.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
