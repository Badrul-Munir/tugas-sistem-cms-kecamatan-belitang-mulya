/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from "react";
import {
  Users,
  Briefcase,
  FileText,
  ShoppingBag,
  TrendingUp,
  Award,
  BookOpen,
  CheckCircle,
  Database,
  Grid,
  AlertTriangle,
  ArrowRight,
  MessageSquare
} from "lucide-react";

import {
  Desa,
  MonografiKependudukan,
  MonografiSosialEkonomi,
  SaranaPrasarana,
  Komoditas,
  PerangkatDesa,
  BeritaKegiatan,
  ProdukLapak,
  AsetDesa,
  CatatKecamatan,
  LogAktivitas
} from "../types";
import VillageMap from "./VillageMap";

interface DashboardProps {
  villages: Desa[];
  kependudukan: MonografiKependudukan[];
  sosialEkonomi: MonografiSosialEkonomi[];
  saranaPrasarana: SaranaPrasarana[];
  komoditas: Komoditas[];
  perangkat: PerangkatDesa[];
  berita: BeritaKegiatan[];
  produk: ProdukLapak[];
  aset: AsetDesa[];
  catatanKecamatan: CatatKecamatan[];
  aktivitas: LogAktivitas[];
  selectedVillageId: string | null;
  onSelectVillage: (id: string | null) => void;
  onNavigateToTab: (tabId: string) => void;
}

export default function DashboardModule({
  villages,
  kependudukan,
  sosialEkonomi,
  saranaPrasarana,
  komoditas,
  perangkat,
  berita,
  produk,
  aset,
  catatanKecamatan,
  aktivitas,
  selectedVillageId,
  onSelectVillage,
  onNavigateToTab
}: DashboardProps) {
  // Helper to calculate completeness for a single village
  const calculateCompleteness = (vId: string) => {
    let completedPoints = 0;
    const maxPoints = 7;

    const hasKependudukan = kependudukan.some((k) => k.desaId === vId);
    if (hasKependudukan) completedPoints++;

    const hasSosialEkonomi = sosialEkonomi.some((s) => s.desaId === vId);
    if (hasSosialEkonomi) completedPoints++;

    const hasSaranaPrasarana = saranaPrasarana.some((s) => s.desaId === vId);
    if (hasSaranaPrasarana) completedPoints++;

    const hasKomoditas = komoditas.some((k) => k.desaId === vId);
    if (hasKomoditas) completedPoints++;

    const hasPerangkat = perangkat.some((p) => p.desaId === vId);
    if (hasPerangkat) completedPoints++;

    const hasAset = aset.some((a) => a.desaId === vId);
    if (hasAset) completedPoints++;

    const activeProfile = villages.find((v) => v.id === vId);
    if (activeProfile && activeProfile.statusWeb === "Aktif") {
      completedPoints++;
    }

    const percentage = Math.round((completedPoints / maxPoints) * 100);
    return {
      percentage,
      points: completedPoints,
      max: maxPoints,
      status: percentage >= 85 ? "Lengkap" : percentage >= 50 ? "Perlu Diperbarui" : "Belum Lengkap",
      hasKependudukan,
      hasSosialEkonomi,
      hasSaranaPrasarana,
      hasKomoditas,
      hasPerangkat,
      hasAset
    };
  };

  // Filter lists based on selected village if any
  const filteredVillages = selectedVillageId ? villages.filter((v) => v.id === selectedVillageId) : villages;
  const filteredKependudukan = selectedVillageId ? kependudukan.filter((k) => k.desaId === selectedVillageId) : kependudukan;
  const filteredKomoditas = selectedVillageId ? komoditas.filter((k) => k.desaId === selectedVillageId) : komoditas;
  const filteredPerangkat = selectedVillageId ? perangkat.filter((p) => p.desaId === selectedVillageId) : perangkat;
  const filteredBerita = selectedVillageId ? berita.filter((b) => b.desaId === selectedVillageId) : berita;
  const filteredProduk = selectedVillageId ? produk.filter((p) => p.desaId === selectedVillageId) : produk;
  const filteredAset = selectedVillageId ? aset.filter((a) => a.desaId === selectedVillageId) : aset;

  // Multi-village aggregation
  const totalPenduduk = filteredKependudukan.reduce((sum, k) => sum + k.jumlahPenduduk, 0);
  const totalKK = filteredKependudukan.reduce((sum, k) => sum + k.jumlahKK, 0);
  const totalBerita = filteredBerita.length;
  const totalProduk = filteredProduk.length;
  const totalAsetCount = filteredAset.length;
  const countPerangkat = filteredPerangkat.length;

  return (
    <div className="space-y-6">
      {/* Dynamic Header */}
      <div id="dynamic-header-panel" className="bg-gradient-to-r from-slate-900 to-slate-950 text-white rounded-2xl p-6 shadow-sm border border-slate-950 relative overflow-hidden">
        <div className="absolute top-0 right-0 transform translate-x-12 -translate-y-12 w-64 h-64 bg-yellow-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div>
              <div className="text-[10px] font-mono tracking-widest text-yellow-400 uppercase">
                {selectedVillageId
                  ? `MONITORING DESA: ${villages.find((v) => v.id === selectedVillageId)?.nama}`
                  : "SISTEM CMS KECAMATAN BELITANG MULYA"}
              </div>
              <h2 className="text-2xl font-black font-sans tracking-tight mt-1">
                Kecamatan Belitang Mulya
              </h2>
              <p className="text-xs text-slate-350 mt-1 max-w-xl">
                Kabupaten OKU Timur, Provinsi Sumatera Selatan. Pusat visualisasi potensi pertanian terpadu, perkebunan kelapa sawit rakyat, hortikultura buah unggulan, dan pengembangan UMKM anyaman kreatif.
              </p>
            </div>
            {selectedVillageId && (
              <button
                onClick={() => onSelectVillage(null)}
                className="bg-white/10 hover:bg-white/20 border border-white/20 text-white text-xs px-3 py-1.5 rounded-lg transition-all"
              >
                Tampilkan Semua Desa
              </button>
            )}
          </div>
        </div>
      </div>

      {/* 1.1 Statistik Kecamatan Cards Layout */}
      <div id="statistics-grid" className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
        <div className="bg-white p-4 rounded-xl border border-slate-200/80 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-semibold text-slate-400 uppercase">Total Desa</span>
            <div className="p-1.5 bg-yellow-50 rounded-lg text-amber-600">
              <Grid className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <h4 className="text-2xl font-black text-slate-800 font-mono">
              {selectedVillageId ? 1 : villages.length}
            </h4>
            <p className="text-[10px] text-amber-600 font-medium mt-1">
              {selectedVillageId ? "Filter Aktif" : "Satu Kecamatan"}
            </p>
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200/80 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-semibold text-slate-400 uppercase">Penduduk</span>
            <div className="p-1.5 bg-yellow-50 rounded-lg text-amber-600">
              <Users className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <h4 className="text-2xl font-black text-slate-800 font-mono">
              {totalPenduduk.toLocaleString("id-ID")}
            </h4>
            <p className="text-[10px] text-amber-600 font-medium mt-1">
              Jiwa Terdata
            </p>
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200/80 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-semibold text-slate-400 uppercase">Kepala Keluarga</span>
            <div className="p-1.5 bg-yellow-50 rounded-lg text-amber-600">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <h4 className="text-2xl font-black text-slate-800 font-mono">
              {totalKK.toLocaleString("id-ID")}
            </h4>
            <p className="text-[10px] text-neutral-500 mt-1">KK Terdaftar</p>
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200/80 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-semibold text-slate-400 uppercase">Aparatur Desa</span>
            <div className="p-1.5 bg-yellow-50 rounded-lg text-amber-600">
              <Award className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <h4 className="text-2xl font-black text-slate-800 font-mono">{countPerangkat}</h4>
            <p className="text-[10px] text-neutral-500 mt-1">Perangkat Aktif</p>
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200/80 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-semibold text-slate-400 uppercase">Produk Lapak</span>
            <div className="p-1.5 bg-yellow-50 rounded-lg text-amber-600">
              <ShoppingBag className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <h4 className="text-2xl font-black text-slate-800 font-mono">{totalProduk}</h4>
            <p className="text-[10px] text-amber-650 text-amber-600 font-medium mt-1">Unggulan Ready</p>
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200/80 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-semibold text-slate-400 uppercase">Aset Daerah</span>
            <div className="p-1.5 bg-yellow-50 rounded-lg text-amber-600">
              <Database className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <h4 className="text-2xl font-black text-slate-800 font-mono">{totalAsetCount}</h4>
            <p className="text-[10px] text-neutral-500 mt-1">Logistik Tercatat</p>
          </div>
        </div>
      </div>

      {/* 1.2 Geotagging Map Integration */}
      <VillageMap
        villages={villages}
        selectedVillageId={selectedVillageId}
        onSelectVillage={onSelectVillage}
      />

      <div className="grid grid-cols-1 xl:grid-cols-12 gap-6">
        {/* Left Hand: 1.3 Kelengkapan Data Desa & 1.5 Rekap Komoditas */}
        <div className="xl:col-span-7 space-y-6">
          {/* 1.3 Status Kelengkapan Data */}
          <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm">
            <div className="flex justify-between items-center mb-4">
              <div>
                <span className="text-xs font-bold uppercase tracking-wider text-slate-900 border-l-2 border-yellow-500 px-2.5 py-0.5">
                  1.3 Kelayakan Administrasi
                </span>
                <h3 className="text-lg font-bold text-slate-800 mt-1.5">
                  Status Kelengkapan Data Wajib Desa
                </h3>
              </div>
              <span className="text-xs text-slate-500">Maks 7 Indikator</span>
            </div>

            <div className="space-y-4">
              {villages.map((v) => {
                const info = calculateCompleteness(v.id);
                const isCurrentActive = selectedVillageId === v.id;

                return (
                  <div
                    key={v.id}
                    onClick={() => onSelectVillage(v.id === selectedVillageId ? null : v.id)}
                    className={`border rounded-xl p-3.5 transition-all cursor-pointer ${
                      isCurrentActive
                        ? "border-yellow-500 bg-yellow-500/[0.04] shadow-sm"
                        : "border-slate-100 hover:border-yellow-255 hover:border-yellow-300 hover:bg-slate-50/50"
                    }`}
                  >
                    <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 mb-2">
                      <div>
                        <h4 className="text-xs font-bold text-slate-800 flex items-center gap-2">
                          {v.nama}
                          {info.points === info.max && (
                            <CheckCircle className="w-3.5 h-3.5 text-yellow-500" />
                          )}
                        </h4>
                        <p className="text-[10px] text-slate-400">Kode Web: {v.kodeDesa}</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className={`text-[9px] font-bold uppercase px-2 py-0.5 rounded border ${
                          info.status === "Lengkap"
                            ? "bg-yellow-100 text-yellow-900 border-yellow-250 bg-yellow-50"
                            : info.status === "Perlu Diperbarui"
                            ? "bg-amber-100 text-amber-900 border-amber-200"
                            : "bg-rose-100 text-rose-900 border-rose-250"
                        }`}>
                          {info.status}
                        </span>
                        <span className="text-xs font-mono font-bold text-slate-700">
                          {info.percentage}%
                        </span>
                      </div>
                    </div>

                    {/* Progress Bar */}
                    <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden mb-2">
                      <div
                        className={`h-full rounded-full transition-all duration-500 ${
                          info.percentage === 100
                            ? "bg-yellow-500"
                            : info.percentage >= 50
                            ? "bg-amber-500"
                            : "bg-rose-500"
                        }`}
                        style={{ width: `${info.percentage}%` }}
                      />
                    </div>

                    {/* Miniature Checklist indicators */}
                    <div className="flex flex-wrap gap-x-3 gap-y-1 text-[9px] text-slate-500">
                      <span className={info.hasKependudukan ? "text-[#0F172A] font-bold" : "text-slate-400"}>
                        ● Kependudukan
                      </span>
                      <span className={info.hasSosialEkonomi ? "text-[#0F172A] font-bold" : "text-slate-400"}>
                        ● Sosioekonomi
                      </span>
                      <span className={info.hasSaranaPrasarana ? "text-[#0F172A] font-bold" : "text-slate-400"}>
                        ● Sapras
                      </span>
                      <span className={info.hasKomoditas ? "text-[#0F172A] font-bold" : "text-slate-400"}>
                        ● Komoditas
                      </span>
                      <span className={info.hasPerangkat ? "text-[#0F172A] font-bold" : "text-slate-400"}>
                        ● Aparat
                      </span>
                      <span className={info.hasAset ? "text-[#0F172A] font-bold" : "text-slate-400"}>
                        ● Aset
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* 1.5 Rekap Komoditas Desa */}
          <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm">
            <div className="flex justify-between items-center mb-4">
              <div>
                <span className="text-xs font-bold uppercase tracking-wider text-slate-900 border-l-2 border-yellow-500 px-2.5 py-0.5">
                  1.5 Potensi Kewilayahan
                </span>
                <h3 className="text-lg font-bold text-slate-800 mt-1.5">
                  Rekap Sebaran Komoditas Utama
                </h3>
              </div>
              <button
                onClick={() => onNavigateToTab("komoditas")}
                className="text-amber-600 text-xs font-semibold hover:underline flex items-center gap-1"
              >
                Atur Komoditas <ArrowRight className="w-3 h-3" />
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {filteredKomoditas.length > 0 ? (
                filteredKomoditas.map((k) => {
                  const parentDesa = villages.find((v) => v.id === k.desaId);
                  return (
                    <div key={k.id} className="p-3 bg-slate-50 rounded-xl border border-slate-100 flex gap-3 items-start">
                      <img
                        referrerPolicy="no-referrer"
                        src={k.fotoUrl}
                        alt={k.namaKomoditas}
                        className="w-12 h-12 rounded-lg object-cover shrink-0 border border-slate-200"
                      />
                      <div className="space-y-1">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span className="text-[8px] font-bold text-amber-900 bg-amber-100 px-1.5 py-0.5 rounded border border-amber-200/50">
                            {k.kategori}
                          </span>
                          {k.statusUnggulan && (
                            <span className="text-[8px] font-bold text-yellow-905 bg-yellow-50 border border-yellow-250 text-amber-900 px-1.5 py-0.5 rounded flex items-center gap-0.5">
                              ★ Unggulan
                            </span>
                          )}
                        </div>
                        <h4 className="text-xs font-bold text-slate-800">{k.namaKomoditas}</h4>
                        <p className="text-[10px] text-slate-500 font-medium">Asal: {parentDesa?.nama}</p>
                        <p className="text-[10px] text-slate-400 font-mono">Kapasitas: {k.estimasiProduksiTahunan}</p>
                      </div>
                    </div>
                  );
                })
              ) : (
                <div className="col-span-2 text-center py-6 text-xs text-slate-400">
                  Tidak ada komoditas terdaftar dalam filter desa aktif.
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Right Hand: 1.4 Rekap Aktivitas Desa & Catatan Perbaikan Kecamatan */}
        <div className="xl:col-span-5 space-y-6">
          {/* 1.4 Rekap Aktivitas Desa */}
          <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-900 border-l-2 border-yellow-500 px-2.5 py-0.5">
              1.4 Log Aktivitas
            </span>
            <h3 className="text-lg font-bold text-slate-800 mt-1.5 mb-4">
              Aktivitas Pembaruan Terkini
            </h3>

            <div className="flow-root">
              <ul className="-mb-8">
                {aktivitas.map((act, actIdx) => (
                  <li key={act.id}>
                    <div className="relative pb-8">
                      {actIdx !== aktivitas.length - 1 ? (
                        <span className="absolute top-4 left-4 -ml-px h-full w-0.5 bg-slate-200" aria-hidden="true" />
                      ) : null}
                      <div className="relative flex space-x-3">
                        <div>
                          <span className="h-8 w-8 rounded-full bg-yellow-50 text-amber-600 flex items-center justify-center ring-8 ring-white">
                            <BookOpen className="w-4 h-4" />
                          </span>
                        </div>
                        <div className="flex-1 min-w-0 pt-1.5">
                          <p className="text-xs text-slate-800">
                            <strong>{act.user}</strong> ({act.role}) melakukan <strong>{act.aksi}</strong>
                          </p>
                          <p className="text-[11px] text-slate-500 mt-0.5">{act.detail}</p>
                          <p className="text-[10px] text-slate-400 mt-1 font-mono">{act.timestamp}</p>
                        </div>
                      </div>
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* Kecamatan Directive Actions (2.4 Catatan Kecamatan) */}
          <div className="bg-amber-50/50 rounded-2xl border border-amber-100 p-6 shadow-sm">
            <div className="flex justify-between items-center mb-3">
              <span className="text-xs font-semibold uppercase tracking-wider text-amber-800 bg-amber-100/60 px-2.5 py-1 rounded-full flex items-center gap-1">
                <AlertTriangle className="w-3 h-3" />
                Catatan Kecamatan (CMS Directive)
              </span>
              <span className="text-[10px] font-mono text-amber-700 font-bold">
                {catatanKecamatan.filter((r) => !r.isResolved).length} Tunggu Koreksi
              </span>
            </div>
            <p className="text-xs text-slate-600 mb-4 leading-relaxed">
              Catatan perbaikan atau arahan dari Camat/Admin Kecamatan kepada desa jika terdeteksi data monografi tidak lengkap.
            </p>

            <div className="space-y-3.5">
              {catatanKecamatan.map((c) => {
                const affectedDesaName = villages.find((v) => v.id === c.desaId)?.nama || "Seluruh Desa";
                return (
                  <div key={c.id} className="bg-white p-3.5 rounded-xl border border-amber-100 shadow-sm space-y-2">
                    <div className="flex justify-between items-start gap-2">
                      <div className="bg-amber-100/50 text-amber-900 border border-amber-200/40 text-[9px] font-bold px-2 py-0.5 rounded uppercase">
                        Hutang Data: {affectedDesaName}
                      </div>
                      <span className="text-[10px] font-mono text-slate-400">{c.tanggal}</span>
                    </div>
                    <p className="text-xs text-slate-700 italic leading-relaxed">
                      &ldquo;{c.catatan}&rdquo;
                    </p>
                    <div className="text-[10px] text-slate-400 flex items-center gap-1">
                      <MessageSquare className="w-3 h-3 text-slate-400" />
                      <span>Pengirim: {c.pengirim}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
