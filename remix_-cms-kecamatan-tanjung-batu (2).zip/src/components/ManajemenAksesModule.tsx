/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, FormEvent } from "react";
import {
  Key,
  ShieldCheck,
  User,
  ShieldAlert,
  Sliders,
  History,
  Lock,
  RefreshCw,
  Plus,
  Trash,
  FileEdit,
  UserPlus
} from "lucide-react";
import { LogAktivitas, UserRole, Desa } from "../types";

interface ManajemenAksesModuleProps {
  aktivitas: LogAktivitas[];
  activeRole: UserRole;
  operatorVillageId: string | null;
  villages: Desa[];
  onRoleSwitch: (role: UserRole, operatorVillageId: string | null) => void;
  onLoggedAction: (action: string, detail: string) => void;
}

export default function ManajemenAksesModule({
  aktivitas,
  activeRole,
  operatorVillageId,
  villages,
  onRoleSwitch,
  onLoggedAction
}: ManajemenAksesModuleProps) {
  const [adminPassword, setAdminPassword] = useState("");
  const [showPwdResetSuccess, setShowPwdResetSuccess] = useState("");

  // Stateful CRUD accounts system
  const [userAccounts, setUserAccounts] = useState([
    {
      id: "acc-1",
      nama: "Drs. H. Syahrul, M.Si",
      role: "Camat/Admin Kecamatan" as UserRole,
      villageId: null as string | null,
      desc: "Akses Super-Admin Kecamatan. Berwenang melihat semua desa, melakukan modifikasi data global, mengirim memo, dan mengatur perijinan."
    },
    {
      id: "acc-2",
      nama: "Ahmad Jauhari (Petanggan)",
      role: "Operator Desa" as UserRole,
      villageId: "desa-2", // Petanggan
      desc: "Akses Terbatas Desa Petanggan. Berwenang mengubah monografi Desa Petanggan, memasarkan produk agrowisata, dan mengelola aparatur desa Petanggan."
    },
    {
      id: "acc-3",
      nama: "Siti Rahma (Sugih Waras)",
      role: "Operator Desa" as UserRole,
      villageId: "desa-4", // Sugih Waras
      desc: "Akses Terbatas Desa Sugih Waras. Berwenang menyiarkan kabar pertanian, memperbaharui harga jagung hibrida, melakukan audit aset Sugih Waras."
    },
    {
      id: "acc-4",
      nama: "Tamu Kehormatan Pemprov Sumsel",
      role: "Publik/Pengunjung" as UserRole,
      villageId: null as string | null,
      desc: "Akses Baca-Saja (Guest). Diperuntukkan bagi masyarakat umum, dinas kabupaten, atau investor yang mencari referensi potensi UMKM Sumatera Selatan."
    }
  ]);

  // CRUD Form states
  const [showCrudForm, setShowCrudForm] = useState(false);
  const [editingAccountId, setEditingAccountId] = useState<string | null>(null);
  const [formNama, setFormNama] = useState("");
  const [formRole, setFormRole] = useState<UserRole>("Operator Desa");
  const [formVillageId, setFormVillageId] = useState<string>("");
  const [formDesc, setFormDesc] = useState("");

  const handleResetPassword = (accNama: string) => {
    onLoggedAction("Reset Password", `Membantu meriset password akun operator ${accNama}.`);
    setShowPwdResetSuccess(accNama);
    setTimeout(() => {
      setShowPwdResetSuccess("");
    }, 4000);
  };

  const handleSaveAccount = (e: FormEvent) => {
    e.preventDefault();
    if (!formNama) return;

    const actualVillageId = formRole === "Operator Desa" ? (formVillageId || villages[0]?.id || null) : null;

    if (editingAccountId) {
      // UPDATE mode
      setUserAccounts((prev) =>
        prev.map((acc) =>
          acc.id === editingAccountId
            ? {
                ...acc,
                nama: formNama,
                role: formRole,
                villageId: actualVillageId,
                desc: formDesc || `Rincian hak akses login dinamis operasional sebagai ${formRole}.`
              }
            : acc
        )
      );
      onLoggedAction("Update Akun", `Memodifikasi profil hak akses akun operator "${formNama}".`);
      setEditingAccountId(null);
    } else {
      // CREATE mode
      const newAcc = {
        id: `acc-${Date.now()}`,
        nama: formNama,
        role: formRole,
        villageId: actualVillageId,
        desc: formDesc || `Daftar akun operator baru yang melayani hak akses administratif ${formRole}.`
      };
      setUserAccounts((prev) => [...prev, newAcc]);
      onLoggedAction("Tambah Akun", `Mendaftarkan akun operator baru bernama "${formNama}" sebagai ${formRole}.`);
    }

    // Reset Form
    setFormNama("");
    setFormDesc("");
    setFormVillageId("");
    setShowCrudForm(false);
  };

  const handleEditClick = (acc: typeof userAccounts[0]) => {
    setEditingAccountId(acc.id);
    setFormNama(acc.nama);
    setFormRole(acc.role);
    setFormVillageId(acc.villageId || villages[0]?.id || "");
    setFormDesc(acc.desc);
    setShowCrudForm(true);
  };

  const handleDeleteAccount = (id: string, nama: string) => {
    setUserAccounts((prev) => prev.filter((acc) => acc.id !== id));
    onLoggedAction("Hapus Akun", `Menghapus akun operator "${nama}" dari daftar sistem otorisasi.`);
  };

  return (
    <div className="grid grid-cols-1 xl:grid-cols-12 gap-6">
      {/* 9.1 & 9.2 Manajemen Akun & Role Swapper */}
      <div className="xl:col-span-7 bg-white rounded-2xl border border-slate-200 p-6 shadow-sm space-y-6">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-slate-900 border-l-2 border-yellow-500 px-2.5 py-0.5">
              9.1 Akun & Hak Akses Berbasis Peran
            </span>
            <h3 className="text-lg font-bold text-slate-800 mt-1">
              Simulasi & Registrasi Akun Pengguna
            </h3>
            <p className="text-xs text-slate-500">
              Klik salah satu profil pegawai untuk berpindah mode. Hanya Camat / Admin Kecamatan yang berhak melakukan pendaftaran dan penghapusan CRUD akun.
            </p>
          </div>

          <button
            onClick={() => {
              setEditingAccountId(null);
              setFormNama("");
              setFormDesc("");
              setFormVillageId(villages[0]?.id || "");
              setShowCrudForm(!showCrudForm);
            }}
            className="bg-[#0F172A] hover:bg-[#1E293B] text-white text-xs font-bold px-3.5 py-2 rounded-xl transition-all flex items-center gap-1.5 shrink-0 shadow-sm"
          >
            <UserPlus className="w-4 h-4" /> Registrasi Akun
          </button>
        </div>

        {/* CRUD Form overlay/in-panel */}
        {showCrudForm && (
          <form onSubmit={handleSaveAccount} className="bg-slate-50 p-5 rounded-2xl border border-slate-200 space-y-4 animate-fadeIn">
            <div className="flex justify-between items-center border-b border-slate-200 pb-2">
              <h4 className="text-xs font-black uppercase text-slate-850 flex items-center gap-1.5 text-slate-800 tracking-wider">
                <Sliders className="w-4 h-4 text-yellow-600" />
                {editingAccountId ? "Kemutakhiran Otoritas Akun" : "Registrasi Operator Baru"}
              </h4>
              <button 
                type="button" 
                onClick={() => {
                  setShowCrudForm(false);
                  setEditingAccountId(null);
                }} 
                className="text-[10px] font-bold text-slate-400 hover:text-slate-600 uppercase"
              >
                Tutup
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-[10px] uppercase font-bold text-slate-550 mb-1 text-slate-500">Nama Lengkap Pegawai</label>
                <input
                  required
                  type="text"
                  placeholder="Contoh: Heri Sunandar, S.Pd"
                  value={formNama}
                  onChange={(e) => setFormNama(e.target.value)}
                  className="w-full text-xs border border-slate-250 bg-white rounded-lg p-2.5 focus:outline-none focus:border-yellow-500 text-slate-800 font-bold"
                />
              </div>

              <div>
                <label className="block text-[10px] uppercase font-bold text-slate-550 mb-1 text-slate-500">Hak Peran (Role)</label>
                <select
                  value={formRole}
                  onChange={(e) => setFormRole(e.target.value as UserRole)}
                  className="w-full text-xs border border-slate-250 bg-white rounded-lg p-2.5 focus:outline-none focus:border-yellow-500 text-slate-800 font-bold"
                >
                  <option value="Camat/Admin Kecamatan">Camat/Admin Kecamatan</option>
                  <option value="Operator Desa">Operator Desa</option>
                  <option value="Publik/Pengunjung">Publik/Pengunjung</option>
                </select>
              </div>

              {formRole === "Operator Desa" && (
                <div className="sm:col-span-2">
                  <label className="block text-[10px] uppercase font-bold text-slate-550 mb-1 text-slate-500">Lokasi Penugasan (Desa Otoritas)</label>
                  <select
                    value={formVillageId}
                    onChange={(e) => setFormVillageId(e.target.value)}
                    className="w-full text-xs border border-slate-250 bg-white rounded-lg p-2.5 focus:outline-none focus:border-yellow-500 text-slate-800 font-bold"
                  >
                    {villages.map((v) => (
                      <option key={v.id} value={v.id}>{v.nama}</option>
                    ))}
                  </select>
                </div>
              )}

              <div className="sm:col-span-2">
                <label className="block text-[10px] uppercase font-bold text-slate-550 mb-1 text-slate-500">Deskripsi Ringkas Jabatan</label>
                <input
                  type="text"
                  placeholder="Contoh: Mengurus inventarisasi monografi desa."
                  value={formDesc}
                  onChange={(e) => setFormDesc(e.target.value)}
                  className="w-full text-xs border border-slate-250 bg-white rounded-lg p-2.5 focus:outline-none focus:border-yellow-500 text-slate-700"
                />
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t border-slate-200">
              <button
                type="submit"
                className="bg-yellow-500 hover:bg-yellow-600 text-slate-950 font-black text-xs px-5 py-2 rounded-xl transition-all"
              >
                {editingAccountId ? "Simpan Perubahan Akun" : "Daftarkan Akun Baru"}
              </button>
            </div>
          </form>
        )}

        {/* Profiles Deck */}
        <div className="space-y-4">
          {userAccounts.map((acc) => {
            const isCurrentlyActive = activeRole === acc.role && operatorVillageId === acc.villageId;
            const targetVillageName = acc.villageId ? villages.find((v) => v.id === acc.villageId)?.nama : "Seluruh Kecamatan";

            return (
              <div
                key={acc.id}
                onClick={() => onRoleSwitch(acc.role, acc.villageId)}
                className={`p-4 rounded-xl border transition-all cursor-pointer flex flex-col md:flex-row items-start md:items-center justify-between gap-4 ${
                  isCurrentlyActive
                    ? "border-yellow-500 bg-yellow-500/[0.04] shadow-sm"
                    : "border-slate-100 hover:border-yellow-300 hover:bg-slate-50/50"
                }`}
              >
                <div className="flex gap-3.5 items-start">
                  <div className={`p-2.5 rounded-xl shrink-0 ${
                    isCurrentlyActive ? "bg-[#0F172A] text-white" : "bg-slate-100 text-slate-500"
                  }`}>
                    <User className="w-5 h-5 focus-ring" />
                  </div>
                  <div className="space-y-1">
                    <h4 className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                      {acc.nama}
                      {isCurrentlyActive && (
                        <span className="text-[9px] bg-yellow-500 text-white font-bold uppercase px-2 py-0.5 rounded-full">
                          LOGIN AKTIF
                        </span>
                      )}
                    </h4>
                    <p className="text-[10px] text-slate-400 font-bold uppercase">
                      Bagian: {acc.role} ({targetVillageName})
                    </p>
                    <p className="text-[11px] text-slate-500 leading-relaxed max-w-sm">{acc.desc}</p>
                  </div>
                </div>

                <div className="flex sm:flex-row md:flex-col items-center md:items-end gap-1.5 shrink-0 self-stretch sm:self-auto">
                  {acc.role !== "Publik/Pengunjung" && (
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleResetPassword(acc.nama);
                      }}
                      className="text-center py-1 px-2 text-[10px] bg-slate-100 hover:bg-slate-200 text-slate-700 rounded transition-colors flex items-center justify-center gap-1 font-bold"
                    >
                      <RefreshCw className="w-3 h-3 text-slate-400" /> Reset Sandi
                    </button>
                  )}

                  <div className="flex gap-1">
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleEditClick(acc);
                      }}
                      className="text-[10px] text-indigo-600 hover:text-indigo-800 font-bold bg-indigo-50 hover:bg-indigo-100 px-2.5 py-1 rounded-lg"
                    >
                      Ubah
                    </button>
                    {activeRole === "Camat/Admin Kecamatan" && (
                      <button
                        type="button"
                        disabled={isCurrentlyActive}
                        onClick={(e) => {
                          e.stopPropagation();
                          handleDeleteAccount(acc.id, acc.nama);
                        }}
                        className="text-[10px] text-rose-600 hover:text-rose-800 font-bold bg-rose-50 hover:bg-rose-100 px-2.5 py-1 rounded-lg disabled:opacity-40 disabled:cursor-not-allowed"
                        title="Hapus akun dari sistem"
                      >
                        Hapus
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* 9.3 Security Warnings & 9.5 Log Audit */}
      <div className="xl:col-span-5 space-y-6">
        {/* 9.3 Pembatasan Data per Desa Warnings Panel */}
        <div className="bg-slate-900 text-white rounded-2xl border border-slate-800 p-6 shadow-sm space-y-4">
          <div className="flex items-center gap-2">
            <Lock className="w-5 h-5 text-yellow-400 shrink-0" />
            <h4 className="text-xs font-black uppercase text-yellow-400 tracking-wider">
              9.3 Keamanan Enclave Desa (Data Isolation)
            </h4>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            Sistem CMS secara ketat mengimplementasikan modul keamanan **Data Isolation**. Ketika diakses oleh operator selain Camat, sekuritas sistem mengamankan file desa tetangga.
          </p>

          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 text-left space-y-2.5">
            <h5 className="text-[11px] text-slate-400 uppercase font-bold">Kebijakan Hak Akses Aktif:</h5>
            <div className="text-xs font-sans text-slate-300 space-y-2">
              <div className="flex items-start gap-1.5">
                <span className="text-xs text-yellow-400 font-bold">✓</span>
                <p className="leading-tight">
                  Status Peran Anda: <strong>{activeRole}</strong>
                </p>
              </div>
              <div className="flex items-start gap-1.5">
                <span className="text-xs text-yellow-400 font-bold">✓</span>
                <p className="leading-tight">
                  Wilayah Otorisasi: <strong>{operatorVillageId ? villages.find(v => v.id === operatorVillageId)?.nama : "Seluruh Desa (Camat)"}</strong>
                </p>
              </div>
              {operatorVillageId ? (
                <div className="bg-amber-950/40 border border-amber-900 p-2.5 rounded text-amber-300 text-[10px] leading-relaxed flex gap-2">
                  <ShieldAlert className="w-4 h-4 shrink-0 mt-0.5 text-amber-500" />
                  <span>
                    <strong>Pemberitahuan Kontrol:</strong> UI telah dinonaktifkan secara otomatis untuk tombol edit desa selain <strong>{villages.find(v => v.id === operatorVillageId)?.nama}</strong>. Hubungi Bupati atau Camat jika terdapat kekeliruan login.
                  </span>
                </div>
              ) : (
                <div className="bg-yellow-500/10 border border-yellow-500/20 p-2.5 rounded text-yellow-300 text-[10px] leading-relaxed flex gap-2">
                  <ShieldCheck className="w-4 h-4 shrink-0 mt-0.5 text-yellow-400" />
                  <span>
                    Akses tidak terisolasi. Seluruh desa terbuka untuk pelaporan Kecamatan Belitang Mulya.
                  </span>
                </div>
              )}
            </div>
          </div>

          {/* Reset password toast mock */}
          {showPwdResetSuccess && (
            <div className="p-3 bg-yellow-500 rounded-lg text-white text-xs font-bold shadow animate-bounce text-center">
              Berhasil! Sandi default direset menjadi: &ldquo;BelitangMulya_123&rdquo; untuk {showPwdResetSuccess}
            </div>
          )}
        </div>

        {/* 9.5 Log Aktivitas Pengguna */}
        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm space-y-4">
          <div className="flex justify-between items-center pb-2 border-b">
            <h4 className="text-xs font-bold uppercase text-slate-400 tracking-wider flex items-center gap-1.5">
              <History className="w-4 h-4 text-amber-600" />
              9.5 Log Audit Aktivitas Pengguna
            </h4>
          </div>

          <div className="space-y-3 max-h-60 overflow-y-auto pr-1">
            {aktivitas.map((act) => (
              <div key={act.id} className="p-2.5 bg-slate-50 rounded-xl border border-slate-100 text-[11px] space-y-1">
                <div className="flex justify-between items-center">
                  <span className="font-bold text-slate-700">{act.user} <span className="text-[9px] text-slate-400">({act.role})</span></span>
                  <span className="font-mono text-slate-400 text-[9px]">{act.timestamp}</span>
                </div>
                <div className="text-slate-800">
                  Aksi: <strong className="text-yellow-600 font-bold">{act.aksi}</strong>
                </div>
                <p className="text-slate-500 text-[10px] leading-tight">{act.detail}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
