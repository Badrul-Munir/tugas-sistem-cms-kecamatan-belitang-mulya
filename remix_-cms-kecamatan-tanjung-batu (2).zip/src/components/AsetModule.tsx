/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, FormEvent } from "react";
import {
  Database,
  Building2,
  MapPin,
  Compass,
  FileCheck,
  Plus,
  Compass as CompassIcon,
  Download,
  AlertTriangle,
  Info
} from "lucide-react";
import { AsetDesa, Desa, UserRole } from "../types";

interface AsetModuleProps {
  aset: AsetDesa[];
  villages: Desa[];
  activeRole: UserRole;
  operatorVillageId: string | null;
  onAddAset: (newAset: Omit<AsetDesa, "id">) => void;
  onUpdateCondition: (asetId: string, kondisi: AsetDesa["kondisi"]) => void;
}

export default function AsetModule({
  aset,
  villages,
  activeRole,
  operatorVillageId,
  onAddAset,
  onUpdateCondition
}: AsetModuleProps) {
  const [selectedVillageId, setSelectedVillageId] = useState("");
  const [selectedKategori, setSelectedKategori] = useState("");
  const [detailedAset, setDetailedAset] = useState<AsetDesa | null>(aset[0] || null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Form controls
  const [showAddForm, setShowAddForm] = useState(false);
  const [formNama, setFormNama] = useState("");
  const [formKategori, setFormKategori] = useState<AsetDesa["kategoriAset"]>("Tanah Milik Desa");
  const [formDesaId, setFormDesaId] = useState(villages[0]?.id || "");
  const [formLokasi, setFormLokasi] = useState("");
  const [formLuas, setFormLuas] = useState("");
  const [formSertifikat, setFormSertifikat] = useState("Sertifikat Pemdes");
  const [formPenggunaan, setFormPenggunaan] = useState("");

  const categories = ["Tanah Milik Desa", "Bangunan Milik Desa", "Inventaris Barang Desa"];

  const filteredAset = aset.filter((a) => {
    const matchesVillage = !selectedVillageId || a.desaId === selectedVillageId;
    const matchesKategori = !selectedKategori || a.kategoriAset === selectedKategori;
    return matchesVillage && matchesKategori;
  });

  const canEditAset = (vId: string) => {
    if (activeRole === "Camat/Admin Kecamatan") return true;
    if (activeRole === "Operator Desa" && operatorVillageId === vId) return true;
    return false;
  };

  const handleCreateAset = (e: FormEvent) => {
    e.preventDefault();
    if (!formNama || !formLokasi) return;

    onAddAset({
      desaId: formDesaId,
      namaAset: formNama,
      kategoriAset: formKategori,
      lokasiSpesifik: formLokasi,
      luasMeterPersegi: formLuas ? parseFloat(formLuas) : undefined,
      statusKepemilikan: formSertifikat,
      kondisi: "Aktif Digunakan",
      penggunaanSaatIni: formPenggunaan || "Fasilitasi Rakyat",
      dokumenPendukungName: "Lampiran_BeritaAcara_PemeriksaanAset.pdf",
      dokumenSize: "1.1 MB"
    });

    setFormNama("");
    setFormLokasi("");
    setFormLuas("");
    setFormPenggunaan("");
    setShowAddForm(false);
  };

  const handleDownloadAlert = (name: string, size: string) => {
    setToastMessage(`[DOKUMEN DIUNDUH] File "${name}" (${size}) berhasil disimulasikan terunduh ke komputer Anda.`);
    setTimeout(() => {
      setToastMessage(null);
    }, 4500);
  };

  return (
    <div className="space-y-6">
      {/* 8.1 Header Filters and Stats */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm space-y-4">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-slate-900 border-l-2 border-yellow-500 px-2.5 py-0.5">
              8.0 Buku Register Aset Desa
            </span>
            <h3 className="text-lg font-bold text-slate-800 mt-1">
              Inventaris Bangunan & Tanah Pemerintah
            </h3>
            <p className="text-xs text-slate-500">
              Pusat pencatatan legalitas, titik fisik, dan status operasional seluruh prasarana milik pemdes.
            </p>
          </div>

          <div className="flex gap-2 self-stretch sm:self-auto">
            {activeRole !== "Publik/Pengunjung" && (
              <button
                onClick={() => {
                  if (activeRole === "Operator Desa" && operatorVillageId) {
                    setFormDesaId(operatorVillageId);
                  }
                  setShowAddForm(!showAddForm);
                }}
                className="bg-[#0F172A] hover:bg-[#1e293b] text-white text-xs font-semibold px-4 py-2 rounded-lg transition-all flex items-center gap-1.5 shrink-0 hover:scale-[1.01]"
              >
                <Plus className="w-4 h-4" /> Daftarkan Aset
              </button>
            )}
            <select
              value={selectedVillageId}
              onChange={(e) => setSelectedVillageId(e.target.value)}
              className="text-xs border border-slate-200 rounded-lg py-2 px-3 focus:outline-none cursor-pointer bg-slate-50"
            >
              <option value="">Semua Wilayah</option>
              {villages.map((v) => (
                <option key={v.id} value={v.id}>
                  {v.nama}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Add Asset Form */}
      {showAddForm && (
        <form onSubmit={handleCreateAset} className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm grid grid-cols-1 md:grid-cols-12 gap-4">
          <div className="md:col-span-12 border-b border-slate-100 pb-3 flex justify-between items-center">
            <h4 className="text-sm font-bold text-slate-800">Daftarkan Entri Aset Baru Desa</h4>
            <button type="button" onClick={() => setShowAddForm(false)} className="text-xs text-slate-400 hover:text-slate-600">Batal</button>
          </div>

          <div className="md:col-span-4">
            <label className="block text-[10px] uppercase font-bold text-slate-500 mb-1">Nama Aset (Inventaris)</label>
            <input
              required
              type="text"
              placeholder="Contoh: Gedung Balai Desa Purwodadi"
              value={formNama}
              onChange={(e) => setFormNama(e.target.value)}
              className="w-full text-xs border border-slate-200 rounded-lg p-2.5 focus:outline-none focus:border-yellow-500"
            />
          </div>

          <div className="md:col-span-4">
            <label className="block text-[10px] uppercase font-bold text-slate-500 mb-1">Klasifikasi Aset (8.1/8.2/8.3)</label>
            <select
              value={formKategori}
              onChange={(e) => setFormKategori(e.target.value as AsetDesa["kategoriAset"])}
              className="w-full text-xs border border-slate-200 rounded-lg p-2.5 focus:outline-none"
            >
              <option value="Tanah Milik Desa">8.1 Tanah Milik Desa</option>
              <option value="Bangunan Milik Desa">8.2 Bangunan Milik Desa</option>
              <option value="Inventaris Barang Desa">8.3 Inventaris Barang Desa</option>
            </select>
          </div>

          {activeRole !== "Operator Desa" && (
            <div className="md:col-span-4">
              <label className="block text-[10px] uppercase font-bold text-slate-500 mb-1">Desa Penanggung Jawab</label>
              <select
                value={formDesaId}
                onChange={(e) => setFormDesaId(e.target.value)}
                className="w-full text-xs border border-slate-200 p-2.5 focus:outline-none"
              >
                {villages.map((v) => (
                  <option key={v.id} value={v.id}>{v.nama}</option>
                ))}
              </select>
            </div>
          )}

          <div className="md:col-span-8">
            <label className="block text-[10px] uppercase font-bold text-slate-500 mb-1">Lokasi Rinci & Keterangan Fisik</label>
            <input
              required
              type="text"
              placeholder="Contoh: Jl. Mayor Ruslan, Dusun III, Belakang Pasar"
              value={formLokasi}
              onChange={(e) => setFormLokasi(e.target.value)}
              className="w-full text-xs border border-slate-200 rounded-lg p-2.5 focus:outline-none focus:border-yellow-500"
            />
          </div>

          <div className="md:col-span-4">
            <label className="block text-[10px] uppercase font-bold text-slate-500 mb-1">Luas (Meter Persegi)</label>
            <input
              type="number"
              placeholder="Contoh: 1540 (Boleh kosong untuk mesin)"
              value={formLuas}
              onChange={(e) => setFormLuas(e.target.value)}
              className="w-full text-xs border border-slate-200 rounded-lg p-2.5 focus:outline-none"
            />
          </div>

          <div className="md:col-span-6">
            <label className="block text-[10px] uppercase font-bold text-slate-500 mb-1">Status Kepemilikan (Deed)</label>
            <input
              type="text"
              placeholder="Contoh: Sertifikat BPN Ke-9"
              value={formSertifikat}
              onChange={(e) => setFormSertifikat(e.target.value)}
              className="w-full text-xs border border-slate-200 rounded-lg p-2.5 focus:outline-none"
            />
          </div>

          <div className="md:col-span-6">
            <label className="block text-[10px] uppercase font-bold text-slate-500 mb-1">Penggunaan / Fungsi Utama Saat Ini</label>
            <input
              type="text"
              placeholder="Contoh: Layanan Posyandu Bulanan"
              value={formPenggunaan}
              onChange={(e) => setFormPenggunaan(e.target.value)}
              className="w-full text-xs border border-slate-200 rounded-lg p-2.5 focus:outline-none"
            />
          </div>

          <div className="md:col-span-12 flex justify-end gap-2 pt-2 border-t">
            <button
              type="button"
              onClick={() => setShowAddForm(false)}
              className="px-4 py-2 border border-slate-200 text-xs text-slate-500 rounded-lg hover:bg-slate-50"
            >
              Batal
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-[#0F172A] hover:bg-[#1e293b] text-white rounded-lg text-xs font-black shadow-sm"
            >
              Simpan Master Aset
            </button>
          </div>
        </form>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Register Table Left */}
        <div className="lg:col-span-7 bg-white rounded-2xl border border-slate-200 p-6 shadow-sm space-y-4">
          <div className="flex justify-between items-center pb-2 border-b">
            <h4 className="text-xs font-bold uppercase text-slate-400 tracking-wider flex items-center gap-2">
              <Database className="w-4 h-4 text-amber-600" />
              Buku Register Aset Daerah Terdaftar
            </h4>
          </div>

          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-slate-100 text-left text-[11px] text-slate-700">
              <thead className="bg-slate-50 text-slate-500 font-bold uppercase">
                <tr>
                  <th className="px-3 py-2.5">Aset / Inventaris</th>
                  <th className="px-3 py-2.5">Klasifikasi</th>
                  <th className="px-3 py-2.5">Bumi / Desa</th>
                  <th className="px-3 py-2.5">Pemakaian</th>
                  <th className="px-3 py-2.5 text-right">Fisik</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50 font-sans">
                {filteredAset.map((item) => {
                  const isSelected = detailedAset?.id === item.id;
                  const parentDesa = villages.find((v) => v.id === item.desaId);

                  return (
                    <tr
                      key={item.id}
                      onClick={() => setDetailedAset(item)}
                      className={`cursor-pointer transition-colors ${
                        isSelected ? "bg-yellow-500/[0.04] font-bold text-slate-900" : "hover:bg-slate-50"
                      }`}
                    >
                      <td className="px-3 py-3 font-semibold text-slate-800">{item.namaAset}</td>
                      <td className="px-3 py-3">
                        <span className="text-[10px] text-slate-500 bg-slate-100 px-1.5 py-0.5 rounded">
                          {item.kategoriAset.replace(" Milik Desa", "")}
                        </span>
                      </td>
                      <td className="px-3 py-3">{parentDesa?.nama}</td>
                      <td className="px-3 py-3 max-w-[120px] truncate">{item.penggunaanSaatIni}</td>
                      <td className="px-3 py-3 text-right">
                        <span className={`text-[9px] px-1.5 py-0.5 rounded border ${
                          item.kondisi === "Aktif Digunakan"
                            ? "bg-yellow-105 text-yellow-900 border-yellow-250 bg-yellow-50 font-bold text-yellow-800"
                            : item.kondisi === "Rusak Ringan"
                            ? "bg-amber-100 text-amber-800 border-amber-200"
                            : "bg-rose-100 text-rose-800 border border-rose-200"
                        }`}>
                          {item.kondisi.replace(" Digunakan", "")}
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Detailed Register Sheet & Documents */}
        <div className="lg:col-span-5">
          {detailedAset ? (() => {
            const isRestricted = !canEditAset(detailedAset.desaId);
            const parentDesa = villages.find((v) => v.id === detailedAset.desaId);

            return (
              <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm space-y-4 font-sans">
                <div className="border-b border-slate-100 pb-3">
                  <span className="text-[9px] uppercase font-mono text-slate-400">8.0 SPESIFIKASI DOKUMEN REGISTER ASET</span>
                  <h4 className="text-sm font-black text-slate-800 mt-1">{detailedAset.namaAset}</h4>
                  <p className="text-xs text-slate-500">Administrasi Wilayah: <strong>{parentDesa?.nama}</strong></p>
                </div>

                <div className="space-y-2.5 text-xs">
                  <div className="flex justify-between items-center border-b border-slate-100 pb-1.5">
                    <span className="text-slate-400">Klasifikasi Legalitas:</span>
                    <strong className="text-slate-700">{detailedAset.kategoriAset}</strong>
                  </div>
                  <div className="flex justify-between items-center border-b border-slate-100 pb-1.5">
                    <span className="text-slate-400">Titel Kepemilikan:</span>
                    <span className="font-mono text-slate-600 font-semibold">{detailedAset.statusKepemilikan}</span>
                  </div>
                  <div className="flex justify-between items-center border-b border-slate-100 pb-1.5">
                    <span className="text-slate-400">Lokasi Penyelenggara:</span>
                    <span className="text-slate-600 max-w-[200px] text-right line-clamp-1">{detailedAset.lokasiSpesifik}</span>
                  </div>
                  {detailedAset.luasMeterPersegi && (
                    <div className="flex justify-between items-center border-b border-slate-100 pb-1.5">
                      <span className="text-slate-400">Luas Kubikal Tanah/Bangunan:</span>
                      <strong className="text-slate-800 font-mono">{detailedAset.luasMeterPersegi} m²</strong>
                    </div>
                  )}
                  <div className="flex justify-between items-center pb-1">
                    <span className="text-slate-400">Pemanfaatan Publik:</span>
                    <strong className="text-slate-700">{detailedAset.penggunaanSaatIni}</strong>
                  </div>
                </div>

                {/* 8.4 Geotagging information block */}
                <div className="bg-[#0F172A] text-yellow-450 text-yellow-400 p-3.5 rounded-xl border border-slate-900 space-y-2.5">
                  <div className="flex justify-between items-center">
                    <span className="text-[9px] text-slate-450 font-bold uppercase tracking-wider flex items-center gap-1">
                      <CompassIcon className="w-3.5 h-3.5 text-yellow-400" /> Geolasir Koordinat Fisik (8.4)
                    </span>
                    <span className="text-[8px] bg-yellow-500/10 text-yellow-400 font-black uppercase px-2 py-0.5 rounded border border-yellow-500/30">
                      LIVE GPS
                    </span>
                  </div>
                  <div className="grid grid-cols-2 gap-2 text-[11px] font-mono">
                    <div className="bg-slate-950 p-2 rounded border border-slate-800 text-center">
                      <div className="text-[8px] text-slate-500 uppercase">Garis Lintang (Lat)</div>
                      <div className="font-bold text-white mt-0.5">
                        {detailedAset.koordinatLat ? detailedAset.koordinatLat.toFixed(6) : parentDesa?.koordinatLat.toFixed(6)}
                      </div>
                    </div>
                    <div className="bg-slate-950 p-2 rounded border border-slate-800 text-center">
                      <div className="text-[8px] text-slate-500 uppercase">Garis Bujur (Lng)</div>
                      <div className="font-bold text-white mt-0.5">
                        {detailedAset.koordinatLng ? detailedAset.koordinatLng.toFixed(6) : parentDesa?.koordinatLng.toFixed(6)}
                      </div>
                    </div>
                  </div>
                </div>

                {/* 8.6 File Mock Attachment Download Area */}
                <div className="bg-slate-50 p-4 rounded-xl border border-slate-200/50 space-y-3">
                  <div className="flex items-center gap-2">
                    <div className="p-1.5 bg-yellow-50 rounded text-yellow-600 border border-yellow-250">
                      <FileCheck className="w-4 h-4" />
                    </div>
                    <div>
                      <h6 className="text-[10px] font-bold uppercase text-slate-400">8.6 Dokumen Sertifikat / Bukti Logistik</h6>
                      <span className="text-xs font-bold text-slate-800 max-w-[180px] truncate block mt-0.5">
                        {detailedAset.dokumenPendukungName}
                      </span>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => handleDownloadAlert(detailedAset.dokumenPendukungName, detailedAset.dokumenSize)}
                    className="w-full bg-slate-200 hover:bg-slate-350 text-slate-700 py-2 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 border border-slate-300"
                  >
                    <Download className="w-3.5 h-3.5" />
                    Unduh Arsip Sertifikat ({detailedAset.dokumenSize})
                  </button>
                </div>

                {/* 8.5 Condition Switcher */}
                {!isRestricted ? (
                  <div className="space-y-1.5 border-t border-slate-100 pt-3">
                    <label className="block text-[10px] uppercase font-bold text-slate-400">Kondisi Fisik Saat Ini (8.5)</label>
                    <select
                      value={detailedAset.kondisi}
                      onChange={(e) => onUpdateCondition(detailedAset.id, e.target.value as AsetDesa["kondisi"])}
                      className="w-full text-xs border border-slate-200 rounded-lg p-2 focus:outline-none focus:border-yellow-500 cursor-pointer"
                    >
                      <option value="Aktif Digunakan">Aktif Digunakan</option>
                      <option value="Rusak Ringan">Rusak Ringan</option>
                      <option value="Rusak Berat">Rusak Berat</option>
                      <option value="Tidak Digunakan">Tidak Digunakan</option>
                      <option value="Dipinjamkan">Dipinjamkan</option>
                      <option value="Disewakan">Disewakan</option>
                    </select>
                  </div>
                ) : (
                  <div className="bg-slate-100 text-[10px] text-slate-500 p-2.5 rounded-lg text-center leading-snug">
                    Anda masuk sebagai {activeRole}. Hanya operator {parentDesa?.nama} yang diizinkan merubah status kondisi fisik aset ini.
                  </div>
                )}
              </div>
            );
          })() : (
            <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm text-center py-16 flex flex-col items-center">
              <Building2 className="w-10 h-10 text-slate-300 mb-2" />
              <p className="text-xs">Klik salah satu baris instrumen aset untuk menginspeksi titik koordinat GPS.</p>
            </div>
          )}
        </div>
      </div>

      {/* Floating System Notification Toast */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 bg-slate-950 border-2 border-yellow-500 text-white px-4 py-3 rounded-xl shadow-2xl flex items-center gap-3 z-50 animate-pulse font-sans">
          <div className="w-2.5 h-2.5 bg-yellow-400 rounded-full shrink-0" />
          <p className="text-xs font-bold leading-normal">{toastMessage}</p>
          <button 
            type="button" 
            onClick={() => setToastMessage(null)} 
            className="text-slate-400 hover:text-white font-mono text-[10px] pl-2 border-l border-slate-700 hover:scale-105"
          >
            TUTUP
          </button>
        </div>
      )}
    </div>
  );
}
