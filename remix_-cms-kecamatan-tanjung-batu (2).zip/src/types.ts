/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface Desa {
  id: string; // e.g., "desa-1"
  nama: string; // e.g., "Purwodadi"
  kodeDesa: string;
  alamatKantor: string;
  namaKepalaDesa: string;
  fotoKades?: string;
  kontakKantor: string;
  statusWeb: "Aktif" | "Belum Aktif" | "Draft" | "Perlu Diperbarui" | "Menunggu Verifikasi";
  sejarahSingkat: string;
  luasWilayahHektar: number;
  batasUtara: string;
  batasSelatan: string;
  batasTimur: string;
  batasBarat: string;
  koordinatLat: number;
  koordinatLng: number;
  visi: string;
  misi: string[];
}

export interface MonografiKependudukan {
  desaId: string;
  jumlahPenduduk: number;
  jumlahKK: number;
  jumlahLakiLaki: number;
  jumlahPerempuan: number;
  distribusiUsia: {
    balita: number; // 0-5
    anak: number; // 6-12
    remaja: number; // 13-18
    produktif: number; // 19-59
    lansia: number; // 60+
  };
  agama: {
    islam: number;
    kristen: number;
    katolik: number;
    hindu: number;
    buddha: number;
    konghucu: number;
  };
}

export interface MonografiSosialEkonomi {
  desaId: string;
  pekerjaan: {
    petaniKaret: number;
    petaniNanas: number;
    pengrajinTenun: number;
    tukangKayuPanggung: number;
    pedagang: number;
    pnsTniPolri: number;
    buruh: number;
    lainnya: number;
  };
  pendidikan: {
    tidakSekolah: number;
    sd: number;
    smp: number;
    sma: number;
    diplomaSarjana: number;
  };
  jumlahDusun: number;
  jumlahNakes: number; // Tenaga kesehatan (bidan, perawat)
}

export interface SaranaPrasarana {
  desaId: string;
  sekolah: { sd: number; smp: number; sma: number; paud: number };
  fasilitasKesehatan: { puskesmasPustu: number; posyandu: number; bidanPraktek: number };
  tempatIbadah: { masjid: number; mushola: number; gereja: number };
  panjangJalanKm: number;
  jumlahJembatan: number;
  pasarDesa: number;
  balaiDesa: boolean;
}

export interface Komoditas {
  id: string;
  desaId: string;
  namaKomoditas: string;
  kategori: "Pertanian" | "Perkebunan" | "Peternakan" | "Perikanan" | "UMKM Kerajinan" | "Industri Rumah Tangga" | "Jasa";
  estimasiProduksiTahunan: string; // e.g. "150 Ton / Tahun"
  luasLahanHektarOrUnit: string; // e.g. "200 Hektar" or "45 Unit Usaha"
  periodeProduksi: string; // e.g. "Setiap Bulan" or "Musiman"
  statusUnggulan: boolean;
  keterangan: string;
  fotoUrl: string;
}

export interface PerangkatDesa {
  id: string;
  desaId: string;
  nama: string;
  jabatan: "Kepala Desa" | "Sekretaris Desa" | "Kasi Pemerintahan" | "Kasi Kesejahteraan" | "Kasi Pelayanan" | "Kaur Keuangan" | "Kaur Umum" | "Kepala Dusun" | "Ketua RT" | "Ketua RW";
  foto: string;
  kontak: string;
  alamat: string;
  masaJabatan: string; // e.g., "2021 - 2027"
  statusAktif: "Aktif" | "Nonaktif" | "Pindah" | "Meninggal" | "Habis Masa Jabatan" | "Diganti";
  jobDesk: string;
  riwayatJabatan: string[]; // History logs
}

export interface BeritaKegiatan {
  id: string;
  desaId: string;
  judul: string;
  konten: string;
  kategori: "Kabar Desa" | "Pembangunan" | "Pemberdayaan" | "Pertemuan" | "Pengumuman";
  tanggalPublikasi: string;
  statusPublikasi: "Draft" | "Terbit" | "Arsip" | "Perlu Diperbarui";
  fotoUrl: string;
}

export interface KalenderKegiatan {
  id: string;
  desaId: string;
  namaKegiatan: string;
  tanggal: string;
  lokasi: string;
  statusKegiatan: "Akan Datang" | "Berjalan" | "Selesai" | "Dibatalkan";
  keterangan: string;
}

export interface Pelapak {
  id: string;
  namaPelapak: string;
  noWhatsApp: string; // e.g. "6281234567890" for clean linking
  alamat: string;
  desaId: string;
  deskripsiUsia: string;
}

export interface ProdukLapak {
  id: string;
  desaId: string;
  pelapakId: string;
  namaProduk: string;
  kategori: "Makanan" | "Minuman" | "Pertanian" | "Kerajinan" | "Jasa" | "Hasil Perikanan" | "Hasil Peternakan" | "UMKM";
  harga: number;
  satuanJual: string; // e.g. "Buah", "Set", "Porsi", "Kg", "Pasang"
  stokStatus: "Tersedia" | "Terbatas" | "Kosong" | "Tidak Aktif";
  fotoUrl: string;
  deskripsi: string;
  isUnggulanKecamatan: boolean;
}

export interface AsetDesa {
  id: string;
  desaId: string;
  namaAset: string;
  kategoriAset: "Tanah Milik Desa" | "Bangunan Milik Desa" | "Inventaris Barang Desa";
  lokasiSpesifik: string;
  luasMeterPersegi?: number;
  statusKepemilikan: string; // e.g. "Sertifikat Pemdes", "Hibah", "Hak Guna Usaha"
  kondisi: "Aktif Digunakan" | "Rusak Ringan" | "Rusak Berat" | "Tidak Digunakan" | "Dipinjamkan" | "Disewakan" | "Perlu Update";
  koordinatLat?: number;
  koordinatLng?: number;
  penggunaanSaatIni: string; // e.g., "Kantor Desa", "Kebun Kas Desa", "Operasional"
  dokumenPendukungName: string; // file mockup name e.g. "Sertifikat_Tanah_No12.pdf"
  dokumenSize: string; // e.g., "2.4 MB"
}

export interface CatatKecamatan {
  id: string;
  desaId: string;
  pengirim: string; // Admin Kecamatan
  catatan: string;
  tanggal: string;
  isResolved: boolean;
}

export interface LogAktivitas {
  id: string;
  timestamp: string;
  user: string;
  role: string;
  desaImpacted?: string;
  aksi: string; // e.g., "Ubah Data Monografi", "Tambah Berita", "Ubah Status Aset"
  detail: string;
}

export type UserRole = "Camat/Admin Kecamatan" | "Operator Desa" | "Publik/Pengunjung";
