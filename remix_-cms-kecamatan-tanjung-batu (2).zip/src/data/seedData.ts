/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  Desa,
  MonografiKependudukan,
  MonografiSosialEkonomi,
  SaranaPrasarana,
  Komoditas,
  PerangkatDesa,
  BeritaKegiatan,
  KalenderKegiatan,
  Pelapak,
  ProdukLapak,
  AsetDesa,
  CatatKecamatan,
  LogAktivitas
} from "../types";

export const desaList: Desa[] = [
  {
    id: "desa-1",
    nama: "Purwodadi",
    kodeDesa: "16.08.15.2001",
    alamatKantor: "Jl. Poros Raya No. 12, RT 02, Desa Purwodadi",
    namaKepalaDesa: "Sudarmin, S.IP",
    fotoKades: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=200",
    kontakKantor: "0812-7345-XXXX",
    statusWeb: "Aktif",
    sejarahSingkat: "Desa Purwodadi secara historis dirintis sejak tahun 1980-an oleh para tokoh transmigrasi tangguh yang berikhtiar membangun lumbung beras unggulan swasembada pangan berkelanjutan di Kecamatan Belitang Mulya, Kabupaten OKU Timur.",
    luasWilayahHektar: 852,
    batasUtara: "Kecamatan Belitang",
    batasSelatan: "Desa Sariguna",
    batasTimur: "Desa Rejosari",
    batasBarat: "Desa Srimulyo",
    koordinatLat: -3.3420,
    koordinatLng: 104.6295,
    visi: "Terwujudnya Desa Purwodadi Sebagai Sentra Mandiri Swasembada Padi, Pertanian Modern Berkelanjutan, dan Gotong Royong OKU Timur.",
    misi: [
      "Meningkatkan mutu produksi padi organik melalui pelatihan teknologi pupuk hayati mandiri.",
      "Mengembangkan jalur irigasi teknis guna mengoptimalkan suplai air ke sawah-sawah warga.",
      "Melahirkan kelompok tani milenial yang mahir menerapkan teknologi pertanian cerdas (Smart Farming).",
      "Transparansi tata kelola dana desa untuk penguatan modal usaha bersama pelopor tani desa."
    ]
  },
  {
    id: "desa-2",
    nama: "Petanggan",
    kodeDesa: "16.08.15.2002",
    alamatKantor: "Jl. Poros Petanggan, RT 03 Dusun II",
    namaKepalaDesa: "Zulkifli, S.Sos",
    fotoKades: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&q=80&w=200",
    kontakKantor: "0821-6544-XXXX",
    statusWeb: "Aktif",
    sejarahSingkat: "Dikelilingi oleh aliran sungai irigasi sekunder yang jernih, Desa Petanggan berdiri kokoh sebagai surga agrowisata hortikultura buah naga dan melon dengan standarisasi kualitas ekspor.",
    luasWilayahHektar: 640,
    batasUtara: "Desa Purwodadi",
    batasSelatan: "Desa Sariguna",
    batasTimur: "Desa Srimulyo",
    batasBarat: "Kecamatan Belitang Jaya",
    koordinatLat: -3.3360,
    koordinatLng: 104.6130,
    visi: "Terwujudnya Petanggan Sebagai Desa Wisata Hortikultura Mandiri Sejahtera Berbasis Potensi Lokal dan Digitalisasi Pelayanan.",
    misi: [
      "Melestarikan ekosistem pengairan sawah dan kebun buah non-pestisida kimiawi.",
      "Menyediakan bimbingan pemasaran produk hilir agribisnis ke jaringan swalayan nasional.",
      "Meningkatkan akses kesehatan ibu anak terpadu dan ketersediaan ambulans siaga desa."
    ]
  },
  {
    id: "desa-3",
    nama: "Srimulyo",
    kodeDesa: "16.08.15.2003",
    alamatKantor: "Jl. Mayor Ruslan No. 44, RT 05 Dusun III, Desa Srimulyo",
    namaKepalaDesa: "H. Harun Al-Rasyid",
    fotoKades: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=200",
    kontakKantor: "0813-8991-XXXX",
    statusWeb: "Draft",
    sejarahSingkat: "Sebagai sentra anyaman rotan dan kerajinan bambu fungsional, Srimulyo menyuplai hampir 60 persen kebutuhan perabotan tradisional dan wadah hasil panen se-Kabupaten OKU Timur.",
    luasWilayahHektar: 550,
    batasUtara: "Desa Srimulyo",
    batasSelatan: "Desa Purwodadi",
    batasTimur: "Desa Sugih Waras",
    batasBarat: "Perkebunan Karet Rakyat",
    koordinatLat: -3.3510,
    koordinatLng: 104.6320,
    visi: "Modernisasi UMKM Kerajinan Serat Alam demi Kemandirian Ekonomi Pengrajin Desa Srimulyo.",
    misi: [
      "Memberikan bantuan alat pencacah bambu otomatis bagi kelompok pengrajin anyaman.",
      "Rehabilitasi infrastruktur parit pencegah genangan air saat curah hujan tinggi.",
      "Membentuk Koperasi Anyaman Kreatif Mandiri Penjamin Harga Pasar Pengrajin."
    ]
  },
  {
    id: "desa-4",
    nama: "Sugih Waras",
    kodeDesa: "16.08.15.2004",
    alamatKantor: "Jl. Datuk Sugih Waras No. 01, Desa Sugih Waras",
    namaKepalaDesa: "Hj. Ratna Dewita, M.Si",
    fotoKades: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=200",
    kontakKantor: "0811-9988-XXXX",
    statusWeb: "Perlu Diperbarui",
    sejarahSingkat: "Desa Sugih Waras dikaruniai tanah alluvial yang subur, menjadikannya penghasil jagung hibrida dan kedelai lokal bermutu prima penopang pakan ternak regional Belitang Mulya.",
    luasWilayahHektar: 1120,
    batasUtara: "Kecamatan Belitang",
    batasSelatan: "Desa Petanggan",
    batasTimur: "Desa Purwodadi",
    batasBarat: "Embung Irigasi Desa",
    koordinatLat: -3.3460,
    koordinatLng: 104.5980,
    visi: "Sugih Waras Lumbung Palawija Mandiri yang Adil, Makmur, dan Berkelanjutan.",
    misi: [
      "Mengoptimalkan sistem pascapanen jagung guna mengurangi kehilangan hasil pengeringan.",
      "Penyediaan bibit unggul berlabel bersertifikat gratis untuk para petani prasejahtera.",
      "Mengembangkan sanitasi sehat dan sistem pengelolaan limbah pupuk peternakan."
    ]
  },
  {
    id: "desa-5",
    nama: "Tulung Sari",
    kodeDesa: "16.08.15.2005",
    alamatKantor: "Jl. Raya Belitang-Simpang Km. 18, Desa Tulung Sari",
    namaKepalaDesa: "M. Yusuf Almansyur",
    fotoKades: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=200",
    kontakKantor: "0853-9002-XXXX",
    statusWeb: "Aktif",
    sejarahSingkat: "Desa Tulung Sari membentang luas di sepanjang poros aspal perekonomian Belitang Mulya. Berkat posisinya yang strategis, desa ini bertransformasi menjadi lokomotif penghasil olahan keripik pisang nan empuk dan anyaman bambu kreatif.",
    luasWilayahHektar: 980,
    batasUtara: "Desa Purwodadi",
    batasSelatan: "Desa Sariguna",
    batasTimur: "Kanal Irigasi Lempuing",
    batasBarat: "Kabupaten OKU Selatan",
    koordinatLat: -3.3450,
    koordinatLng: 104.6490,
    visi: "Tulung Sari Sentra Kuliner Palawija Kreatif yang Bersih, Edukatif, dan Dinamis.",
    misi: [
      "Menggandeng Dinas Koperasi UKM guna jaminan mutu usaha keripik rakyat.",
      "Mempercantik rest area jalur perlintasan lintas kabupaten OKU Timur.",
      "Digitalisasi laporan monografi penduduk menggunakan cloud terintegrasi."
    ]
  },
  {
    id: "desa-6",
    nama: "Mulya Sari",
    kodeDesa: "16.08.15.2006",
    alamatKantor: "Jl. Perintis Kemerdekaan Dusun IV, Desa Mulya Sari",
    namaKepalaDesa: "Baharuddin Umar",
    fotoKades: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&q=80&w=200",
    kontakKantor: "0812-7110-XXXX",
    statusWeb: "Belum Aktif",
    sejarahSingkat: "Dahulu dipenuhi peternakan sapi tradisional berskala kecil, wilayah berlereng landai di Desa Mulya Sari ini kini tumbuh mandiri sebagai perintis integrasi kebun kelapa sawit dan pakan ternak organik modern.",
    luasWilayahHektar: 1450,
    batasUtara: "Desa Sugih Waras",
    batasSelatan: "Kecamatan Madang Suku",
    batasTimur: "Sawah Lebak Tadah Hujan",
    batasBarat: "Desa Sariguna",
    koordinatLat: -3.3312,
    koordinatLng: 104.6241,
    visi: "Mewujudkan Mulya Sari Desa Sawit dan Ternak Terpadu Mandiri, Lestari Alamnya, Makmur Keluarganya.",
    misi: [
      "Mengawal kemitraan petani kelapa sawit mandiri dengan industri hilir CPO lokal.",
      "Mengembangkan embung desa terpadu penampung air pencegah kekeringan lahan perkebunan sawit.",
      "Menyediakan mobil ambulans gawat darurat desa 24 jam gratis."
    ]
  },
  {
    id: "desa-7",
    nama: "Rejosari",
    kodeDesa: "16.08.15.2007",
    alamatKantor: "Jl. Lapangan Merdeka RT 01, Desa Rejosari",
    namaKepalaDesa: "H. Sugeng Wardoyo",
    fotoKades: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=200",
    kontakKantor: "0812-7890-XXXX",
    statusWeb: "Aktif",
    sejarahSingkat: "Desa Rejosari dirintis pada tahun 1985 sebagai eks pemukiman transmigrasi yang berfokus pada pengembangan perkebunan karet alam and budidaya bibit kelapa sawit mandiri.",
    luasWilayahHektar: 780,
    batasUtara: "Desa Purwodadi",
    batasSelatan: "Desa Mulya Sari",
    batasTimur: "Desa Sugih Waras",
    batasBarat: "Kebun Karet Rakyat",
    koordinatLat: -3.3400,
    koordinatLng: 104.6100,
    visi: "Terwujudnya Rejosari Sebagai Desa Sejahtera Berbasis Perkebunan Karet Modern dan Kelestarian Lingkungan.",
    misi: [
      "Mengoptimalkan kualitas getah karet melalui penyuluhan metode lateks bersih.",
      "Pembangunan akses jalan sentra produksi kebun karet rakyat."
    ]
  },
  {
    id: "desa-8",
    nama: "Sariguna",
    kodeDesa: "16.08.15.2008",
    alamatKantor: "Jl. Raya Damai, RT 03, Desa Sariguna",
    namaKepalaDesa: "Nyoman Sukarja",
    fotoKades: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=200",
    kontakKantor: "0823-1122-XXXX",
    statusWeb: "Aktif",
    sejarahSingkat: "Sariguna menonjol dengan kerukunan antarumat beragama yang kuat serta geliat perkebunan jeruk manis hortikultura yang dikelola warga lokal secara produktif.",
    luasWilayahHektar: 820,
    batasUtara: "Desa Tulung Sari",
    batasSelatan: "Desa Sukoharjo",
    batasTimur: "Desa Srimulyo",
    batasBarat: "Kecamatan Belitang",
    koordinatLat: -3.3480,
    koordinatLng: 104.6120,
    visi: "Mewujudkan Sariguna Sentra Jeruk Manis dan Harmoni Keberagaman.",
    misi: [
      "Meningkatkan kapasitas budidaya jeruk organik tanpa pestisida kimia tinggi.",
      "Menyelenggarakan pagelaran seni lintas budaya tahunan desa."
    ]
  },
  {
    id: "desa-9",
    nama: "Sribudaya",
    kodeDesa: "16.08.15.2009",
    alamatKantor: "Jl. Veteran Dusun I, Desa Sribudaya",
    namaKepalaDesa: "Supriyadi, S.E.",
    fotoKades: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&q=80&w=200",
    kontakKantor: "0813-7744-XXXX",
    statusWeb: "Aktif",
    sejarahSingkat: "Sejak didirikan, Desa Sribudaya mengandalkan sektor sawah irigasi teknis yang subur dan peternakan kambing etawa skala rumah tangga sebagai pendorong ekonomi utama desa.",
    luasWilayahHektar: 690,
    batasUtara: "Desa Rejosari",
    batasSelatan: "Desa Sidowaloyo",
    batasTimur: "Desa Petanggan",
    batasBarat: "Saluran Irigasi Kanan",
    koordinatLat: -3.3640,
    koordinatLng: 104.6390,
    visi: "Sribudaya Berswasembada Padi Unggul dan Sentra Ternak Kambing Kreatif.",
    misi: [
      "Memperluas jangkauan irigasi teknis sawah berkerja sama dengan PU Pengairan.",
      "Membentuk kelompok peternak kambing mandiri berdaya saing tinggi."
    ]
  },
  {
    id: "desa-10",
    nama: "Sidowaloyo",
    kodeDesa: "16.08.15.2010",
    alamatKantor: "Jl. Poros Sidowaloyo No. 10, Desa Sidowaloyo",
    namaKepalaDesa: "Ahmad Rifa'i",
    fotoKades: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&q=80&w=200",
    kontakKantor: "0812-5566-XXXX",
    statusWeb: "Draft",
    sejarahSingkat: "Desa Sidowaloyo memiliki lumbung pangan palawija mandiri serta industri pengolahan anyaman bambu/rotan penopang lapangan kerja produktif bagi warga setempat.",
    luasWilayahHektar: 590,
    batasUtara: "Desa Sribudaya",
    batasSelatan: "Desa Sariguna",
    batasTimur: "Desa Ulak Buntar",
    batasBarat: "Hutan Rakyat",
    koordinatLat: -3.3550,
    koordinatLng: 104.5970,
    visi: "Sidowaloyo yang Sejahtera, Mandiri, dan Berbudaya Anyaman Lokal.",
    misi: [
      "Pelatihan digital marketing bagi produk kerajinan anyaman bambu warga.",
      "Sertifikasi bibit komoditas palawija unggul."
    ]
  },
  {
    id: "desa-11",
    nama: "Ulak Buntar",
    kodeDesa: "16.08.15.2011",
    alamatKantor: "Jl. Gajah Mada RT 02 Dusun II, Desa Ulak Buntar",
    namaKepalaDesa: "Ketut Suardika",
    fotoKades: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=200",
    kontakKantor: "0877-3344-XXXX",
    statusWeb: "Aktif",
    sejarahSingkat: "Ulak Buntar didirikan sebagai sentra perkebunan pisang kepok dan budi daya ikan tawar patin serta nila dengan ketersediaan embung kolam terintegrasi yang andal.",
    luasWilayahHektar: 730,
    batasUtara: "Desa Sidowaloyo",
    batasSelatan: "Desa Srimulyo",
    batasTimur: "Kanal Irigasi Sekunder",
    batasBarat: "Rawa Terbuka",
    koordinatLat: -3.3580,
    koordinatLng: 104.6460,
    visi: "Menjadikan Ulak Buntar Pelopor Perikanan Darat Makmur dan Agroindustri Pisang.",
    misi: [
      "Mengadakan balai benih ikan air tawar mandiri skala desa.",
      "Mendirikan UMKM pengolahan keripik pisang aneka rasa."
    ]
  },
  {
    id: "desa-12",
    nama: "Sukoharjo",
    kodeDesa: "16.08.15.2012",
    alamatKantor: "Jl. Pura Tri Buana, Desa Sukoharjo",
    namaKepalaDesa: "I Wayan Sudarta",
    fotoKades: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&q=80&w=200",
    kontakKantor: "0819-2244-XXXX",
    statusWeb: "Aktif",
    sejarahSingkat: "Sebagai desa adat dengan latar belakang kebudayaan transmigran yang kental, Desa Sukoharjo mengintegrasikan kesenian ukir, adat lokal, dan agrowisata kebun buah naga yang indah.",
    luasWilayahHektar: 520,
    batasUtara: "Desa Sariguna",
    batasSelatan: "Kecamatan Belitang",
    batasTimur: "Desa Tulung Sari",
    batasBarat: "Sawah Tadah Hujan",
    koordinatLat: -3.3680,
    koordinatLng: 104.6280,
    visi: "Sukoharjo Desa Wisata Budaya Lestari dan Agrowisata Mandiri Berkarakter.",
    misi: [
      "Meningkatkan sarana prasarana penunjang wisata budaya kearifan lokal.",
      "Optimalisasi kebun buah naga organik dalam sistem agrowisata terpadu."
    ]
  }
];

export const kependudukanList: MonografiKependudukan[] = [
  {
    desaId: "desa-1",
    jumlahPenduduk: 3420,
    jumlahKK: 852,
    jumlahLakiLaki: 1720,
    jumlahPerempuan: 1700,
    distribusiUsia: { balita: 412, anak: 540, remaja: 610, produktif: 1518, lansia: 340 },
    agama: { islam: 3420, kristen: 0, katolik: 0, hindu: 0, buddha: 0, konghucu: 0 }
  },
  {
    desaId: "desa-2",
    jumlahPenduduk: 2150,
    jumlahKK: 612,
    jumlahLakiLaki: 1040,
    jumlahPerempuan: 1110,
    distribusiUsia: { balita: 230, anak: 320, remaja: 410, produktif: 980, lansia: 210 },
    agama: { islam: 2145, kristen: 5, katolik: 0, hindu: 0, buddha: 0, konghucu: 0 }
  },
  {
    desaId: "desa-3",
    jumlahPenduduk: 1890,
    jumlahKK: 540,
    jumlahLakiLaki: 980,
    jumlahPerempuan: 910,
    distribusiUsia: { balita: 180, anak: 270, remaja: 310, produktif: 930, lansia: 200 },
    agama: { islam: 1890, kristen: 0, katolik: 0, hindu: 0, buddha: 0, konghucu: 0 }
  },
  {
    desaId: "desa-4",
    jumlahPenduduk: 4210,
    jumlahKK: 1130,
    jumlahLakiLaki: 2130,
    jumlahPerempuan: 2080,
    distribusiUsia: { balita: 510, anak: 690, remaja: 720, produktif: 1880, lansia: 410 },
    agama: { islam: 4208, kristen: 2, katolik: 0, hindu: 0, buddha: 0, konghucu: 0 }
  },
  {
    desaId: "desa-5",
    jumlahPenduduk: 2980,
    jumlahKK: 790,
    jumlahLakiLaki: 1470,
    jumlahPerempuan: 1510,
    distribusiUsia: { balita: 320, anak: 410, remaja: 480, produktif: 1450, lansia: 320 },
    agama: { islam: 2975, kristen: 3, katolik: 2, hindu: 0, buddha: 0, konghucu: 0 }
  },
  {
    desaId: "desa-6",
    jumlahPenduduk: 1750,
    jumlahKK: 490,
    jumlahLakiLaki: 890,
    jumlahPerempuan: 860,
    distribusiUsia: { balita: 190, anak: 260, remaja: 280, produktif: 820, lansia: 200 },
    agama: { islam: 1750, kristen: 0, katolik: 0, hindu: 0, buddha: 0, konghucu: 0 }
  },
  {
    desaId: "desa-7",
    jumlahPenduduk: 2450,
    jumlahKK: 680,
    jumlahLakiLaki: 1210,
    jumlahPerempuan: 1240,
    distribusiUsia: { balita: 210, anak: 350, remaja: 390, produktif: 1280, lansia: 220 },
    agama: { islam: 2450, kristen: 0, katolik: 0, hindu: 0, buddha: 0, konghucu: 0 }
  },
  {
    desaId: "desa-8",
    jumlahPenduduk: 3100,
    jumlahKK: 840,
    jumlahLakiLaki: 1540,
    jumlahPerempuan: 1560,
    distribusiUsia: { balita: 290, anak: 440, remaja: 510, produktif: 1530, lansia: 330 },
    agama: { islam: 3020, kristen: 10, katolik: 0, hindu: 70, buddha: 0, konghucu: 0 }
  },
  {
    desaId: "desa-9",
    jumlahPenduduk: 2250,
    jumlahKK: 610,
    jumlahLakiLaki: 1120,
    jumlahPerempuan: 1130,
    distribusiUsia: { balita: 190, anak: 310, remaja: 350, produktif: 1180, lansia: 220 },
    agama: { islam: 2250, kristen: 0, katolik: 0, hindu: 0, buddha: 0, konghucu: 0 }
  },
  {
    desaId: "desa-10",
    jumlahPenduduk: 1980,
    jumlahKK: 520,
    jumlahLakiLaki: 970,
    jumlahPerempuan: 1010,
    distribusiUsia: { balita: 160, anak: 280, remaja: 310, produktif: 1030, lansia: 200 },
    agama: { islam: 1980, kristen: 0, katolik: 0, hindu: 0, buddha: 0, konghucu: 0 }
  },
  {
    desaId: "desa-11",
    jumlahPenduduk: 2850,
    jumlahKK: 760,
    jumlahLakiLaki: 1410,
    jumlahPerempuan: 1440,
    distribusiUsia: { balita: 240, anak: 390, remaja: 450, produktif: 1470, lansia: 300 },
    agama: { islam: 2120, kristen: 5, katolik: 0, hindu: 725, buddha: 0, konghucu: 0 }
  },
  {
    desaId: "desa-12",
    jumlahPenduduk: 1650,
    jumlahKK: 430,
    jumlahLakiLaki: 810,
    jumlahPerempuan: 840,
    distribusiUsia: { balita: 140, anak: 210, remaja: 250, produktif: 850, lansia: 200 },
    agama: { islam: 210, kristen: 0, katolik: 0, hindu: 1440, buddha: 0, konghucu: 0 }
  }
];

export const sosialEkonomiList: MonografiSosialEkonomi[] = [
  {
    desaId: "desa-1",
    pekerjaan: {
      petaniKaret: 120,
      petaniNanas: 45,
      pengrajinTenun: 15,
      tukangKayuPanggung: 420,
      pedagang: 180,
      pnsTniPolri: 65,
      buruh: 230,
      lainnya: 443
    },
    pendidikan: { tidakSekolah: 82, sd: 540, smp: 780, sma: 1120, diplomaSarjana: 216 },
    jumlahDusun: 4,
    jumlahNakes: 3
  },
  {
    desaId: "desa-2",
    pekerjaan: {
      petaniKaret: 230,
      petaniNanas: 12,
      pengrajinTenun: 380,
      tukangKayuPanggung: 10,
      pedagang: 95,
      pnsTniPolri: 32,
      buruh: 120,
      lainnya: 101
    },
    pendidikan: { tidakSekolah: 110, sd: 412, smp: 530, sma: 820, diplomaSarjana: 96 },
    jumlahDusun: 3,
    jumlahNakes: 2
  },
  {
    desaId: "desa-3",
    pekerjaan: {
      petaniKaret: 190,
      petaniNanas: 8,
      pengrajinTenun: 22,
      tukangKayuPanggung: 5,
      pedagang: 110,
      pnsTniPolri: 28,
      buruh: 340, // Banyak buruh pandai logam
      lainnya: 207
    },
    pendidikan: { tidakSekolah: 95, sd: 390, smp: 480, sma: 650, diplomaSarjana: 72 },
    jumlahDusun: 3,
    jumlahNakes: 2
  },
  {
    desaId: "desa-4",
    pekerjaan: {
      petaniKaret: 850,
      petaniNanas: 620,
      pengrajinTenun: 4,
      tukangKayuPanggung: 8,
      pedagang: 140,
      pnsTniPolri: 75,
      buruh: 290,
      lainnya: 183
    },
    pendidikan: { tidakSekolah: 150, sd: 910, smp: 1180, sma: 1350, diplomaSarjana: 280 },
    jumlahDusun: 6,
    jumlahNakes: 4
  },
  {
    desaId: "desa-5",
    pekerjaan: {
      petaniKaret: 140,
      petaniNanas: 32,
      pengrajinTenun: 85,
      tukangKayuPanggung: 24,
      pedagang: 380, // Pedagang kemplang panggang dan kuliner
      pnsTniPolri: 61,
      buruh: 150,
      lainnya: 218
    },
    pendidikan: { tidakSekolah: 75, sd: 480, smp: 690, sma: 1010, diplomaSarjana: 185 },
    jumlahDusun: 5,
    jumlahNakes: 3
  },
  {
    desaId: "desa-6",
    pekerjaan: {
      petaniKaret: 220,
      petaniNanas: 18,
      pengrajinTenun: 3,
      tukangKayuPanggung: 2,
      pedagang: 45,
      pnsTniPolri: 19,
      buruh: 420, // Buruh kelapa sawit
      lainnya: 133
    },
    pendidikan: { tidakSekolah: 140, sd: 410, smp: 520, sma: 430, diplomaSarjana: 50 },
    jumlahDusun: 4,
    jumlahNakes: 1
  },
  {
    desaId: "desa-7",
    pekerjaan: {
      petaniKaret: 340,
      petaniNanas: 13,
      pengrajinTenun: 5,
      tukangKayuPanggung: 8,
      pedagang: 110,
      pnsTniPolri: 41,
      buruh: 260,
      lainnya: 193
    },
    pendidikan: { tidakSekolah: 80, sd: 350, smp: 480, sma: 710, diplomaSarjana: 120 },
    jumlahDusun: 4,
    jumlahNakes: 2
  },
  {
    desaId: "desa-8",
    pekerjaan: {
      petaniKaret: 110,
      petaniNanas: 8,
      pengrajinTenun: 12,
      tukangKayuPanggung: 4,
      pedagang: 240,
      pnsTniPolri: 52,
      buruh: 410,
      lainnya: 232
    },
    pendidikan: { tidakSekolah: 110, sd: 540, smp: 690, sma: 910, diplomaSarjana: 154 },
    jumlahDusun: 5,
    jumlahNakes: 3
  },
  {
    desaId: "desa-9",
    pekerjaan: {
      petaniKaret: 412,
      petaniNanas: 5,
      pengrajinTenun: 2,
      tukangKayuPanggung: 10,
      pedagang: 90,
      pnsTniPolri: 29,
      buruh: 180,
      lainnya: 142
    },
    pendidikan: { tidakSekolah: 90, sd: 390, smp: 460, sma: 620, diplomaSarjana: 95 },
    jumlahDusun: 3,
    jumlahNakes: 2
  },
  {
    desaId: "desa-10",
    pekerjaan: {
      petaniKaret: 150,
      petaniNanas: 12,
      pengrajinTenun: 140,
      tukangKayuPanggung: 15,
      pedagang: 95,
      pnsTniPolri: 21,
      buruh: 110,
      lainnya: 117
    },
    pendidikan: { tidakSekolah: 70, sd: 320, smp: 410, sma: 580, diplomaSarjana: 83 },
    jumlahDusun: 3,
    jumlahNakes: 1
  },
  {
    desaId: "desa-11",
    pekerjaan: {
      petaniKaret: 210,
      petaniNanas: 14,
      pengrajinTenun: 24,
      tukangKayuPanggung: 4,
      pedagang: 195,
      pnsTniPolri: 43,
      buruh: 310,
      lainnya: 184
    },
    pendidikan: { tidakSekolah: 105, sd: 460, smp: 590, sma: 820, diplomaSarjana: 132 },
    jumlahDusun: 4,
    jumlahNakes: 3
  },
  {
    desaId: "desa-12",
    pekerjaan: {
      petaniKaret: 190,
      petaniNanas: 2,
      pengrajinTenun: 110,
      tukangKayuPanggung: 8,
      pedagang: 80,
      pnsTniPolri: 18,
      buruh: 150,
      lainnya: 102
    },
    pendidikan: { tidakSekolah: 65, sd: 280, smp: 390, sma: 510, diplomaSarjana: 72 },
    jumlahDusun: 3,
    jumlahNakes: 2
  }
];

export const saranaPrasaranaList: SaranaPrasarana[] = [
  {
    desaId: "desa-1",
    sekolah: { sd: 2, smp: 1, sma: 1, paud: 2 },
    fasilitasKesehatan: { puskesmasPustu: 1, posyandu: 4, bidanPraktek: 2 },
    tempatIbadah: { masjid: 3, mushola: 6, gereja: 0 },
    panjangJalanKm: 12.5,
    jumlahJembatan: 4,
    pasarDesa: 1,
    balaiDesa: true
  },
  {
    desaId: "desa-2",
    sekolah: { sd: 1, smp: 0, sma: 0, paud: 1 },
    fasilitasKesehatan: { puskesmasPustu: 0, posyandu: 2, bidanPraktek: 2 },
    tempatIbadah: { masjid: 2, mushola: 4, gereja: 0 },
    panjangJalanKm: 8.2,
    jumlahJembatan: 2,
    pasarDesa: 0,
    balaiDesa: true
  },
  {
    desaId: "desa-3",
    sekolah: { sd: 1, smp: 1, sma: 0, paud: 1 },
    fasilitasKesehatan: { puskesmasPustu: 0, posyandu: 2, bidanPraktek: 1 },
    tempatIbadah: { masjid: 1, mushola: 3, gereja: 0 },
    panjangJalanKm: 6.8,
    jumlahJembatan: 1,
    pasarDesa: 0,
    balaiDesa: true
  },
  {
    desaId: "desa-4",
    sekolah: { sd: 3, smp: 1, sma: 0, paud: 3 },
    fasilitasKesehatan: { puskesmasPustu: 1, posyandu: 5, bidanPraktek: 3 },
    tempatIbadah: { masjid: 4, mushola: 9, gereja: 0 },
    panjangJalanKm: 18.2,
    jumlahJembatan: 5,
    pasarDesa: 1,
    balaiDesa: true
  },
  {
    desaId: "desa-5",
    sekolah: { sd: 2, smp: 0, sma: 0, paud: 2 },
    fasilitasKesehatan: { puskesmasPustu: 1, posyandu: 3, bidanPraktek: 2 },
    tempatIbadah: { masjid: 3, mushola: 5, gereja: 0 },
    panjangJalanKm: 14.0,
    jumlahJembatan: 3,
    pasarDesa: 1,
    balaiDesa: true
  },
  {
    desaId: "desa-6",
    sekolah: { sd: 1, smp: 0, sma: 0, paud: 1 },
    fasilitasKesehatan: { puskesmasPustu: 0, posyandu: 2, bidanPraktek: 1 },
    tempatIbadah: { masjid: 1, mushola: 2, gereja: 0 },
    panjangJalanKm: 11.4,
    jumlahJembatan: 2,
    pasarDesa: 0,
    balaiDesa: false
  },
  {
    desaId: "desa-7",
    sekolah: { sd: 1, smp: 0, sma: 0, paud: 2 },
    fasilitasKesehatan: { puskesmasPustu: 0, posyandu: 3, bidanPraktek: 1 },
    tempatIbadah: { masjid: 2, mushola: 4, gereja: 0 },
    panjangJalanKm: 12.0,
    jumlahJembatan: 2,
    pasarDesa: 0,
    balaiDesa: true
  },
  {
    desaId: "desa-8",
    sekolah: { sd: 2, smp: 1, sma: 1, paud: 2 },
    fasilitasKesehatan: { puskesmasPustu: 1, posyandu: 4, bidanPraktek: 2 },
    tempatIbadah: { masjid: 2, mushola: 3, gereja: 1 },
    panjangJalanKm: 10.5,
    jumlahJembatan: 3,
    pasarDesa: 1,
    balaiDesa: true
  },
  {
    desaId: "desa-9",
    sekolah: { sd: 1, smp: 0, sma: 0, paud: 1 },
    fasilitasKesehatan: { puskesmasPustu: 0, posyandu: 2, bidanPraktek: 1 },
    tempatIbadah: { masjid: 1, mushola: 4, gereja: 0 },
    panjangJalanKm: 8.5,
    jumlahJembatan: 1,
    pasarDesa: 0,
    balaiDesa: true
  },
  {
    desaId: "desa-10",
    sekolah: { sd: 1, smp: 1, sma: 0, paud: 1 },
    fasilitasKesehatan: { puskesmasPustu: 0, posyandu: 2, bidanPraktek: 1 },
    tempatIbadah: { masjid: 2, mushola: 3, gereja: 0 },
    panjangJalanKm: 7.2,
    jumlahJembatan: 1,
    pasarDesa: 0,
    balaiDesa: true
  },
  {
    desaId: "desa-11",
    sekolah: { sd: 2, smp: 0, sma: 0, paud: 2 },
    fasilitasKesehatan: { puskesmasPustu: 0, posyandu: 3, bidanPraktek: 2 },
    tempatIbadah: { masjid: 3, mushola: 5, gereja: 0 },
    panjangJalanKm: 11.0,
    jumlahJembatan: 2,
    pasarDesa: 0,
    balaiDesa: true
  },
  {
    desaId: "desa-12",
    sekolah: { sd: 1, smp: 0, sma: 0, paud: 1 },
    fasilitasKesehatan: { puskesmasPustu: 0, posyandu: 2, bidanPraktek: 1 },
    tempatIbadah: { masjid: 1, mushola: 2, gereja: 0 },
    panjangJalanKm: 6.8,
    jumlahJembatan: 1,
    pasarDesa: 0,
    balaiDesa: true
  }
];

export const komoditasList: Komoditas[] = [
  {
    id: "kom-1",
    desaId: "desa-1",
    namaKomoditas: "Beras Organik Premium Belitang",
    kategori: "Pertanian",
    estimasiProduksiTahunan: "3.500 Ton / Tahun",
    luasLahanHektarOrUnit: "852 Hektar Sawah",
    periodeProduksi: "Dua Kali Setahun",
    statusUnggulan: true,
    keterangan: "Beras organik premium khas Belitang OKU Timur yang dibudidayakan secara alami tanpa residu kimiawi berbahaya. Terkenal pulen, wangi, dan menyehatkan.",
    fotoUrl: "https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?auto=format&fit=crop&q=80&w=600"
  },
  {
    id: "kom-2",
    desaId: "desa-2",
    namaKomoditas: "Buah Naga Merah & Melon Super",
    kategori: "Pertanian",
    estimasiProduksiTahunan: "120 Ton / Tahun",
    luasLahanHektarOrUnit: "150 Hektar Kebun",
    periodeProduksi: "Setiap Minggu",
    statusUnggulan: true,
    keterangan: "Buah naga merah segar dan melon varietas unggul yang dipasarkan di agrowisata terpadu Desa Srimulyo dengan rasa manis pekat rasa premium.",
    fotoUrl: "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&q=80&w=600"
  },
  {
    id: "kom-3",
    desaId: "desa-3",
    namaKomoditas: "Kerajinan Anyaman Bambu Kreatif",
    kategori: "UMKM Kerajinan",
    estimasiProduksiTahunan: "15.000 Unit / Tahun",
    luasLahanHektarOrUnit: "85 Pengrajin Aktif",
    periodeProduksi: "Setiap Hari",
    statusUnggulan: true,
    keterangan: "Hasil kerajinan fungsional perabot rumah tangga, wadah panen, dan tas anyaman eksklusif berbahan premium bambu serat alam khas Sariguna.",
    fotoUrl: "https://images.unsplash.com/photo-1544816155-12df9643f363?auto=format&fit=crop&q=80&w=600"
  },
  {
    id: "kom-4",
    desaId: "desa-4",
    namaKomoditas: "Jagung Hibrida Unggul Nusantara",
    kategori: "Pertanian",
    estimasiProduksiTahunan: "4.800 Ton / Tahun",
    luasLahanHektarOrUnit: "1.120 Hektar",
    periodeProduksi: "Tiga Bulan Sekali",
    statusUnggulan: true,
    keterangan: "Jagung manis hibrida berkualitas andalan petani Desa Sidomulyo sebagai pilar bahan pakan ternak dan konsumsi pangan regional Sumatera Selatan.",
    fotoUrl: "https://images.unsplash.com/photo-1551754655-cd27e38d2076?auto=format&fit=crop&q=80&w=600"
  },
  {
    id: "kom-5",
    desaId: "desa-4",
    namaKomoditas: "Kedelai Hitam & Hijau Organik",
    kategori: "Pertanian",
    estimasiProduksiTahunan: "250 Ton / Tahun",
    luasLahanHektarOrUnit: "110 Hektar",
    periodeProduksi: "Musiman",
    statusUnggulan: false,
    keterangan: "Komoditas tumpang sari kedelai organik penyuplai industri kecap dan tahu-tempe higienis se-Kabupaten OKU Timur.",
    fotoUrl: "https://images.unsplash.com/photo-1523348837708-15d4a09cfac2?auto=format&fit=crop&q=80&w=600"
  },
  {
    id: "kom-6",
    desaId: "desa-5",
    namaKomoditas: "Olahan Keripik Pisang Renyah",
    kategori: "Industri Rumah Tangga",
    estimasiProduksiTahunan: "18 Ton / Tahun",
    luasLahanHektarOrUnit: "65 Pelaku UMKM",
    periodeProduksi: "Setiap Hari",
    statusUnggulan: true,
    keterangan: "Produk olahan makanan ringan berbahan pisang tanduk berbalut karamel manis kental dan varian gurih khas dari Desa Purwodadi.",
    fotoUrl: "https://images.unsplash.com/photo-1582979512210-99b6a53386f9?auto=format&fit=crop&q=80&w=600"
  },
  {
    id: "kom-7",
    desaId: "desa-6",
    namaKomoditas: "Tandan Buah Segar (TBS) Kelapa Sawit",
    kategori: "Perkebunan",
    estimasiProduksiTahunan: "4.200 Ton / Tahun",
    luasLahanHektarOrUnit: "1.450 Hektar Plasma",
    periodeProduksi: "Dua Mingguan",
    statusUnggulan: false,
    keterangan: "Hasil kelapa sawit rakyat mandiri bersertifikat ISPO yang dikelola terintegrasi dengan balai penampungan CPO lokal.",
    fotoUrl: "https://images.unsplash.com/photo-1590004953392-5aba2e72269a?auto=format&fit=crop&q=80&w=600"
  },
  {
    id: "kom-8",
    desaId: "desa-2",
    namaKomoditas: "Beras Pandan Wangi Petanggan",
    kategori: "Pertanian",
    estimasiProduksiTahunan: "2.100 Ton / Tahun",
    luasLahanHektarOrUnit: "540 Hektar Sawah",
    periodeProduksi: "Dua Kali Setahun",
    statusUnggulan: true,
    keterangan: "Beras pandan wangi aromatik alami unggulan pertanian Desa Petanggan yang pulen dan memiliki keharuman pandan alami khas daerah aliran sungai irigasi.",
    fotoUrl: "https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?auto=format&fit=crop&q=80&w=600"
  },
  {
    id: "kom-9",
    desaId: "desa-3",
    namaKomoditas: "Beras IR64 Sentosa Srimulyo",
    kategori: "Pertanian",
    estimasiProduksiTahunan: "1.800 Ton / Tahun",
    luasLahanHektarOrUnit: "420 Hektar Sawah",
    periodeProduksi: "Dua Kali Setahun",
    statusUnggulan: true,
    keterangan: "Beras tangguh IR64 dari Srimulyo yang sangat bersaing secara ekonomi karena indeks rendemen tinggi dan tekstur nasi yang empuk serta pulen.",
    fotoUrl: "https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?auto=format&fit=crop&q=80&w=600"
  },
  {
    id: "kom-10",
    desaId: "desa-4",
    namaKomoditas: "Beras Ketan Putih Sugih Waras",
    kategori: "Pertanian",
    estimasiProduksiTahunan: "950 Ton / Tahun",
    luasLahanHektarOrUnit: "220 Hektar Sawah",
    periodeProduksi: "Satu Kali Setahun",
    statusUnggulan: false,
    keterangan: "Beras ketan putih super lengket bertekstur premium dari Sugih Waras, sangat diminati oleh industri pembuatan kue tradisional dan kuliner daerah Sumatra Selatan.",
    fotoUrl: "https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?auto=format&fit=crop&q=80&w=600"
  },
  {
    id: "kom-11",
    desaId: "desa-5",
    namaKomoditas: "Beras Merah Sehat Tulung Sari",
    kategori: "Pertanian",
    estimasiProduksiTahunan: "1.200 Ton / Tahun",
    luasLahanHektarOrUnit: "310 Hektar Sawah",
    periodeProduksi: "Dua Kali Setahun",
    statusUnggulan: true,
    keterangan: "Beras merah organik rendah glikemik indeks tinggi serat dari Tulung Sari untuk mendukung gaya hidup sehat perkotaan dan penderita diabetes.",
    fotoUrl: "https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?auto=format&fit=crop&q=80&w=600"
  },
  {
    id: "kom-12",
    desaId: "desa-6",
    namaKomoditas: "Beras Cianjur Mulya Sari",
    kategori: "Pertanian",
    estimasiProduksiTahunan: "1.500 Ton / Tahun",
    luasLahanHektarOrUnit: "380 Hektar Sawah",
    periodeProduksi: "Dua Kali Setahun",
    statusUnggulan: true,
    keterangan: "Beras varietas khusus Cianjur yang sukses dibudidayakan di ekosistem subur Desa Mulya Sari dengan rasa manis, pulen, dan kadar amilosa yang ideal.",
    fotoUrl: "https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?auto=format&fit=crop&q=80&w=600"
  },
  {
    id: "kom-13",
    desaId: "desa-7",
    namaKomoditas: "Beras Padi Gogo Rejosari",
    kategori: "Pertanian",
    estimasiProduksiTahunan: "800 Ton / Tahun",
    luasLahanHektarOrUnit: "180 Hektar",
    periodeProduksi: "Satu Kali Setahun",
    statusUnggulan: false,
    keterangan: "Beras hasil budidaya tadah hujan padi gogo di lereng kering Rejosari yang tangguh kekeringan dan memiliki cita rasa nasi yang khas.",
    fotoUrl: "https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?auto=format&fit=crop&q=80&w=600"
  },
  {
    id: "kom-14",
    desaId: "desa-8",
    namaKomoditas: "Beras Jasmine Wangi Sariguna",
    kategori: "Pertanian",
    estimasiProduksiTahunan: "1.900 Ton / Tahun",
    luasLahanHektarOrUnit: "450 Hektar Sawah",
    periodeProduksi: "Dua Kali Setahun",
    statusUnggulan: true,
    keterangan: "Beras jasmine beraroma eksotis yang pulen tinggi dari Sariguna, dibudidayakan dengan pengairan teknis modern terintegrasi.",
    fotoUrl: "https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?auto=format&fit=crop&q=80&w=600"
  },
  {
    id: "kom-15",
    desaId: "desa-9",
    namaKomoditas: "Beras Premium Sribudaya",
    kategori: "Pertanian",
    estimasiProduksiTahunan: "2.400 Ton / Tahun",
    luasLahanHektarOrUnit: "550 Hektar Sawah",
    periodeProduksi: "Dua Kali Setahun",
    statusUnggulan: true,
    keterangan: "Beras kualitas premium Sribudaya super putih bersih dengan tingkat kepulenaan tinggi idaman para ibu rumah tangga perkotaan Sumatera Selatan.",
    fotoUrl: "https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?auto=format&fit=crop&q=80&w=600"
  },
  {
    id: "kom-16",
    desaId: "desa-10",
    namaKomoditas: "Beras Mentik Susu Sidowaloyo",
    kategori: "Pertanian",
    estimasiProduksiTahunan: "1.100 Ton / Tahun",
    luasLahanHektarOrUnit: "280 Hektar Sawah",
    periodeProduksi: "Dua Kali Setahun",
    statusUnggulan: true,
    keterangan: "Beras mentik susu Sidowaloyo yang terkenal sangat pulen menyerupai beras ketan beraroma susu segar alami.",
    fotoUrl: "https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?auto=format&fit=crop&q=80&w=600"
  },
  {
    id: "kom-17",
    desaId: "desa-11",
    namaKomoditas: "Beras Basmati Lokal Ulak Buntar",
    kategori: "Pertanian",
    estimasiProduksiTahunan: "700 Ton / Tahun",
    luasLahanHektarOrUnit: "170 Hektar Sawah",
    periodeProduksi: "Setiap Tahun",
    statusUnggulan: false,
    keterangan: "Varietas beras basmati berbulir panjang yang berhasil dibudidayakan secara lokal di Ulak Buntar dengan indeks glikemik sangat rendah cocok bagi program diet.",
    fotoUrl: "https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?auto=format&fit=crop&q=80&w=600"
  },
  {
    id: "kom-18",
    desaId: "desa-12",
    namaKomoditas: "Beras Ciherang Unggul Sukoharjo",
    kategori: "Pertanian",
    estimasiProduksiTahunan: "2.200 Ton / Tahun",
    luasLahanHektarOrUnit: "480 Hektar Sawah",
    periodeProduksi: "Dua Kali Setahun",
    statusUnggulan: true,
    keterangan: "Beras varietas unggul Ciherang dari Sukoharjo yang dikenal tahan hama penyakit dan memproduksi rasa nasi yang sangat berselera tinggi.",
    fotoUrl: "https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?auto=format&fit=crop&q=80&w=600"
  }
];

export const perangkatList: PerangkatDesa[] = [
  {
    id: "per-1",
    desaId: "desa-1",
    nama: "Sudarmin, S.IP",
    jabatan: "Kepala Desa",
    foto: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=200",
    kontak: "0812-7345-XXXX",
    alamat: "RT 02 Dusun I, Desa Purwodadi",
    masaJabatan: "2021 - 2027",
    statusAktif: "Aktif",
    jobDesk: "Memimpin penyelenggaraan pemerintahan desa, membina ketertiban masyarakat, dan menetapkan Peraturan Desa bersama BPD.",
    riwayatJabatan: ["Dilantik Kades Terpilih Pilkades Serentak OKU Timur 2021", "Mantan Bendahara Desa (2015-2021)"]
  },
  {
    id: "per-2",
    desaId: "desa-1",
    nama: "Supriyanto, A.Md",
    jabatan: "Sekretaris Desa",
    foto: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&q=80&w=200",
    kontak: "0813-2211-XXXX",
    alamat: "RT 01 Dusun I, Desa Purwodadi",
    masaJabatan: "2021 - 2027",
    statusAktif: "Aktif",
    jobDesk: "Mengoordinasikan sekretariat desa, mengelola administrasi surat, kearsipan, dan menyusun laporan pertanggungjawaban APBDesa.",
    riwayatJabatan: ["Diangkat PNS Sekdes Kab. OKU Timur 2021"]
  },
  {
    id: "per-3",
    desaId: "desa-2",
    nama: "Zulkifli, S.Sos",
    jabatan: "Kepala Desa",
    foto: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&q=80&w=200",
    kontak: "0821-6544-XXXX",
    alamat: "Dusun II, Srimulyo",
    masaJabatan: "2020 - 2026",
    statusAktif: "Aktif",
    jobDesk: "Menyelenggarakan penanganan ekonomi inklusif rakyat dan memperkuat paguyuban kelompok hortikultura buah unggulan.",
    riwayatJabatan: ["Dilantik Bupati OKU Timur Desember 2020"]
  },
  {
    id: "per-4",
    desaId: "desa-2",
    nama: "Fatimah Az-Zahra",
    jabatan: "Kaur Keuangan",
    foto: "https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&q=80&w=200",
    kontak: "0852-7890-XXXX",
    alamat: "Dusun III, Srimulyo",
    masaJabatan: "2020 - 2026",
    statusAktif: "Aktif",
    jobDesk: "Mengelola arus kas masuk dan keluar desa, menjurnalkan transaksi, mengeluarkan kuitansi anggaran dan pajak daerah.",
    riwayatJabatan: ["Lulus Seleksi Perangkat Desa Formasi Keuangan 2020"]
  },
  {
    id: "per-5",
    desaId: "desa-3",
    nama: "H. Harun Al-Rasyid",
    jabatan: "Kepala Desa",
    foto: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=200",
    kontak: "0813-8991-XXXX",
    alamat: "RT 05 Dusun III, Sariguna",
    masaJabatan: "2020 - 2026",
    statusAktif: "Aktif",
    jobDesk: "Mengoordinasi program UMKM dan kerajinan anyaman rotan bambu fungsional desa.",
    riwayatJabatan: ["Kades Terpilih Pilkades Sariguna 2020"]
  },
  {
    id: "per-6",
    desaId: "desa-4",
    nama: "Hj. Ratna Dewita, M.Si",
    jabatan: "Kepala Desa",
    foto: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=200",
    kontak: "0811-9988-XXXX",
    alamat: "Dusun I, Sidomulyo",
    masaJabatan: "2022 - 2028",
    statusAktif: "Aktif",
    jobDesk: "Mengembangkan program swasembada pangan palawija jagung hibrida skala kabupaten.",
    riwayatJabatan: ["Pelantikan Kades Sidomulyo Periode II 2022"]
  },
  {
    id: "per-7",
    desaId: "desa-5",
    nama: "M. Yusuf Almansyur",
    jabatan: "Kepala Desa",
    foto: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=200",
    kontak: "0853-9002-XXXX",
    alamat: "Jl. Poros Belitang, Purwodadi",
    masaJabatan: "2021 - 2027",
    statusAktif: "Aktif",
    jobDesk: "Mengelola pelayanan administrasi warga, merintis sentra kuliner keripik pisang dan anyaman desa.",
    riwayatJabatan: ["Pemenang Pilkades Purwodadi 2021"]
  },
  {
    id: "per-8",
    desaId: "desa-6",
    nama: "Baharuddin Umar",
    jabatan: "Kepala Desa",
    foto: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&q=80&w=200",
    kontak: "0812-7110-XXXX",
    alamat: "Dusun IV, Petanggan",
    masaJabatan: "2020 - 2026",
    statusAktif: "Aktif",
    jobDesk: "Membina dan mengawal tata kelola kemitraan plasma perkebunan kelapa sawit rakyat mandiri.",
    riwayatJabatan: ["Dilantik Kades Petanggan 2020"]
  },
  {
    id: "per-9",
    desaId: "desa-7",
    nama: "H. Sugeng Wardoyo",
    jabatan: "Kepala Desa",
    foto: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=200",
    kontak: "0812-7890-XXXX",
    alamat: "RT 01, Bumi Jaya",
    masaJabatan: "2021 - 2027",
    statusAktif: "Aktif",
    jobDesk: "Memimpin pembinaan kelompok tani perkebunan karet alam kotor bersih di Bumi Jaya.",
    riwayatJabatan: ["Purnawirawan POLRI, Terpilih Kades 2021"]
  },
  {
    id: "per-10",
    desaId: "desa-8",
    nama: "Nyoman Sukarja",
    jabatan: "Kepala Desa",
    foto: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=200",
    kontak: "0823-1122-XXXX",
    alamat: "RT 03, Karang Manik",
    masaJabatan: "2021 - 2027",
    statusAktif: "Aktif",
    jobDesk: "Mengembangkan jalur distribusi jeruk manis hortikultura Karang Manik.",
    riwayatJabatan: ["Dilantik Bupati OKU Timur 2021"]
  },
  {
    id: "per-11",
    desaId: "desa-9",
    nama: "Supriyadi, S.E.",
    jabatan: "Kepala Desa",
    foto: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&q=80&w=200",
    kontak: "0813-7744-XXXX",
    alamat: "Dusun I, Rejosari",
    masaJabatan: "2020 - 2026",
    statusAktif: "Aktif",
    jobDesk: "Mendorong ketahanan swasembada padi dan pemberdayaan peternak etawa Rejosari.",
    riwayatJabatan: ["Sarjana Ekonomi, Terpilih Kades Rejosari 2020"]
  },
  {
    id: "per-12",
    desaId: "desa-10",
    nama: "Ahmad Rifa'i",
    jabatan: "Kepala Desa",
    foto: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&q=80&w=200",
    kontak: "0812-5566-XXXX",
    alamat: "Dusun II, Sugih Waras",
    masaJabatan: "2022 - 2028",
    statusAktif: "Aktif",
    jobDesk: "Memfasilitasi pengadaan bahan baku bambu serat alam dan pembinaan pengerajin anyaman.",
    riwayatJabatan: ["Praktisi Industri Kerajinan, Dilantik Kades 2022"]
  },
  {
    id: "per-13",
    desaId: "desa-11",
    nama: "Ketut Suardika",
    jabatan: "Kepala Desa",
    foto: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=200",
    kontak: "0877-3344-XXXX",
    alamat: "RT 02 Dusun II, Suryajaya",
    masaJabatan: "2021 - 2027",
    statusAktif: "Aktif",
    jobDesk: "Mengoordinasi budi daya hortikultura pisang kepok dan budi daya mina tawar patin.",
    riwayatJabatan: ["Lulusan Unila, Kades Terpilih Suryajaya 2021"]
  },
  {
    id: "per-14",
    desaId: "desa-12",
    nama: "I Wayan Sudarta",
    jabatan: "Kepala Desa",
    foto: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&q=80&w=200",
    kontak: "0819-2244-XXXX",
    alamat: "Dusun Utama Sukoharjo",
    masaJabatan: "2020 - 2026",
    statusAktif: "Aktif",
    jobDesk: "Mengkonsolidasikan agenda adat kesenian ukir dan wisata religi kebun buah naga di Sukoharjo.",
    riwayatJabatan: ["Tokoh Adat Sukoharjo, Dilantik Kades 2020"]
  }
];

export const beritaList: BeritaKegiatan[] = [
  {
    id: "ber-1",
    desaId: "desa-1",
    judul: "Ekspor Beras Organik Premium Purwodadi Tembus Pasar Swalayan Jakarta",
    konten: "Sebanyak 15 ton beras organik bebas residu kimiawi buatan Gapoktan Purwodadi resmi dilepas keberangkatannya menuju distributor besar di Jakarta. Beras unggulan OKU Timur ini diproduksi menggunakan metode pemupukan hayati terintegrasi yang ramah lingkungan.",
    kategori: "Pemberdayaan",
    tanggalPublikasi: "2026-06-15",
    statusPublikasi: "Terbit",
    fotoUrl: "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&q=80&w=600"
  },
  {
    id: "ber-2",
    desaId: "desa-2",
    judul: "Pelatihan Olahan Ekstrak Buah naga Agro Eco-Premium bagi Pemuda",
    konten: "Pemerintah Desa Petanggan menggelar pelatihan hulu-hilir mengolah ekstrak kulit buah naga dan sirup olahan alami guna menciptakan produk berdaya saing tinggi bernilai tambah untuk menaikkan kesejahteraan petani lokal.",
    kategori: "Pemberdayaan",
    tanggalPublikasi: "2026-06-18",
    statusPublikasi: "Terbit",
    fotoUrl: "https://images.unsplash.com/photo-1544816155-12df9643f363?auto=format&fit=crop&q=80&w=600"
  },
  {
    id: "ber-3",
    desaId: "desa-4",
    judul: "Dampak Kemarau Ekstrem, Petani Palawija Sugih Waras Optimalkan Pompa Pengairan Irigasi",
    konten: "Menyusul penurunan debit air, para petani jagung hibrida Desa Sugih Waras beralih memaksimalkan pompa pengairan irigasi malam hari demi efisiensi penyerapan air tanah. Pihak pemerintah kecamatan mengupayakan bantuan tambahan solar bersubsidi.",
    kategori: "Kabar Desa",
    tanggalPublikasi: "2026-06-19",
    statusPublikasi: "Terbit",
    fotoUrl: "https://images.unsplash.com/photo-1523348837708-15d4a09cfac2?auto=format&fit=crop&q=80&w=600"
  }
];

export const kegiatanList: KalenderKegiatan[] = [
  {
    id: "keg-1",
    desaId: "desa-1",
    namaKegiatan: "Panen Raya Sawah Padi Terpadu OKU Timur",
    tanggal: "2026-07-10",
    lokasi: "Lahan Pertanian Gapoktan Purwodadi",
    statusKegiatan: "Akan Datang",
    keterangan: "Kegiatan panen raya padi organik varietas unggul secara serentak bersama Bupati OKU Timur dan Dinas Pertanian."
  },
  {
    id: "keg-2",
    desaId: "desa-2",
    namaKegiatan: "Rembuk Stunting dan Pembagian Makanan Tambahan PMT",
    tanggal: "2026-06-25",
    lokasi: "Balai Desa Petanggan",
    statusKegiatan: "Akan Datang",
    keterangan: "Musyawarah bersama bidan desa dan seluruh ibu hamil dan menyusui guna meminimalkan risiko stunting Balai Desa."
  }
];

export const pelapakList: Pelapak[] = [
  {
    id: "pel-1",
    namaPelapak: "Pak Sudarmo - Beras Unggul Sriwijaya",
    noWhatsApp: "6281274563341", // Real prefix
    alamat: "Jl. Poros No. 20, Desa Purwodadi",
    desaId: "desa-1",
    deskripsiUsia: "Pusat Penggilingan & Distribusi Beras Organik Premium Sejak 1998."
  },
  {
    id: "pel-2",
    namaPelapak: "Ibu Nurhayati - Sirup Cantik Petanggan",
    noWhatsApp: "6282188432210",
    alamat: "Kompleks Pengolahan Buah RT 02, Desa Petanggan",
    desaId: "desa-2",
    deskripsiUsia: "Produsen Olahan Sirup Buah Naga Alami dan Selai Organik Higienis."
  },
  {
    id: "pel-3",
    namaPelapak: "Mak Cik Aminah - Keripik Renyah Purwodadi",
    noWhatsApp: "6289943215560",
    alamat: "Lorong Buntu No. 12, Desa Purwodadi",
    desaId: "desa-5",
    deskripsiUsia: "Pondok UMKM Pembuat Keripik Pisang Rasa Manis Gurih Tradisional."
  }
];

export const produkList: ProdukLapak[] = [
  {
    id: "prod-1",
    desaId: "desa-1",
    pelapakId: "pel-1",
    namaProduk: "Beras Organik Pandan Wangi Super (10 Kg)",
    kategori: "Makanan",
    harga: 145000,
    satuanJual: "Karung",
    stokStatus: "Tersedia",
    fotoUrl: "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&q=80&w=600",
    deskripsi: "Beras merah dan putih organik unggulan khas OKU Timur kemasan 10 Kg. Diproses dengan tingkat kebersihan mesin modern, bebas pengawet maupun pemutih sintetis. Pulen, wangi alami, dan sangat menyehatkan bagi keluarga Anda.",
    isUnggulanKecamatan: true
  },
  {
    id: "prod-2",
    desaId: "desa-2",
    pelapakId: "pel-2",
    namaProduk: "Sirup Buah Naga Merah Segar Organik",
    kategori: "Makanan",
    harga: 28000,
    satuanJual: "Botol",
    stokStatus: "Terbatas",
    fotoUrl: "https://images.unsplash.com/photo-1544816155-12df9643f363?auto=format&fit=crop&q=80&w=600",
    deskripsi: "Sirup buah naga murni kualitas premium hasil agro-ekologi Srimulyo. Diolah dari buah naga merah segar matang pohon pilihan dengan gula pasir tebu murni, kaya vitamin C dan sumber antioksidan berlimpah.",
    isUnggulanKecamatan: true
  },
  {
    id: "prod-3",
    desaId: "desa-5",
    pelapakId: "pel-3",
    namaProduk: "Keripik Pisang Tanduk Karamel Renyah",
    kategori: "Makanan",
    harga: 18050,
    satuanJual: "Bungkus",
    stokStatus: "Tersedia",
    fotoUrl: "https://images.unsplash.com/photo-1582979512210-99b6a53386f9?auto=format&fit=crop&q=80&w=600",
    deskripsi: "Olahan keripik pisang gurih renyah lapis karamel manis dengan irisan tipis nan presisi khas Desa Purwodadi. Camilan nikmat bebas lemak jenuh tinggi, sempurna untuk menemani waktu senggang santai Anda sekeluarga.",
    isUnggulanKecamatan: true
  },
  {
    id: "prod-4",
    desaId: "desa-8",
    pelapakId: "pel-2",
    namaProduk: "Jeruk Manis Hortikultura Organik (5 Kg)",
    kategori: "Pertanian",
    harga: 75000,
    satuanJual: "Lusin/Karung",
    stokStatus: "Tersedia",
    fotoUrl: "https://images.unsplash.com/photo-1557800636-894a64c1696f?auto=format&fit=crop&q=80&w=600",
    deskripsi: "Jeruk manis segar hortikultura varietas unggul dipetik langsung dari kebun warga Karang Manik, diproses higienis dan memiliki kandungan manis alami tinggi tanpa pemanis tambahan.",
    isUnggulanKecamatan: true
  },
  {
    id: "prod-5",
    desaId: "desa-12",
    pelapakId: "pel-1",
    namaProduk: "Kerajinan Ukiran Patung Kayu Bali",
    kategori: "Kerajinan",
    harga: 320000,
    satuanJual: "Unit",
    stokStatus: "Tersedia",
    fotoUrl: "https://images.unsplash.com/photo-1544816155-12df9643f363?auto=format&fit=crop&q=80&w=600",
    deskripsi: "Seni pahatan kayu bernilai seni tinggi buatan tangan pengerajin terampil Desa Sukoharjo, terbuat dari kayu jati/mahoni berkualitas tinggi dengan detail ukiran ornamen lokal yang eksotis.",
    isUnggulanKecamatan: false
  }
];

export const asetList: AsetDesa[] = [
  {
    id: "aset-1",
    desaId: "desa-1",
    namaAset: "Tanah Lapangan Olahraga Merdeka",
    kategoriAset: "Tanah Milik Desa",
    lokasiSpesifik: "Sebelah Barat Kantor Desa, RT 02",
    luasMeterPersegi: 4500,
    statusKepemilikan: "Sertifikat Hak Pakai Pemdes No. 04/2012",
    kondisi: "Aktif Digunakan",
    koordinatLat: -3.3425,
    koordinatLng: 104.6300,
    penggunaanSaatIni: "Ajang Olahraga Rakyat & Lokasi Festival Tahunan",
    dokumenPendukungName: "Sertifikat_BPN_TanahMerdeka_MulyaGuna.pdf",
    dokumenSize: "1.8 MB"
  },
  {
    id: "aset-2",
    desaId: "desa-2",
    namaAset: "Gedung Sentra Agrowisata Buah Rakyat",
    kategoriAset: "Bangunan Milik Desa",
    lokasiSpesifik: "Jl. Poros RT 04 Dusun III",
    luasMeterPersegi: 240,
    statusKepemilikan: "Bangunan APBDesa Dana Hibah Provinsi 2018",
    kondisi: "Aktif Digunakan",
    koordinatLat: -3.3365,
    koordinatLng: 104.6135,
    penggunaanSaatIni: "Pusat Bengkel Agro dan Galeri Display UMKM Buah",
    dokumenPendukungName: "IMB_SentraAgrowisataSrimulyo.pdf",
    dokumenSize: "2.3 MB"
  },
  {
    id: "aset-3",
    desaId: "desa-3",
    namaAset: "Mesin Pencacah Bambu Serat Alam Otomatis",
    kategoriAset: "Inventaris Barang Desa",
    lokasiSpesifik: "Gudang Penempaan Koperasi Anyaman",
    statusKepemilikan: "Fasilitasi Kementerian Perindustrian RI 2021",
    kondisi: "Aktif Digunakan",
    penggunaanSaatIni: "Disewakan bagi Pengrajin Anyaman Bambu Desa",
    dokumenPendukungName: "BeritaAcara_MesinBambu_OKUTimur.pdf",
    dokumenSize: "950 KB"
  },
  {
    id: "aset-4",
    desaId: "desa-5",
    namaAset: "Gedung Sentra Pengolahan Keripik Pisang Purwodadi",
    kategoriAset: "Bangunan Milik Desa",
    lokasiSpesifik: "Jl. Poros Utama No. 15, RT 02",
    luasMeterPersegi: 380,
    statusKepemilikan: "Sertifikat Hak Guna Bangunan Pemdes No. 12/2019",
    kondisi: "Aktif Digunakan",
    koordinatLat: -3.3455,
    koordinatLng: 104.6495,
    penggunaanSaatIni: "Sentra Produksi Bersama UMKM Keripik Pisang Desa",
    dokumenPendukungName: "Sertifikat_BPN_SentraKeripikPurwodadi.pdf",
    dokumenSize: "1.4 MB"
  },
  {
    id: "aset-5",
    desaId: "desa-5",
    namaAset: "Mesin Vacuum Frying Keripik Pisang Kapasitas Industri",
    kategoriAset: "Inventaris Barang Desa",
    lokasiSpesifik: "Gedung Sentra Pengolahan, Meja Utama",
    statusKepemilikan: "Pengadaan APBDesa Dana Desa Tahun Anggaran 2022",
    kondisi: "Aktif Digunakan",
    penggunaanSaatIni: "Fasilitas Penggorengan Keripik Pisang bagi UMKM Pemula",
    dokumenPendukungName: "BA_SerahTerima_MesinVacuumPurwodadi.pdf",
    dokumenSize: "680 KB"
  },
  {
    id: "aset-6",
    desaId: "desa-12",
    namaAset: "Ambulans Desa Siaga Sehat Sukoharjo",
    kategoriAset: "Inventaris Barang Desa",
    lokasiSpesifik: "Garasi Siaga Sehat, Samping Kantor Desa",
    statusKepemilikan: "Pembelian CSR Perusahaan Perkebunan Sawit Mitra Desa 2023",
    kondisi: "Aktif Digunakan",
    penggunaanSaatIni: "Pelayanan Kesehatan Gratis gawat darurat warga 24 Jam",
    dokumenPendukungName: "BPKB_STNK_AmbulansSukoharjo.pdf",
    dokumenSize: "1.1 MB"
  }
];

export const catatanKecamatanList: CatatKecamatan[] = [
  {
    id: "cat-1",
    desaId: "desa-3",
    pengirim: "Sub Bagian Administrasi Kecamatan",
    catatan: "Harap melampirkan profil lengkap perangkat desa bagian Sekdes yang terpilih. Status data monografi belum disubmit sejak triwulan lalu.",
    tanggal: "2026-06-18",
    isResolved: false
  },
  {
    id: "cat-2",
    desaId: "desa-4",
    pengirim: "Casi Pemerintahan Kecamatan",
    catatan: "Luas wilayah koordinat Lat/Lng pada Monografi Luas Wilayah terdeteksi deviasi negatif. Harap verifikasi batas desa ulang dengan peta RTRW Kabupaten.",
    tanggal: "2026-06-19",
    isResolved: false
  }
];

export const logAktivitasList: LogAktivitas[] = [
  {
    id: "log-1",
    timestamp: "2026-06-19 14:32",
    user: "Syahrul Camat",
    role: "Camat/Admin Kecamatan",
    aksi: "Kirim Memo",
    detail: "Mengirim instruksi percepatan input monografi ke Desa Sariguna."
  },
  {
    id: "log-2",
    timestamp: "2026-06-19 10:15",
    user: "Operator_Srimulyo1",
    role: "Operator Desa",
    desaImpacted: "Srimulyo",
    aksi: "Tambah Produk UMKM",
    detail: "Mengunggah produk baru 'Sirup Buah Naga Merah Segar' ke Lapak Desa."
  }
];
