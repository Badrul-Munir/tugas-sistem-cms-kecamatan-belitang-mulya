/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from "react";
import {
  LayoutDashboard,
  MapPin,
  FolderTree,
  Coins,
  ShieldCheck,
  Newspaper,
  ShoppingBag,
  Database,
  Lock,
  Compass,
  Users,
  Eye,
  HelpCircle,
  Lightbulb,
  X,
  Menu
} from "lucide-react";

// Types & Seed Data
import {
  Desa,
  MonografiKependudukan,
  MonografiSosialEkonomi,
  SaranaPrasarana,
  Komoditas,
  PerangkatDesa,
  BeritaKegiatan,
  KalenderKegiatan,
  Pelapak,
  ProdukLapak,
  AsetDesa,
  CatatKecamatan,
  LogAktivitas,
  UserRole
} from "./types";

import {
  desaList,
  kependudukanList,
  sosialEkonomiList,
  saranaPrasaranaList,
  komoditasList,
  perangkatList,
  beritaList,
  kegiatanList,
  pelapakList,
  produkList,
  asetList,
  catatanKecamatanList,
  logAktivitasList
} from "./data/seedData";

// Components
import DashboardModule from "./components/DashboardModule";
import DataDesaModule from "./components/DataDesaModule";
import MonografiModule from "./components/MonografiModule";
import KomoditasModule from "./components/KomoditasModule";
import PerangkatModule from "./components/PerangkatModule";
import BeritaModule from "./components/BeritaModule";
import LapakModule from "./components/LapakModule";
import AsetModule from "./components/AsetModule";
import ManajemenAksesModule from "./components/ManajemenAksesModule";

export default function App() {
  // State variables for all modules
  const [villages, setVillages] = useState<Desa[]>(desaList);
  const [kependudukan, setKependudukan] = useState<MonografiKependudukan[]>(kependudukanList);
  const [sosialEkonomi, setSosialEkonomi] = useState<MonografiSosialEkonomi[]>(sosialEkonomiList);
  const [saranaPrasarana, setSaranaPrasarana] = useState<SaranaPrasarana[]>(saranaPrasaranaList);
  const [komoditas, setKomoditas] = useState<Komoditas[]>(komoditasList);
  const [perangkat, setPerangkat] = useState<PerangkatDesa[]>(perangkatList);
  const [berita, setBerita] = useState<BeritaKegiatan[]>(beritaList);
  const [kegiatan, setKegiatan] = useState<KalenderKegiatan[]>(kegiatanList);
  const [pelapak, setPelapak] = useState<Pelapak[]>(pelapakList);
  const [produk, setProduk] = useState<ProdukLapak[]>(produkList);
  const [aset, setAset] = useState<AsetDesa[]>(asetList);
  const [catatanKecamatan, setCatatanKecamatan] = useState<CatatKecamatan[]>(catatanKecamatanList);
  const [aktivitas, setAktivitas] = useState<LogAktivitas[]>(logAktivitasList);

  // Active Context States
  const [selectedVillageId, setSelectedVillageId] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<string>("dashboard");
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);

  // User Authentication & Roles State 9.1
  const [activeRole, setActiveRole] = useState<UserRole>("Camat/Admin Kecamatan");
  const [operatorVillageId, setOperatorVillageId] = useState<string | null>(null);

  // Floating UX Psychology Tips Toggle
  const [showPsychologyTip, setShowPsychologyTip] = useState(true);
  const [currentTipIndex, setCurrentTipIndex] = useState(0);

  const psychologyTips = [
    {
      title: "Prinsip Kebanggaan Wilayah (In-Group Favoritism)",
      desc: "Menampilkan peta interaktif yang menonjolkan sentra pertanian atau agrowisata unggulan (seperti lumbung padi organik atau hortikultura buah naga) memotivasi aparatur daerah untuk berpartisipasi karena merasa diwakili dengan bangga."
    },
    {
      title: "Efek Zeigarnik (Gamified Completeness Gaps)",
      desc: "Bar presentase kelengkapan data yang berwarna dari merah ke hijau pada modul kelayakan memicu rasa 'tugas belum selesai' bagi operator desa, merangsang mereka memenuhi instrumen borang sesegera mungkin."
    },
    {
      title: "Desentralisasi & Jaminan Aman (Isolation Assurance)",
      desc: "Menyertakan peringatan isolasi data bagi Operator Desa Srimulyo menenangkan psikologis pengguna dari stres merusak data wilayah desa tetangga secara tidak sengaja, menciptakan rasa aman bagi operator pemula."
    },
    {
      title: "Reduksi Friksi Whatsapp (Immediate Value Loop)",
      desc: "Tombol klik order Whatsapp langsung ke penenun lokal meningkatkan utilitas perangkat lunak. Aplikasi administratif tidak lagi terasa kaku, melainkan berkontribusi nyata pada ekonomi rakyat (Lapak Penduduk)."
    }
  ];

  // Global Logging Helper
  const logActivity = (aksi: string, detail: string) => {
    const timestamp = new Date().toLocaleString("id-ID", { hourCycle: "h23" });
    const user = activeRole === "Camat/Admin Kecamatan" ? "Syahrul Camat" : activeRole === "Operator Desa" ? `Operator_Desa_${operatorVillageId}` : "Tamu Publik";
    
    const newLog: LogAktivitas = {
      id: `log-${Date.now()}`,
      timestamp,
      user,
      role: activeRole,
      aksi,
      detail
    };
    setAktivitas((prev) => [newLog, ...prev]);
  };

  // State Mutators
  const handleRoleSwitch = (role: UserRole, villageId: string | null) => {
    setActiveRole(role);
    setOperatorVillageId(villageId);
    
    // Automatically filter village context when acting as single village Operator
    if (role === "Operator Desa" && villageId) {
      setSelectedVillageId(villageId);
    } else if (role === "Camat/Admin Kecamatan") {
      setSelectedVillageId(null);
    }
    
    logActivity("Ubah Sesi Peran", `Beralih ke peran ${role} ${villageId ? `pada Desa ${villageId}` : ""}`);
  };

  const handleUpdateWebStatus = (desaId: string, status: Desa["statusWeb"]) => {
    setVillages((prev) =>
      prev.map((v) => (v.id === desaId ? { ...v, statusWeb: status } : v))
    );
    const targetDesa = villages.find((v) => v.id === desaId)?.nama;
    logActivity("Ubah Status Web", `Memperbarui status digital desa ${targetDesa} menjadi ${status}`);
  };

  const handleAddCatatan = (desaId: string, catatan: string) => {
    const newMemo: CatatKecamatan = {
      id: `cat-${Date.now()}`,
      desaId,
      pengirim: "C Camat Belitang Mulya",
      catatan,
      tanggal: new Date().toISOString().split("T")[0],
      isResolved: false
    };
    setCatatanKecamatan((prev) => [newMemo, ...prev]);
    const targetDesa = villages.find((v) => v.id === desaId)?.nama;
    logActivity("Kirim Catatan", `Kecamatan memberi arahan instrumen borang ke Desa ${targetDesa}.`);
  };

  const handleAddKomoditas = (newKom: Omit<Komoditas, "id">) => {
    const freshKom: Komoditas = {
      ...newKom,
      id: `kom-${Date.now()}`
    };
    setKomoditas((prev) => [...prev, freshKom]);
    logActivity("Tambah Komoditas", `Mendaftarkan potensi komoditas baru [${newKom.namaKomoditas}]`);
  };

  const handleToggleUnggulan = (komId: string) => {
    setKomoditas((prev) =>
      prev.map((k) => (k.id === komId ? { ...k, statusUnggulan: !k.statusUnggulan } : k))
    );
    const item = komoditas.find((k) => k.id === komId);
    logActivity("Ubah Unggulan", `Mengubah status komoditas utama ${item?.namaKomoditas}`);
  };

  const handleDeleteKomoditas = (komId: string) => {
    const item = komoditas.find((k) => k.id === komId);
    setKomoditas((prev) => prev.filter((k) => k.id !== komId));
    logActivity("Hapus Komoditas", `Mengeluarkan komoditas ${item?.namaKomoditas} dari master list`);
  };

  const handleAddBerita = (newNews: Omit<BeritaKegiatan, "id" | "tanggalPublikasi">) => {
    const freshNews: BeritaKegiatan = {
      ...newNews,
      id: `ber-${Date.now()}`,
      tanggalPublikasi: new Date().toISOString().split("T")[0]
    };
    setBerita((prev) => [freshNews, ...prev]);
    logActivity("Posting Berita", `Menerbitkan warta berita desa: ${newNews.judul}`);
  };

  const handleUpdatePublishStatus = (newsId: string, status: BeritaKegiatan["statusPublikasi"]) => {
    setBerita((prev) =>
      prev.map((b) => (b.id === newsId ? { ...b, statusPublikasi: status } : b))
    );
    const item = berita.find((b) => b.id === newsId)?.judul;
    logActivity("Ubah Publish Berita", `Toggling status publikasi berita "${item}" menjadi ${status}`);
  };

  const handleAddProduk = (newProd: Omit<ProdukLapak, "id">) => {
    const freshProd: ProdukLapak = {
      ...newProd,
      id: `prod-${Date.now()}`
    };
    setProduk((prev) => [...prev, freshProd]);
    logActivity("Register Lapak", `Menambah produk UMKM baru [${newProd.namaProduk}] ke katalog desa.`);
  };

  const handleToggleStock = (prodId: string, status: ProdukLapak["stokStatus"]) => {
    setProduk((prev) =>
      prev.map((p) => (p.id === prodId ? { ...p, stokStatus: status } : p))
    );
    const title = produk.find((p) => p.id === prodId)?.namaProduk;
    logActivity("Ubah Ketersediaan", `Mengubah stok barang dagang "${title}" menjadi ${status}`);
  };

  const handleAddAset = (newAset: Omit<AsetDesa, "id">) => {
    const freshAset: AsetDesa = {
      ...newAset,
      id: `aset-${Date.now()}`
    };
    setAset((prev) => [...prev, freshAset]);
    logActivity("Simpan Aset", `Memetakan pendaftaran objek aset baru: ${newAset.namaAset}`);
  };

  const handleUpdateAssetCondition = (asetId: string, kondisi: AsetDesa["kondisi"]) => {
    setAset((prev) =>
      prev.map((a) => (a.id === asetId ? { ...a, kondisi } : a))
    );
    const item = aset.find((a) => a.id === asetId)?.namaAset;
    logActivity("Ubah Fisik Aset", `Pembaruan kondisi operasional barang "${item}" menjadi ${kondisi}`);
  };

  // Navigations link helper
  const handleNavigateToTab = (tabId: string) => {
    setActiveTab(tabId);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  // Filter components lists
  const currentVillage = villages.find((v) => v.id === selectedVillageId);

  return (
    <div id="full-cms-app" className="h-screen bg-slate-50 font-sans flex flex-col antialiased text-slate-800 overflow-hidden">
      {/* Premium Top Navigation Rib ribbon with High-Density theme */}
      <header className="bg-[#0F172A] text-white flex flex-col md:flex-row items-start md:items-center justify-between px-6 py-3 border-b-4 border-yellow-500 shadow-lg z-45 gap-4 shrink-0">
        <div className="flex items-center gap-3">
          {/* Tiga Garis Menu Button */}
          <button
            type="button"
            onClick={() => setIsSidebarOpen(!isSidebarOpen)}
            className="p-1.5 hover:bg-slate-850 rounded text-yellow-400 hover:text-white transition-colors duration-150 flex items-center justify-center shrink-0 border border-slate-700 bg-slate-900 shadow-sm cursor-pointer"
            title={isSidebarOpen ? "Tutup Menu" : "Buka Menu"}
          >
            <Menu className="w-5 h-5" />
          </button>

          <div className="w-10 h-10 bg-white rounded-md flex items-center justify-center p-1 shadow-md shrink-0 overflow-hidden">
            <img 
              src="https://upload.wikimedia.org/wikipedia/commons/3/30/Lambang_Kabupaten_OKU_Timur.png" 
              alt="Lambang OKU Timur" 
              className="w-full h-full object-contain" 
              referrerPolicy="no-referrer"
            />
          </div>
          <div>
            <span className="text-[10px] font-bold uppercase tracking-widest text-yellow-400 block leading-tight">
              Provinsi Sumatera Selatan • OKU Timur
            </span>
            <h1 className="text-base font-extrabold text-white tracking-tight leading-none mt-0.5 whitespace-nowrap">
              SISTEM CMS KECAMATAN BELITANG MULYA
            </h1>
          </div>
        </div>

        {/* Global Active Session + Online Status Box */}
        <div className="flex flex-wrap items-center gap-3 self-stretch md:self-auto">
          {/* Selected Village filter notification */}
          {selectedVillageId && (
            <div className="bg-slate-800 text-yellow-400 border border-slate-700 text-xs px-2.5 py-1 rounded font-medium flex items-center gap-1">
              <span>Wilayah: <strong>{currentVillage?.nama}</strong></span>
              {activeRole !== "Operator Desa" && (
                <button
                  type="button"
                  onClick={() => setSelectedVillageId(null)}
                  className="font-bold hover:text-red-500 ml-1 hover:scale-105"
                >
                  ✕
                </button>
              )}
            </div>
          )}

          {/* Session Banner */}
          <div className="bg-slate-800 text-slate-350 border border-slate-700 text-[11px] font-mono px-3 py-1.5 rounded flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-yellow-400" />
            <span>
              Peran: <strong className="text-white">{activeRole}</strong>
            </span>
          </div>

          {/* Online system status badge from template */}
          <div className="flex items-center space-x-2 bg-slate-800 px-3 py-1.5 rounded border border-slate-700">
            <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
            <span className="text-[10px] font-semibold uppercase text-slate-200">Sistem Online</span>
          </div>
        </div>
      </header>

      {/* Main CMS Layout Frame: Sidebar + Dynamic Panel Wrapper */}
      <div className="flex-1 flex flex-row overflow-hidden relative">
        {/* Mobile Backdrop Overlay when sidebar is open */}
        {isSidebarOpen && (
          <div 
            onClick={() => setIsSidebarOpen(false)}
            className="fixed inset-0 bg-slate-950/60 backdrop-blur-xs z-30 md:hidden transition-opacity duration-200 cursor-pointer"
          />
        )}

        {/* SIDEBAR NAVIGATION (Modules Categorized - High-Density Theme with yellow highlights) */}
        <aside className={`
          fixed md:static inset-y-0 left-0 z-40
          bg-[#0F172A] text-slate-300 flex flex-col border-r border-slate-950 shadow-inner shrink-0 
          h-full overflow-y-auto transition-all duration-300 ease-in-out
          ${isSidebarOpen 
            ? "translate-x-0 w-72 md:w-64 p-4 opacity-100" 
            : "-translate-x-full md:translate-x-0 md:w-0 md:p-0 md:opacity-0 md:overflow-hidden md:border-r-0 opacity-0"
          }
        `}>
          <div className="text-[10px] font-bold text-yellow-400 uppercase tracking-widest px-3 border-l-2 border-yellow-500 py-0.5">
            Buku Menu CMS
          </div>

          <nav id="sidebar-navigation" className="space-y-1.5 flex-1 mt-4">
            {[
              { id: "dashboard", label: "Dashboard Utama", icon: LayoutDashboard },
              { id: "data_desa", label: "Master Data Desa", icon: MapPin },
              { id: "monografi", label: "Monografi Sensus", icon: Users },
              { id: "komoditas", label: "Potensi Komoditas", icon: Coins },
              { id: "perangkat", label: "Struktur Perangkat", icon: FolderTree },
              { id: "berita", label: "Portal Berita/Agenda", icon: Newspaper },
              { id: "lapak", label: "Lapak Produk UMKM", icon: ShoppingBag },
              { id: "aset", label: "Register Aset Desa", icon: Database },
              { id: "akses", label: "Manajemen Akses", icon: Lock }
            ].map((item) => {
              const TabIcon = item.icon;
              const isSelected = activeTab === item.id;

              return (
                <button
                  key={item.id}
                  onClick={() => handleNavigateToTab(item.id)}
                  className={`w-full text-left px-3 py-2 rounded text-xs font-bold uppercase tracking-wider flex items-center gap-3 transition-all leading-none ${
                    isSelected
                      ? "bg-yellow-500 text-slate-950 font-black shadow-md border-l-4 border-amber-600 scale-[1.01]"
                      : "hover:bg-slate-800 hover:text-white"
                  }`}
                >
                  <TabIcon className="w-4 h-4 shrink-0 text-slate-400 group-hover:text-white" />
                  <span className="truncate">{item.label}</span>
                </button>
              );
            })}
          </nav>

          {/* Quick Informational Guide explaining User Psychology to South Sumatra users */}
          <div className="hidden md:block border-t border-slate-800/80 pt-4 text-[10px] text-slate-400">
            <span className="font-bold text-slate-300 block mb-1">Sektor Belitang Mulya</span>
            <p className="leading-relaxed">
              Mewakili Desa Sentra: Pertanian berkualitas, kelapa sawit, hortikultura buah-buahan, dan kriya anyaman anyar.
            </p>
          </div>
        </aside>

        {/* DYNAMIC SCREEN SCOPE WRAPPER */}
        <main className="flex-1 p-5 md:p-8 space-y-6 overflow-y-auto h-full">
          {/* Active module selection rendering */}
          {activeTab === "dashboard" && (
            <DashboardModule
              villages={villages}
              kependudukan={kependudukan}
              sosialEkonomi={sosialEkonomi}
              saranaPrasarana={saranaPrasarana}
              komoditas={komoditas}
              perangkat={perangkat}
              berita={berita}
              produk={produk}
              aset={aset}
              catatanKecamatan={catatanKecamatan}
              aktivitas={aktivitas}
              selectedVillageId={selectedVillageId}
              onSelectVillage={setSelectedVillageId}
              onNavigateToTab={handleNavigateToTab}
            />
          )}

          {activeTab === "data_desa" && (
            <DataDesaModule
              villages={villages}
              catatanKecamatan={catatanKecamatan}
              activeRole={activeRole}
              operatorVillageId={operatorVillageId}
              onAddCatatan={handleAddCatatan}
              onUpdateWebStatus={handleUpdateWebStatus}
            />
          )}

          {activeTab === "monografi" && (
            <MonografiModule
              villages={villages}
              kependudukan={kependudukan}
              sosialEkonomi={sosialEkonomi}
              saranaPrasarana={saranaPrasarana}
              selectedVillageId={selectedVillageId}
              onSelectVillage={setSelectedVillageId}
            />
          )}

          {activeTab === "komoditas" && (
            <KomoditasModule
              komoditas={komoditas}
              villages={villages}
              activeRole={activeRole}
              operatorVillageId={operatorVillageId}
              onAddKomoditas={handleAddKomoditas}
              onToggleUnggulan={handleToggleUnggulan}
              onDeleteKomoditas={handleDeleteKomoditas}
            />
          )}

          {activeTab === "perangkat" && (
            <PerangkatModule
              perangkat={perangkat}
              villages={villages}
              selectedVillageId={selectedVillageId}
              onSelectVillage={setSelectedVillageId}
            />
          )}

          {activeTab === "berita" && (
            <BeritaModule
              berita={berita}
              kegiatan={kegiatan}
              villages={villages}
              activeRole={activeRole}
              operatorVillageId={operatorVillageId}
              onAddBerita={handleAddBerita}
              onUpdatePublishStatus={handleUpdatePublishStatus}
            />
          )}

          {activeTab === "lapak" && (
            <LapakModule
              produk={produk}
              pelapak={pelapak}
              villages={villages}
              activeRole={activeRole}
              operatorVillageId={operatorVillageId}
              selectedVillageId={selectedVillageId}
              onSelectVillage={setSelectedVillageId}
              onAddProduk={handleAddProduk}
              onToggleStock={handleToggleStock}
            />
          )}

          {activeTab === "aset" && (
            <AsetModule
              aset={aset}
              villages={villages}
              activeRole={activeRole}
              operatorVillageId={operatorVillageId}
              onAddAset={handleAddAset}
              onUpdateCondition={handleUpdateAssetCondition}
            />
          )}

          {activeTab === "akses" && (
            <ManajemenAksesModule
              aktivitas={aktivitas}
              activeRole={activeRole}
              operatorVillageId={operatorVillageId}
              villages={villages}
              onRoleSwitch={handleRoleSwitch}
              onLoggedAction={logActivity}
            />
          )}
        </main>
      </div>

      {/* USER PSYCHOLOGY FLOATING DRAWER PANEL (Sesuai keinginan pengguna psikologi) */}
      {showPsychologyTip && (
        <div id="psychology-floating-helper" className="fixed bottom-4 right-4 max-w-sm bg-white rounded-lg border-2 border-yellow-500 shadow-xl p-4 z-50 animate-bounce-slow">
          <div className="flex justify-between items-start mb-2">
            <span className="text-[9px] font-bold uppercase text-slate-900 bg-yellow-100 border border-yellow-400 px-2 py-0.5 rounded flex items-center gap-1">
              <Lightbulb className="w-3 h-3 text-amber-600" /> Formula Psikologi Antarmuka
            </span>
            <button
              onClick={() => setShowPsychologyTip(false)}
              className="text-slate-400 hover:text-slate-600 rounded"
              title="Close Guide"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="space-y-1">
            <h5 className="text-xs font-extrabold text-slate-800">
              {psychologyTips[currentTipIndex].title}
            </h5>
            <p className="text-[11px] text-slate-600 leading-relaxed font-medium">
              {psychologyTips[currentTipIndex].desc}
            </p>
          </div>

          <div className="flex justify-between items-center mt-3 pt-2.5 border-t border-slate-100 text-[10px] text-slate-400">
            <span>Formula {currentTipIndex + 1} dari {psychologyTips.length}</span>
            <button
              onClick={() => setCurrentTipIndex((prev) => (prev + 1) % psychologyTips.length)}
              className="text-slate-900 font-bold hover:underline hover:text-yellow-600"
            >
              Berikutnya →
            </button>
          </div>
        </div>
      )}

      {/* Premium Footer */}
      <footer className="bg-slate-900 border-t border-slate-950 p-5 text-center text-[10px] text-slate-500 font-mono">
        <p>
          &copy; {new Date().getFullYear()} PEMERINTAH KECAMATAN BELITANG MULYA, KABUPATEN OKU TIMUR.
        </p>
        <p className="mt-1">
          Pusat Visualisasi Data & Monitoring CMS Desa se-Sumatera Selatan Terintegrasi.
        </p>
      </footer>
    </div>
  );
}
