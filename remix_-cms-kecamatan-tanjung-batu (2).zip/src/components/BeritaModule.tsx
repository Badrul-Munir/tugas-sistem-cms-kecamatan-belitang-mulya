/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, FormEvent } from "react";
import {
  Calendar,
  Image as ImageIcon,
  BookOpen,
  Eye,
  Plus,
  Compass,
  CheckCircle,
  FileText
} from "lucide-react";
import { BeritaKegiatan, KalenderKegiatan, Desa, UserRole } from "../types";

interface BeritaModuleProps {
  berita: BeritaKegiatan[];
  kegiatan: KalenderKegiatan[];
  villages: Desa[];
  activeRole: UserRole;
  operatorVillageId: string | null;
  onAddBerita: (newNews: Omit<BeritaKegiatan, "id" | "tanggalPublikasi">) => void;
  onUpdatePublishStatus: (newsId: string, status: BeritaKegiatan["statusPublikasi"]) => void;
}

export default function BeritaModule({
  berita,
  kegiatan,
  villages,
  activeRole,
  operatorVillageId,
  onAddBerita,
  onUpdatePublishStatus
}: BeritaModuleProps) {
  const [selectedVillageId, setSelectedVillageId] = useState("");
  const [showAddForm, setShowAddForm] = useState(false);

  // Form controls
  const [formJudul, setFormJudul] = useState("");
  const [formKategori, setFormKategori] = useState<BeritaKegiatan["kategori"]>("Kabar Desa");
  const [formDesaId, setFormDesaId] = useState(villages[0]?.id || "");
  const [formKonten, setFormKonten] = useState("");

  const canEditBerita = (vId: string) => {
    if (activeRole === "Camat/Admin Kecamatan") return true;
    if (activeRole === "Operator Desa" && operatorVillageId === vId) return true;
    return false;
  };

  const handleCreateNews = (e: FormEvent) => {
    e.preventDefault();
    if (!formJudul || !formKonten) return;

    onAddBerita({
      judul: formJudul,
      konten: formKonten,
      kategori: formKategori,
      desaId: formDesaId,
      statusPublikasi: "Terbit",
      fotoUrl: "https://images.unsplash.com/photo-1544816155-12df9643f363?auto=format&fit=crop&q=80&w=600"
    });

    // Reset Form
    setFormJudul("");
    setFormKonten("");
    setShowAddForm(false);
  };

  // Filter based on select dropdown
  const filteredBerita = selectedVillageId ? berita.filter((b) => b.desaId === selectedVillageId) : berita;
  const filteredKegiatan = selectedVillageId ? kegiatan.filter((k) => k.desaId === selectedVillageId) : kegiatan;

  return (
    <div className="space-y-6">
      {/* 6.1 Top Filter & Summary */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm space-y-4">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-slate-900 border-l-2 border-yellow-500 px-2.5 py-0.5">
              6.0 Publikasi & Berita Desa
            </span>
            <h3 className="text-lg font-bold text-slate-800 mt-1">
              Portal Monitoring Kabar & Agenda Kegiatan Desa
            </h3>
            <p className="text-xs text-slate-500">
              Kanal monitoring terpadu seluruh berita dan acara kalender yang diterbitkan oleh masing-masing desa.
            </p>
          </div>

          <div className="flex gap-2 self-stretch sm:self-auto">
            {activeRole !== "Publik/Pengunjung" && (
              <button
                onClick={() => {
                  if (activeRole === "Operator Desa" && operatorVillageId) {
                    setFormDesaId(operatorVillageId);
                  }
                  setShowAddForm(!showAddForm);
                }}
                className="bg-[#0F172A] hover:bg-[#1E293B] text-white text-xs font-semibold px-4 py-2 rounded-lg transition-all flex items-center gap-1.5 shrink-0"
              >
                <Plus className="w-4 h-4" /> Tulis Kabar Baru
              </button>
            )}
            <select
              value={selectedVillageId}
              onChange={(e) => setSelectedVillageId(e.target.value)}
              className="text-xs border border-slate-200 rounded-lg py-2 px-3 focus:outline-none cursor-pointer bg-slate-50"
            >
              <option value="">Semua Desa</option>
              {villages.map((v) => (
                <option key={v.id} value={v.id}>
                  {v.nama}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Add Kabar Form */}
      {showAddForm && (
        <form onSubmit={handleCreateNews} className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm space-y-4">
          <div className="border-b border-slate-100 pb-3 flex justify-between items-center">
            <h4 className="text-sm font-bold text-slate-800">Tulis Pengumuman atau Berita Anyar</h4>
            <button type="button" onClick={() => setShowAddForm(false)} className="text-xs text-slate-400 hover:text-slate-600">Batal</button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
            <div className="md:col-span-8">
              <label className="block text-[10px] uppercase font-bold text-slate-500 mb-1">Judul Utama Berita</label>
              <input
                required
                type="text"
                placeholder="Contoh: Perbaikan Jembatan Gantung Desa Siap Dilaksanakan"
                value={formJudul}
                onChange={(e) => setFormJudul(e.target.value)}
                className="w-full text-xs border border-slate-200 rounded-lg p-2.5 focus:outline-none focus:border-yellow-500"
              />
            </div>

            <div className="md:col-span-4">
              <label className="block text-[10px] uppercase font-bold text-slate-500 mb-1">Kategori Kabar</label>
              <select
                value={formKategori}
                onChange={(e) => setFormKategori(e.target.value as BeritaKegiatan["kategori"])}
                className="w-full text-xs border border-slate-200 rounded-lg p-2.5 focus:outline-none focus:border-yellow-500"
              >
                <option value="Kabar Desa">Kabar Desa</option>
                <option value="Pembangunan">Pembangunan</option>
                <option value="Pemberdayaan">Pemberdayaan</option>
                <option value="Pertemuan">Pertemuan</option>
                <option value="Pengumuman">Pengumuman</option>
              </select>
            </div>

            {activeRole !== "Operator Desa" && (
              <div className="md:col-span-12">
                <label className="block text-[10px] uppercase font-bold text-slate-500 mb-1">Terbitkan Atas Nama Desa</label>
                <select
                  value={formDesaId}
                  onChange={(e) => setFormDesaId(e.target.value)}
                  className="w-full text-xs border border-slate-200 p-2 focus:outline-none"
                >
                  {villages.map((v) => (
                    <option key={v.id} value={v.id}>{v.nama}</option>
                  ))}
                </select>
              </div>
            )}

            <div className="md:col-span-12">
              <label className="block text-[10px] uppercase font-bold text-slate-500 mb-1">Isi Berita Lengkap</label>
              <textarea
                required
                placeholder="Deskripsikan acara secara rinci di sini..."
                value={formKonten}
                onChange={(e) => setFormKonten(e.target.value)}
                className="w-full text-xs border border-slate-200 rounded-lg p-2.5 focus:outline-none focus:border-yellow-500 h-32"
              />
            </div>
          </div>

          <div className="flex justify-end gap-2">
            <button
              type="button"
              onClick={() => setShowAddForm(false)}
              className="px-4 py-2 border border-slate-200 text-xs text-slate-500 rounded-lg hover:bg-slate-50"
            >
              Batal
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-[#0F172A] hover:bg-[#1E293B] text-white rounded-lg text-xs font-black"
            >
              Terbitkan Sekarang (Status: Terbit)
            </button>
          </div>
        </form>
      )}

      {/* Main Grid: Columns of News & Calendar of Events */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* 6.2 Berita Terbaru List */}
        <div className="lg:col-span-7 bg-white rounded-2xl border border-slate-200 p-6 shadow-sm space-y-4">
          <h4 className="text-xs font-bold uppercase text-slate-400 tracking-wider flex items-center gap-1.5">
            <BookOpen className="w-4 h-4 text-amber-600" />
            6.2 Rentetan Berita Terkini
          </h4>

          <div className="space-y-4">
            {filteredBerita.length > 0 ? (
              filteredBerita.map((item) => {
                const parentDesa = villages.find((v) => v.id === item.desaId);
                const isRestricted = !canEditBerita(item.desaId);

                return (
                  <div key={item.id} className="border-b border-slate-100 pb-4 last:border-0 last:pb-0 font-sans">
                    <div className="flex flex-col sm:flex-row gap-4 items-start">
                      <img
                        referrerPolicy="no-referrer"
                        src={item.fotoUrl}
                        alt={item.judul}
                        className="w-24 h-20 rounded-lg object-cover bg-slate-100 shrink-0 border border-slate-200"
                      />
                      <div className="space-y-1.5 flex-1 select-text">
                        <div className="flex flex-wrap items-center gap-1.5">
                          <span className="text-[8px] font-bold uppercase text-yellow-950 bg-yellow-50 border border-yellow-200 px-2 py-0.5 rounded">
                            {item.kategori}
                          </span>
                          <span className="text-[10px] text-slate-400 font-mono">
                            {item.tanggalPublikasi}
                          </span>
                          <span className="text-[9px] text-slate-500 font-medium font-mono">
                            • {parentDesa?.nama}
                          </span>
                        </div>

                        <h5 className="text-xs font-extrabold text-slate-800 hover:text-yellow-600 transition-colors leading-relaxed">
                          {item.judul}
                        </h5>
                        <p className="text-[11px] text-slate-500 leading-relaxed line-clamp-2">
                          {item.konten}
                        </p>

                        {/* Status Publication Toggle 6.5 */}
                        <div className="pt-2 flex items-center gap-2">
                          <span className="text-[9px] text-slate-400 uppercase font-mono">Status Publikasi (6.5):</span>
                          <select
                            disabled={isRestricted}
                            value={item.statusPublikasi}
                            onChange={(e) => onUpdatePublishStatus(item.id, e.target.value as BeritaKegiatan["statusPublikasi"])}
                            className={`text-[8px] font-bold uppercase border-0 rounded px-1.5 py-0.5 focus:ring-1 focus:ring-yellow-500 cursor-pointer ${
                              item.statusPublikasi === "Terbit"
                                ? "bg-yellow-100 text-yellow-900 border-yellow-205"
                                : item.statusPublikasi === "Draft"
                                ? "bg-amber-100 text-amber-800"
                                : "bg-slate-100 text-slate-700"
                            } disabled:opacity-75 disabled:cursor-not-allowed`}
                          >
                            <option value="Terbit">Terbit</option>
                            <option value="Draft">Draft</option>
                            <option value="Arsip">Arsip</option>
                            <option value="Perlu Diperbarui">Perlu Diperbarui</option>
                          </select>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })
            ) : (
              <p className="text-center py-8 text-slate-400 text-xs">Belum ada pengumuman berita untuk desa yang dipilih.</p>
            )}
          </div>
        </div>

        {/* 6.3 Kalender Kegiatan & 6.4 Galeri Kegiatan */}
        <div className="lg:col-span-5 space-y-6">
          {/* Action Calendar 6.3 */}
          <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm space-y-4">
            <h4 className="text-xs font-bold uppercase text-slate-400 tracking-wider flex items-center gap-1.5">
              <Calendar className="w-4 h-4 text-amber-600" />
              6.3 Kalender Kegiatan Aparatur
            </h4>

            <div className="space-y-3">
              {filteredKegiatan.length > 0 ? (
                filteredKegiatan.map((item) => {
                  const parentDesa = villages.find((v) => v.id === item.desaId);
                  return (
                    <div key={item.id} className="p-3 bg-slate-50 rounded-xl border border-slate-100 space-y-2">
                      <div className="flex justify-between items-start">
                        <div>
                          <strong className="text-xs text-slate-800 block leading-snug">{item.namaKegiatan}</strong>
                          <span className="text-[10px] text-yellow-600 font-bold">{parentDesa?.nama}</span>
                        </div>
                        <span className={`text-[8px] font-bold uppercase px-2 py-0.5 rounded ${
                          item.statusKegiatan === "Akan Datang"
                            ? "bg-slate-200 text-slate-700"
                            : "bg-yellow-50 text-yellow-900 font-bold border border-yellow-250"
                        }`}>
                          {item.statusKegiatan}
                        </span>
                      </div>
                      <div className="text-[11px] text-slate-500 leading-relaxed font-serif italic">
                        &ldquo;{item.keterangan}&rdquo;
                      </div>
                      <div className="border-t border-slate-200/50 pt-2 flex justify-between text-[10px] text-slate-400 font-mono">
                        <span>Tanggal: {item.tanggal}</span>
                        <span>Lokasi: {item.lokasi}</span>
                      </div>
                    </div>
                  );
                })
              ) : (
                <p className="text-center py-6 text-slate-400 text-xs">Tidak ada kegiatan terjadwal dalam waktu dekat.</p>
              )}
            </div>
          </div>

          {/* 6.4 Galeri Kegiatan */}
          <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm space-y-4">
            <h4 className="text-xs font-bold uppercase text-slate-400 tracking-wider flex items-center gap-1.5">
              <ImageIcon className="w-4 h-4 text-amber-600" />
              6.4 Dokumentasi Galeri Desa
            </h4>

            <div className="grid grid-cols-3 gap-2">
              {[
                { label: "Sawah Padi", url: "https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?auto=format&fit=crop&q=80&w=120" },
                { label: "Anyaman Bambu", url: "https://images.unsplash.com/photo-1544816155-12df9643f363?auto=format&fit=crop&q=80&w=120" },
                { label: "Olahan Makanan", url: "https://images.unsplash.com/photo-1582979512210-99b6a53386f9?auto=format&fit=crop&q=80&w=120" }
              ].map((img, idx) => (
                <div key={idx} className="relative rounded-lg overflow-hidden group border border-slate-100 bg-slate-900 aspect-square">
                  <img
                    referrerPolicy="no-referrer"
                    src={img.url}
                    alt={img.label}
                    className="w-full h-full object-cover opacity-80 group-hover:scale-105 group-hover:opacity-100 transition-all duration-300 pointer-events-none"
                  />
                  <div className="absolute inset-x-0 bottom-0 bg-slate-950/70 p-1 text-center">
                    <span className="text-[8px] font-sans font-bold text-white/90 truncate block">{img.label}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
