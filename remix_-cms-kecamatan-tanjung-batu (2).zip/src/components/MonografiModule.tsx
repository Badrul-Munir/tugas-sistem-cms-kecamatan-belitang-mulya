/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from "react";
import {
  Users,
  Compass,
  Briefcase,
  GraduationCap,
  HeartPulse,
  Home,
  MapPin,
  Building2,
  BookOpen
} from "lucide-react";

import {
  Desa,
  MonografiKependudukan,
  MonografiSosialEkonomi,
  SaranaPrasarana
} from "../types";

interface MonografiModuleProps {
  villages: Desa[];
  kependudukan: MonografiKependudukan[];
  sosialEkonomi: MonografiSosialEkonomi[];
  saranaPrasarana: SaranaPrasarana[];
  selectedVillageId: string | null;
  onSelectVillage: (id: string | null) => void;
}

export default function MonografiModule({
  villages,
  kependudukan,
  sosialEkonomi,
  saranaPrasarana,
  selectedVillageId,
  onSelectVillage,
}: MonografiModuleProps) {
  const [activeSubTab, setActiveSubTab] = useState<"kependudukan" | "sosial_ekonomi" | "sarana_prasarana" | "luas_wilayah">("kependudukan");

  // Get current active datasets
  const getActiveVillageData = () => {
    if (selectedVillageId) {
      const v = villages.find((x) => x.id === selectedVillageId);
      const k = kependudukan.find((x) => x.desaId === selectedVillageId);
      const se = sosialEkonomi.find((x) => x.desaId === selectedVillageId);
      const sp = saranaPrasarana.find((x) => x.desaId === selectedVillageId);
      return {
        nama: v?.nama || "Tidak Ditemukan",
        luas: v?.luasWilayahHektar || 0,
        k,
        se,
        sp
      };
    } else {
      // Aggregation Mode
      const aggK: MonografiKependudukan = {
        desaId: "agg",
        jumlahPenduduk: kependudukan.reduce((s, x) => s + x.jumlahPenduduk, 0),
        jumlahKK: kependudukan.reduce((s, x) => s + x.jumlahKK, 0),
        jumlahLakiLaki: kependudukan.reduce((s, x) => s + x.jumlahLakiLaki, 0),
        jumlahPerempuan: kependudukan.reduce((s, x) => s + x.jumlahPerempuan, 0),
        distribusiUsia: {
          balita: kependudukan.reduce((s, x) => s + x.distribusiUsia.balita, 0),
          anak: kependudukan.reduce((s, x) => s + x.distribusiUsia.anak, 0),
          remaja: kependudukan.reduce((s, x) => s + x.distribusiUsia.remaja, 0),
          produktif: kependudukan.reduce((s, x) => s + x.distribusiUsia.produktif, 0),
          lansia: kependudukan.reduce((s, x) => s + x.distribusiUsia.lansia, 0)
        },
        agama: {
          islam: kependudukan.reduce((s, x) => s + x.agama.islam, 0),
          kristen: kependudukan.reduce((s, x) => s + x.agama.kristen, 0),
          katolik: kependudukan.reduce((s, x) => s + x.agama.katolik, 0),
          hindu: kependudukan.reduce((s, x) => s + x.agama.hindu, 0),
          buddha: kependudukan.reduce((s, x) => s + x.agama.buddha, 0),
          konghucu: kependudukan.reduce((s, x) => s + x.agama.konghucu, 0)
        }
      };

      const aggSE: MonografiSosialEkonomi = {
        desaId: "agg",
        pekerjaan: {
          petaniKaret: sosialEkonomi.reduce((s, x) => s + x.pekerjaan.petaniKaret, 0),
          petaniNanas: sosialEkonomi.reduce((s, x) => s + x.pekerjaan.petaniNanas, 0),
          pengrajinTenun: sosialEkonomi.reduce((s, x) => s + x.pekerjaan.pengrajinTenun, 0),
          tukangKayuPanggung: sosialEkonomi.reduce((s, x) => s + x.pekerjaan.tukangKayuPanggung, 0),
          pedagang: sosialEkonomi.reduce((s, x) => s + x.pekerjaan.pedagang, 0),
          pnsTniPolri: sosialEkonomi.reduce((s, x) => s + x.pekerjaan.pnsTniPolri, 0),
          buruh: sosialEkonomi.reduce((s, x) => s + x.pekerjaan.buruh, 0),
          lainnya: sosialEkonomi.reduce((s, x) => s + x.pekerjaan.lainnya, 0)
        },
        pendidikan: {
          tidakSekolah: sosialEkonomi.reduce((s, x) => s + x.pendidikan.tidakSekolah, 0),
          sd: sosialEkonomi.reduce((s, x) => s + x.pendidikan.sd, 0),
          smp: sosialEkonomi.reduce((s, x) => s + x.pendidikan.smp, 0),
          sma: sosialEkonomi.reduce((s, x) => s + x.pendidikan.sma, 0),
          diplomaSarjana: sosialEkonomi.reduce((s, x) => s + x.pendidikan.diplomaSarjana, 0)
        },
        jumlahDusun: sosialEkonomi.reduce((s, x) => s + x.jumlahDusun, 0),
        jumlahNakes: sosialEkonomi.reduce((s, x) => s + x.jumlahNakes, 0)
      };

      const aggSP: SaranaPrasarana = {
        desaId: "agg",
        sekolah: {
          sd: saranaPrasarana.reduce((s, x) => s + x.sekolah.sd, 0),
          smp: saranaPrasarana.reduce((s, x) => s + x.sekolah.smp, 0),
          sma: saranaPrasarana.reduce((s, x) => s + x.sekolah.sma, 0),
          paud: saranaPrasarana.reduce((s, x) => s + x.sekolah.paud, 0)
        },
        fasilitasKesehatan: {
          puskesmasPustu: saranaPrasarana.reduce((s, x) => s + x.fasilitasKesehatan.puskesmasPustu, 0),
          posyandu: saranaPrasarana.reduce((s, x) => s + x.fasilitasKesehatan.posyandu, 0),
          bidanPraktek: saranaPrasarana.reduce((s, x) => s + x.fasilitasKesehatan.bidanPraktek, 0)
        },
        tempatIbadah: {
          masjid: saranaPrasarana.reduce((s, x) => s + x.tempatIbadah.masjid, 0),
          mushola: saranaPrasarana.reduce((s, x) => s + x.tempatIbadah.mushola, 0),
          gereja: saranaPrasarana.reduce((s, x) => s + x.tempatIbadah.gereja, 0)
        },
        panjangJalanKm: parseFloat(saranaPrasarana.reduce((s, x) => s + x.panjangJalanKm, 0).toFixed(1)),
        jumlahJembatan: saranaPrasarana.reduce((s, x) => s + x.jumlahJembatan, 0),
        pasarDesa: saranaPrasarana.reduce((s, x) => s + x.pasarDesa, 0),
        balaiDesa: true
      };

      return {
        nama: "Se-Kecamatan Belitang Mulya (Agregat)",
        luas: villages.reduce((s, x) => s + x.luasWilayahHektar, 0),
        k: aggK,
        se: aggSE,
        sp: aggSP
      };
    }
  };

  const { nama, luas, k, se, sp } = getActiveVillageData();

  return (
    <div className="space-y-6">
      {/* Scope Filter Section */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <span className="text-xs font-bold uppercase tracking-wider text-slate-900 border-l-2 border-yellow-500 px-2.5 py-0.5">
            3.0 Monografi Desa
          </span>
          <h3 className="text-lg font-bold text-slate-800 mt-1">
            Data Monografi & Sensus Administratif
          </h3>
          <p className="text-xs text-slate-500 mt-0.5">
            Menganalisis kondisi kependudukan, sosio-ekonomi, prasarana fisik, dan ketersediaan lahan secara akurat.
          </p>
        </div>

        {/* Dropdown to pick active village context */}
        <div className="flex items-center gap-2.5">
          <label className="text-xs font-semibold text-slate-400 uppercase">Wilayah:</label>
          <select
            value={selectedVillageId || ""}
            onChange={(e) => onSelectVillage(e.target.value ? e.target.value : null)}
            className="text-xs font-bold text-slate-800 border border-slate-200 rounded-lg bg-slate-50 px-3 py-1.5 focus:outline-none focus:border-yellow-500 cursor-pointer"
          >
            <option value="">Seluruh Kecamatan (Semua Desa)</option>
            {villages.map((v) => (
              <option key={v.id} value={v.id}>
                {v.nama}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Monografi Tabs Navigation */}
      <div className="flex border-b border-slate-200 gap-1 overflow-x-auto pb-px">
        <button
          onClick={() => setActiveSubTab("kependudukan")}
          className={`px-4 py-2.5 text-xs font-bold uppercase transition-all tracking-wider ${
            activeSubTab === "kependudukan"
              ? "border-b-2 border-yellow-500 text-slate-900"
              : "text-slate-500 hover:text-slate-800"
          }`}
        >
          3.1 Kependudukan ({k?.jumlahPenduduk.toLocaleString() || 0} Jiwa)
        </button>
        <button
          onClick={() => setActiveSubTab("sosial_ekonomi")}
          className={`px-4 py-2.5 text-xs font-bold uppercase transition-all tracking-wider ${
            activeSubTab === "sosial_ekonomi"
              ? "border-b-2 border-yellow-500 text-slate-900"
              : "text-slate-500 hover:text-slate-800"
          }`}
        >
          3.2 Sosial Ekonomi
        </button>
        <button
          onClick={() => setActiveSubTab("sarana_prasarana")}
          className={`px-4 py-2.5 text-xs font-bold uppercase transition-all tracking-wider ${
            activeSubTab === "sarana_prasarana"
              ? "border-b-2 border-yellow-500 text-slate-900"
              : "text-slate-500 hover:text-slate-800"
          }`}
        >
          3.3 Sarana Prasarana
        </button>
        <button
          onClick={() => setActiveSubTab("luas_wilayah")}
          className={`px-4 py-2.5 text-xs font-bold uppercase transition-all tracking-wider ${
            activeSubTab === "luas_wilayah"
              ? "border-b-2 border-yellow-500 text-slate-900"
              : "text-slate-500 hover:text-slate-800"
          }`}
        >
          3.4 Luas Wilayah ({luas} Ha)
        </button>
      </div>

      <div className="bg-slate-50 rounded-2xl border border-slate-100 p-1">
        {/* TAB 3.1 KEPENDUDUKAN */}
        {activeSubTab === "kependudukan" && k && (
          <div className="grid grid-cols-1 md:grid-cols-12 gap-6 p-4">
            {/* Demographic Numbers Box */}
            <div className="md:col-span-4 bg-white p-5 rounded-2xl border border-slate-200/60 shadow-sm space-y-4">
              <h4 className="text-xs font-bold uppercase text-slate-400 tracking-wider">Demografi: {nama}</h4>
              <div className="space-y-3">
                <div className="p-3 bg-slate-50 rounded-xl">
                  <div className="text-[10px] text-slate-500">TOTAL POPULASI PENDUDUK</div>
                  <div className="text-2xl font-black text-slate-800 font-mono mt-0.5">
                    {k.jumlahPenduduk.toLocaleString("id-ID")}
                  </div>
                  <div className="text-[9px] text-slate-400 mt-1">Sensus Mandiri Kecamatan</div>
                </div>

                <div className="p-3 bg-slate-50 rounded-xl">
                  <div className="text-[10px] text-slate-500">JUMLAH KEPALA KELUARGA (KK)</div>
                  <div className="text-xl font-black text-slate-800 font-mono mt-0.5">
                    {k.jumlahKK.toLocaleString("id-ID")}
                  </div>
                  <p className="text-[9px] text-slate-400 mt-1">Rata-rata {Math.round(k.jumlahPenduduk / k.jumlahKK)} Jiwa / KK</p>
                </div>
              </div>

              {/* Laki-Laki vs Perempuan Gauge */}
              <div className="space-y-2">
                <div className="flex justify-between text-xs text-slate-600">
                  <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 bg-sky-500 rounded-full" /> Laki-Laki ({k.jumlahLakiLaki.toLocaleString()})</span>
                  <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 bg-pink-500 rounded-full" /> Perempuan ({k.jumlahPerempuan.toLocaleString()})</span>
                </div>
                <div className="w-full bg-slate-100 h-3 rounded-full overflow-hidden flex">
                  <div
                    className="h-full bg-sky-400"
                    style={{ width: `${(k.jumlahLakiLaki / k.jumlahPenduduk) * 100}%` }}
                    title={`Laki-laki: ${Math.round((k.jumlahLakiLaki / k.jumlahPenduduk) * 100)}%`}
                  />
                  <div
                    className="h-full bg-pink-400"
                    style={{ width: `${(k.jumlahPerempuan / k.jumlahPenduduk) * 100}%` }}
                    title={`Perempuan: ${Math.round((k.jumlahPerempuan / k.jumlahPenduduk) * 100)}%`}
                  />
                </div>
              </div>
            </div>

            {/* Age Distribution SVG Chart */}
            <div className="md:col-span-5 bg-white p-5 rounded-2xl border border-slate-200/60 shadow-sm space-y-4">
              <h4 className="text-xs font-bold uppercase text-slate-400 tracking-wider">Distribusi Rentang Usia</h4>
              
              <div className="space-y-3.5">
                {[
                  { label: "Balita (0-5 tahun)", val: k.distribusiUsia.balita, color: "bg-yellow-500" },
                  { label: "Anak-Anak (6-12 tahun)", val: k.distribusiUsia.anak, color: "bg-teal-500" },
                  { label: "Remaja (13-18 tahun)", val: k.distribusiUsia.remaja, color: "bg-indigo-500" },
                  { label: "Produktif (19-59 tahun)", val: k.distribusiUsia.produktif, color: "bg-sky-500" },
                  { label: "Lansia (60+ tahun)", val: k.distribusiUsia.lansia, color: "bg-amber-500" }
                ].map((item, idx) => {
                  const pct = Math.round((item.val / k.jumlahPenduduk) * 100);
                  return (
                    <div key={idx} className="space-y-1">
                      <div className="flex justify-between text-xs font-medium text-slate-700">
                        <span>{item.label}</span>
                        <span className="font-mono">{item.val.toLocaleString()} ({pct}%)</span>
                      </div>
                      <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                        <div className={`h-full ${item.color} rounded-full`} style={{ width: `${pct}%` }} />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Religion Panel */}
            <div className="md:col-span-3 bg-white p-5 rounded-2xl border border-slate-200/60 shadow-sm space-y-4 flex flex-col justify-between">
              <div>
                <h4 className="text-xs font-bold uppercase text-slate-400 tracking-wider mb-3">Distribusi Keyakinan</h4>
                <div className="space-y-3 text-xs">
                  <div className="flex items-center justify-between border-b border-slate-100 pb-1.5">
                    <span className="font-medium text-slate-700">Islam</span>
                    <span className="font-mono bg-yellow-50 text-yellow-905 bg-yellow-50 font-bold border border-yellow-250 text-yellow-900 px-2 py-0.5 rounded font-bold">
                      {k.agama.islam.toLocaleString()}
                    </span>
                  </div>
                  <div className="flex items-center justify-between border-b border-slate-100 pb-1.5">
                    <span className="font-medium text-slate-500 opacity-80">Kristen Protestan</span>
                    <span className="font-mono text-slate-600 p-0.5">{k.agama.kristen.toLocaleString()}</span>
                  </div>
                  <div className="flex items-center justify-between border-b border-slate-100 pb-1.5">
                    <span className="font-medium text-slate-500 opacity-80">Katolik</span>
                    <span className="font-mono text-slate-600 p-0.5">{k.agama.katolik.toLocaleString()}</span>
                  </div>
                  <div className="flex items-center justify-between border-b border-slate-100 pb-1.5">
                    <span className="font-medium text-slate-500 opacity-80">Buddha</span>
                    <span className="font-mono text-slate-600 p-0.5">{k.agama.buddha.toLocaleString()}</span>
                  </div>
                </div>
              </div>
              <div className="bg-amber-50 p-2.5 rounded-lg border border-amber-200 text-[10px] text-amber-900 leading-tight">
                <strong>Catatan Kerukunan:</strong> Wilayah Belitang Mulya tergolong luhur, damai, berlandaskan adat Istiadat komering serta melayu Sumsel yang religius.
              </div>
            </div>
          </div>
        )}

        {/* TAB 3.2 SOSIAL EKONOMI */}
        {activeSubTab === "sosial_ekonomi" && se && (
          <div className="grid grid-cols-1 md:grid-cols-12 gap-6 p-4">
            {/* Employment Bento Column */}
            <div className="md:col-span-7 bg-white p-5 rounded-2xl border border-slate-200/60 shadow-sm space-y-4">
              <div className="flex justify-between items-center">
                <h4 className="text-xs font-bold uppercase text-slate-400 tracking-wider">
                  Mata Pencaharian Penduduk (3.2 Pekerjaan)
                </h4>
                <span className="text-[10px] text-yellow-600 font-bold bg-yellow-50 border border-yellow-200 px-2 py-0.5 rounded">Sentra UMKM</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {[
                  { label: "Petani Padi Organik & Sawah", val: se.pekerjaan.petaniKaret, desc: "Sektor Swasembada Padi", color: "border-l-rose-500" },
                  { label: "Pekebun Jeruk & Hortikultura", val: se.pekerjaan.petaniNanas, desc: "Sektor Lahan Buah", color: "border-l-amber-500" },
                  { label: "Pengrajin Anyaman Bambu/Rotan", val: se.pekerjaan.pengrajinTenun, desc: "UMKM Anyaman Kreatif", color: "border-l-violet-500" },
                  { label: "Peternak Sapi & Unggas", val: se.pekerjaan.tukangKayuPanggung, desc: "Sektor Ternak Mandiri", color: "border-l-yellow-500" },
                  { label: "Pelaku UMKM Kuliner Rakyat", val: se.pekerjaan.pedagang, desc: "Keripik & Produk Olahan", color: "border-l-sky-500" },
                  { label: "ASN / PNS / TNI / POLRI", val: se.pekerjaan.pnsTniPolri, desc: "Layanan Pemerintah", color: "border-l-slate-400" },
                  { label: "Buruh Swasta & Kebun Sawit", val: se.pekerjaan.buruh, desc: "Pekerja Upah Harian", color: "border-l-indigo-500" }
                ].map((job, idx) => (
                  <div key={idx} className={`p-2.5 bg-slate-50 rounded-xl border border-slate-200/40 border-l-4 ${job.color} flex justify-between items-center`}>
                    <div>
                      <div className="text-xs font-bold text-slate-800">{job.label}</div>
                      <div className="text-[9px] text-slate-400">{job.desc}</div>
                    </div>
                    <span className="text-xs font-mono font-bold text-slate-700 bg-white border px-1.5 py-0.5 rounded shadow-sm">
                      {job.val.toLocaleString("id-ID")}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Education Spread Column */}
            <div className="md:col-span-5 bg-white p-5 rounded-2xl border border-slate-200/60 shadow-sm space-y-4 flex flex-col justify-between">
              <div>
                <h4 className="text-xs font-bold uppercase text-slate-400 tracking-wider">
                  Pendidikan Terakhir Terdata
                </h4>
                <p className="text-[10px] text-slate-400 mb-4">Grafik rasio lulusan se-wilayah terpilih</p>

                <div className="space-y-3.5 text-xs text-slate-600">
                  {[
                    { label: "Tidak/Belum Sekolah", val: se.pendidikan.tidakSekolah, icon: Compass },
                    { label: "SD / Sederajat", val: se.pendidikan.sd, icon: BookOpen },
                    { label: "SMP / Sederajat", val: se.pendidikan.smp, icon: BookOpen },
                    { label: "SMA / SMK / Sederajat", val: se.pendidikan.sma, icon: GraduationCap },
                    { label: "Diploma / Sarjana (S1-S3)", val: se.pendidikan.diplomaSarjana, icon: GraduationCap }
                  ].map((edu, idx) => {
                    const totalEdu = se.pendidikan.tidakSekolah + se.pendidikan.sd + se.pendidikan.smp + se.pendidikan.sma + se.pendidikan.diplomaSarjana;
                    const pct = Math.round((edu.val / totalEdu) * 100) || 0;
                    return (
                      <div key={idx} className="space-y-1">
                        <div className="flex justify-between font-medium">
                          <span>{edu.label}</span>
                          <span className="font-mono">{edu.val.toLocaleString()} ({pct}%)</span>
                        </div>
                        <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
                          <div className="h-full bg-yellow-500 rounded-full" style={{ width: `${pct}%` }} />
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Administrative Summary mini */}
              <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 text-xs grid grid-cols-2 gap-4">
                <div>
                  <div className="text-[10px] text-slate-400 uppercase font-semibold">Tenaga Kesehatan</div>
                  <div className="font-bold text-slate-800 text-sm mt-0.5">{se.jumlahNakes} Nakes di Desa</div>
                </div>
                <div>
                  <div className="text-[10px] text-slate-400 uppercase font-semibold">Tingkat Dusun</div>
                  <div className="font-bold text-slate-800 text-sm mt-0.5">{se.jumlahDusun} Blok Terdaftar</div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 3.3 SARANA PRASARANA */}
        {activeSubTab === "sarana_prasarana" && sp && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 p-4">
            {/* Pendidikan & Sapras Ibadah */}
            <div className="bg-white p-5 rounded-2xl border border-slate-200/60 shadow-sm space-y-4">
              <h4 className="text-xs font-bold uppercase text-slate-400 tracking-wider">
                Sarana Pendidikan & Ibadah
              </h4>
              <div className="space-y-3">
                <div className="bg-slate-50 p-3 rounded-xl space-y-2">
                  <span className="text-[10px] text-slate-400 uppercase font-bold">Gedung Pendidikan</span>
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div>SD: <strong>{sp.sekolah.sd} unit</strong></div>
                    <div>SMP: <strong>{sp.sekolah.smp} unit</strong></div>
                    <div>SMA: <strong>{sp.sekolah.sma} unit</strong></div>
                    <div>PAUD: <strong>{sp.sekolah.paud} unit</strong></div>
                  </div>
                </div>

                <div className="bg-slate-50 p-3 rounded-xl space-y-2">
                  <span className="text-[10px] text-slate-400 uppercase font-bold">Tempat Ibadah</span>
                  <div className="grid grid-cols-3 gap-1 text-xs">
                    <div>Masjid: <strong>{sp.tempatIbadah.masjid}</strong></div>
                    <div>Mushola: <strong>{sp.tempatIbadah.mushola}</strong></div>
                    <div>Gereja: <strong>{sp.tempatIbadah.gereja}</strong></div>
                  </div>
                </div>
              </div>
            </div>

            {/* Faskes & Balai */}
            <div className="bg-white p-5 rounded-2xl border border-slate-200/60 shadow-sm space-y-4">
              <h4 className="text-xs font-bold uppercase text-slate-400 tracking-wider">
                Fasilitas Kesehatan & Umum
              </h4>
              <div className="space-y-3">
                <div className="bg-slate-50 p-3 rounded-xl space-y-2">
                  <span className="text-[10px] text-slate-400 uppercase font-bold">Sarana Kesehatan</span>
                  <div className="space-y-1.5 text-xs text-slate-700">
                    <div className="flex justify-between">
                      <span>Puskesmas / Pustu:</span>
                      <strong>{sp.fasilitasKesehatan.puskesmasPustu} Unit</strong>
                    </div>
                    <div className="flex justify-between">
                      <span>Posyandu Lingkungan:</span>
                      <strong>{sp.fasilitasKesehatan.posyandu} Titik</strong>
                    </div>
                    <div className="flex justify-between">
                      <span>Praktek Bidan Mandiri:</span>
                      <strong>{sp.fasilitasKesehatan.bidanPraktek} Lapak</strong>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs text-center">
                  <div className="p-2.5 bg-slate-50 rounded-xl">
                    <div className="text-[9px] text-slate-400 uppercase">Pasar Desa</div>
                    <strong className="text-slate-800 text-sm mt-0.5 inline-block">
                      {sp.pasarDesa > 0 ? `${sp.pasarDesa} Lokasi` : "Tidak Ada"}
                    </strong>
                  </div>
                  <div className="p-2.5 bg-slate-50 rounded-xl">
                    <div className="text-[9px] text-slate-400 uppercase">Balai Pertemuan</div>
                    <strong className="text-yellow-600 text-sm font-bold mt-0.5 inline-block">
                      {sp.balaiDesa ? "Tersedia" : "Absen"}
                    </strong>
                  </div>
                </div>
              </div>
            </div>

            {/* Transportasi & Infrastruktur */}
            <div className="bg-white p-5 rounded-2xl border border-slate-200/60 shadow-sm space-y-4 flex flex-col justify-between">
              <div>
                <h4 className="text-xs font-bold uppercase text-slate-400 tracking-wider">
                  Logistik & Infrastruktur Jalan
                </h4>
                <p className="text-[10px] text-slate-400 mt-1 mb-3">Panjang jaringan jalan yang melintasi pemukiman</p>

                <div className="space-y-3">
                  <div className="p-3 bg-slate-50 rounded-xl">
                     <span className="text-[10px] text-slate-400 uppercase">Total Panjang Jalan Desa</span>
                     <div className="text-xl font-black text-slate-800 font-mono mt-0.5">{sp.panjangJalanKm} Kilometer</div>
                  </div>

                  <div className="p-3 bg-slate-50 rounded-xl">
                     <span className="text-[10px] text-slate-400 uppercase">Bentang Jembatan Desa</span>
                     <div className="text-xl font-black text-slate-800 font-mono mt-0.5">{sp.jumlahJembatan} Jembatan</div>
                  </div>
                </div>
              </div>
              <div className="text-[9px] text-slate-400 text-center animate-pulse">
                Terakhir diperbaharui via Sistem CMS Dinas Perhubungan OKU Timur
              </div>
            </div>
          </div>
        )}

        {/* TAB 3.4 LUAS WILAYAH */}
        {activeSubTab === "luas_wilayah" && (
          <div className="p-4">
            <div className="bg-white p-6 rounded-2xl border border-slate-200/60 shadow-sm space-y-5">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-yellow-101 bg-yellow-50 rounded-full flex items-center justify-center text-yellow-600 border border-yellow-250">
                  <Home className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-slate-800">Cakupan Wilayah Daratan & Lahan Gambut</h4>
                  <p className="text-xs text-slate-400">Total Hektar lahan basah pasang surut dan perkebunan kering</p>
                </div>
              </div>

              {/* Dynamic comparisons */}
              <div className="grid grid-cols-1 md:grid-cols-12 gap-5 items-center">
                <div className="md:col-span-5 bg-slate-50 p-4 rounded-xl border border-slate-100">
                  <span className="text-[10px] text-slate-400 uppercase">PROPORSI KONTRIBUSI LAHAN DESA</span>
                  <div className="text-3xl font-black text-slate-800 font-mono mt-1">{luas.toLocaleString()} Ha</div>
                  <p className="text-xs text-slate-500 mt-2">
                    Desa {nama} memberikan kontribusi seluas <strong>{Math.round((luas / villages.reduce((s, x) => s + x.luasWilayahHektar, 0)) * 100)}%</strong> dari total wilayah administratif Kecamatan Belitang Mulya.
                  </p>
                </div>

                <div className="md:col-span-7 space-y-3">
                  <div className="text-[10px] text-slate-400 uppercase font-semibold">Rasio Perbandingan Seluruh Desa</div>
                  {villages.map((v) => {
                    const scalePct = Math.round((v.luasWilayahHektar / 1450) * 100); // 1450 max ha
                    const isActive = v.id === selectedVillageId;
                    return (
                      <div key={v.id} className="space-y-1">
                        <div className="flex justify-between text-xs">
                          <span className={isActive ? "font-bold text-yellow-600 pl-1.5 border-l-2 border-yellow-500" : "text-slate-600"}>{v.nama}</span>
                          <span className="font-mono text-slate-400">{v.luasWilayahHektar} Ha</span>
                        </div>
                        <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
                          <div
                            className={`h-full ${isActive ? "bg-[#0F172A]" : "bg-slate-200"} rounded-full`}
                            style={{ width: `${scalePct}%` }}
                          />
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
