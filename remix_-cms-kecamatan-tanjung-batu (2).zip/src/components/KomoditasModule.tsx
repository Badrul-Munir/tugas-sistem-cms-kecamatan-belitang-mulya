/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, FormEvent } from "react";
import {
  TrendingUp,
  Tag,
  Boxes,
  Compass,
  Award,
  Search,
  CheckCircle,
  Plus,
  Trash,
  SlidersHorizontal
} from "lucide-react";
import { Komoditas, Desa, UserRole } from "../types";

interface KomoditasModuleProps {
  komoditas: Komoditas[];
  villages: Desa[];
  activeRole: UserRole;
  operatorVillageId: string | null;
  onAddKomoditas: (newKom: Omit<Komoditas, "id">) => void;
  onToggleUnggulan: (komId: string) => void;
  onDeleteKomoditas: (komId: string) => void;
}

export default function KomoditasModule({
  komoditas,
  villages,
  activeRole,
  operatorVillageId,
  onAddKomoditas,
  onToggleUnggulan,
  onDeleteKomoditas
}: KomoditasModuleProps) {
  const [selectedVillageId, setSelectedVillageId] = useState<string>("");
  const [selectedKategori, setSelectedKategori] = useState<string>("");
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [selectedKomoditas, setSelectedKomoditas] = useState<Komoditas | null>(komoditas[0] || null);

  // New Komoditas form controls
  const [showAddForm, setShowAddForm] = useState(false);
  const [formNama, setFormNama] = useState("");
  const [formKategori, setFormKategori] = useState<Komoditas["kategori"]>("Pertanian");
  const [formDesaId, setFormDesaId] = useState(villages[0]?.id || "");
  const [formProduksi, setFormProduksi] = useState("");
  const [formLahan, setFormLahan] = useState("");
  const [formPeriode, setFormPeriode] = useState("");
  const [formKeterangan, setFormKeterangan] = useState("");

  const categories = [
    "Pertanian",
    "Perkebunan",
    "Peternakan",
    "Perikanan",
    "UMKM Kerajinan",
    "Industri Rumah Tangga",
    "Jasa"
  ];

  // Filtering
  const filteredKomoditas = komoditas.filter((k) => {
    const matchesQuery = k.namaKomoditas.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          k.keterangan.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesVillage = !selectedVillageId || k.desaId === selectedVillageId;
    const matchesKategori = !selectedKategori || k.kategori === selectedKategori;
    return matchesQuery && matchesVillage && matchesKategori;
  });

  const canEditKomoditas = (vId: string) => {
    if (activeRole === "Camat/Admin Kecamatan") return true;
    if (activeRole === "Operator Desa" && operatorVillageId === vId) return true;
    return false;
  };

  const handleCreateKomoditas = (e: FormEvent) => {
    e.preventDefault();
    if (!formNama) return;

    onAddKomoditas({
      desaId: formDesaId,
      namaKomoditas: formNama,
      kategori: formKategori,
      estimasiProduksiTahunan: formProduksi || "N/A",
      luasLahanHektarOrUnit: formLahan || "N/A",
      periodeProduksi: formPeriode || "Setiap Bulan",
      statusUnggulan: false,
      keterangan: formKeterangan,
      fotoUrl: "https://images.unsplash.com/photo-1544816155-12df9643f363?auto=format&fit=crop&q=80&w=400"
    });

    // Reset Form
    setFormNama("");
    setFormProduksi("");
    setFormLahan("");
    setFormPeriode("");
    setFormKeterangan("");
    setShowAddForm(false);
  };

  return (
    <div className="space-y-6">
      {/* 4.6 Filter & Pencarian Komoditas */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-slate-900 border-l-2 border-yellow-500 px-2.5 py-0.5">
              4.0 Komoditas & Potensi Ekonomi
            </span>
            <h3 className="text-lg font-bold text-slate-800 mt-1">
              Peta Sebaran Komoditas Unggulan Desa
            </h3>
            <p className="text-xs text-slate-500">
              Analisis kapasitas industri rakyat dan sektor perkebunan sumatera selatan.
            </p>
          </div>

          <div className="flex gap-2">
            {activeRole !== "Publik/Pengunjung" && (
              <button
                onClick={() => {
                  if (activeRole === "Operator Desa" && operatorVillageId) {
                    setFormDesaId(operatorVillageId);
                  }
                  setShowAddForm(!showAddForm);
                }}
                className="bg-[#0F172A] hover:bg-[#1E293B] text-white text-xs font-semibold px-4 py-2 rounded-lg transition-all flex items-center gap-1.5"
              >
                <Plus className="w-4 h-4" /> Tambah Komoditas
              </button>
            )}
          </div>
        </div>

        {/* Filters Controls Area */}
        <div className="grid grid-cols-1 sm:grid-cols-3 md:grid-cols-4 gap-3 bg-slate-50 p-3.5 rounded-xl border border-slate-200/60">
          <div className="relative">
            <Search className="absolute left-3 top-2.5 w-3.5 h-3.5 text-slate-400" />
            <input
              type="text"
              placeholder="Cari komoditas..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9 pr-3 py-1.5 text-xs bg-white border border-slate-200 rounded-lg w-full focus:outline-none focus:border-yellow-500"
            />
          </div>

          <select
            value={selectedVillageId}
            onChange={(e) => setSelectedVillageId(e.target.value)}
            className="text-xs bg-white border border-slate-200 rounded-lg py-1.5 px-2.5 w-full focus:outline-none cursor-pointer"
          >
            <option value="">Semua Wilayah Desa</option>
            {villages.map((v) => (
              <option key={v.id} value={v.id}>
                {v.nama}
              </option>
            ))}
          </select>

          <select
            value={selectedKategori}
            onChange={(e) => setSelectedKategori(e.target.value)}
            className="text-xs bg-white border border-slate-200 rounded-lg py-1.5 px-2.5 w-full focus:outline-none cursor-pointer"
          >
            <option value="">Semua Sektor Kategori</option>
            {categories.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>

          <div className="text-[10px] text-slate-400 flex items-center justify-end pr-1 sm:col-span-3 md:col-span-1 font-mono font-bold">
            {filteredKomoditas.length} Data komoditas lolos filter
          </div>
        </div>
      </div>

      {/* Add Komoditas Form Panel */}
      {showAddForm && (
        <form onSubmit={handleCreateKomoditas} className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm grid grid-cols-1 md:grid-cols-12 gap-5">
          <div className="md:col-span-12 border-b border-slate-100 pb-3 flex justify-between items-center">
            <h4 className="text-sm font-bold text-slate-800">Daftarkan Produk Komoditas Baru</h4>
            <button type="button" onClick={() => setShowAddForm(false)} className="text-xs text-slate-400 hover:text-slate-600">Batal</button>
          </div>

          <div className="md:col-span-4">
            <label className="block text-[10px] uppercase font-bold text-slate-500 mb-1">Nama Komoditas / Hasil Alam</label>
            <input
              required
              type="text"
              placeholder="Contoh: Karet Bersih (Lateks)"
              value={formNama}
              onChange={(e) => setFormNama(e.target.value)}
              className="w-full text-xs border border-slate-200 rounded-lg p-2 focus:outline-none focus:border-yellow-500"
            />
          </div>

          <div className="md:col-span-4">
            <label className="block text-[10px] uppercase font-bold text-slate-500 mb-1">Kategori Potensi</label>
            <select
              value={formKategori}
              onChange={(e) => setFormKategori(e.target.value as Komoditas["kategori"])}
              className="w-full text-xs border border-slate-200 rounded-lg p-2 focus:outline-none"
            >
              {categories.map((c) => (
                <option key={c} value={c}>{c}</option>
              ))}
            </select>
          </div>

          <div className="md:col-span-4">
            <label className="block text-[10px] uppercase font-bold text-slate-500 mb-1">Desa Asal / Lokasi Lahan</label>
            <select
              disabled={activeRole === "Operator Desa"}
              value={formDesaId}
              onChange={(e) => setFormDesaId(e.target.value)}
              className="w-full text-xs border border-slate-200 rounded-lg p-2 focus:outline-none disabled:bg-slate-50"
            >
              {villages.map((v) => (
                <option key={v.id} value={v.id}>{v.nama}</option>
              ))}
            </select>
          </div>

          <div className="md:col-span-4">
            <label className="block text-[10px] uppercase font-bold text-slate-500 mb-1">Estimasi Hasil Produksi</label>
            <input
              type="text"
              placeholder="Contoh: 1.200 Ton / Tahun"
              value={formProduksi}
              onChange={(e) => setFormProduksi(e.target.value)}
              className="w-full text-xs border border-slate-200 rounded-lg p-2 focus:outline-none focus:border-yellow-500"
            />
          </div>

          <div className="md:col-span-4">
            <label className="block text-[10px] uppercase font-bold text-slate-500 mb-1">Luas Lahan / Jumlah Pengrajin</label>
            <input
              type="text"
              placeholder="Contoh: 800 Hektar"
              value={formLahan}
              onChange={(e) => setFormLahan(e.target.value)}
              className="w-full text-xs border border-slate-200 rounded-lg p-2 focus:outline-none"
            />
          </div>

          <div className="md:col-span-4">
            <label className="block text-[10px] uppercase font-bold text-slate-500 mb-1">Masa / Periode Panen</label>
            <input
              type="text"
              placeholder="Contoh: Setiap Bulan"
              value={formPeriode}
              onChange={(e) => setFormPeriode(e.target.value)}
              className="w-full text-xs border border-slate-200 rounded-lg p-2 focus:outline-none"
            />
          </div>

          <div className="md:col-span-12">
            <label className="block text-[10px] uppercase font-bold text-slate-500 mb-1">Keterangan Spesifikasi Komoditas</label>
            <textarea
              placeholder="Jelaskan kualitas, tekstur, atau pasar ekspornya..."
              value={formKeterangan}
              onChange={(e) => setFormKeterangan(e.target.value)}
              className="w-full text-xs border border-slate-200 rounded-lg p-2 focus:outline-none focus:border-yellow-500 h-20"
            />
          </div>

          <div className="md:col-span-12 flex justify-end gap-2">
            <button
              type="button"
              onClick={() => setShowAddForm(false)}
              className="px-4 py-2 border border-slate-200 text-xs text-slate-600 rounded-lg hover:bg-slate-50"
            >
              Batal
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-[#0F172A] hover:bg-[#1E293B] text-white rounded-lg text-xs font-black shadow-sm"
            >
              Simpan Master Komoditas
            </button>
          </div>
        </form>
      )}

      {/* REKAP KOMODITAS DATA - Analisis agregat potensi kecamatan */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 bg-slate-900 text-white rounded-2xl p-5 border border-slate-950 shadow-md">
        <div className="space-y-1">
          <span className="text-[9px] uppercase tracking-wider text-yellow-400 font-bold font-mono">Total Hasil Komoditas</span>
          <div className="text-2xl font-black">{komoditas.length} Potensi</div>
          <p className="text-[10px] text-slate-400">Total komoditas alam & industri kreatif se-kecamatan.</p>
        </div>
        <div className="space-y-1 border-t sm:border-t-0 sm:border-l border-slate-800 pt-3 sm:pt-0 sm:pl-4">
          <span className="text-[9px] uppercase tracking-wider text-yellow-400 font-bold font-mono">Komoditas Unggulan</span>
          <div className="text-2xl font-black">{komoditas.filter((k) => k.statusUnggulan).length} Unggulan</div>
          <p className="text-[10px] text-slate-400">Telah ditandai & dibina langsung oleh Dinas Kecamatan.</p>
        </div>
        <div className="space-y-1 border-t sm:border-t-0 sm:border-l border-slate-800 pt-3 sm:pt-0 sm:pl-4">
          <span className="text-[9px] uppercase tracking-wider text-yellow-400 font-bold font-mono">Sektor Produksi Terdata</span>
          <div className="text-2xl font-black">{categories.length} Sektor Utama</div>
          <p className="text-[10px] text-slate-400 flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 bg-green-500 rounded-full animate-ping" />
            Terhubung real-time dengan Monografi Sektor.
          </p>
        </div>
      </div>

      {/* Grid Layout listing filtered items & the Inspection Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* 4.1 Daftar Komoditas Table / Grid */}
        <div className="lg:col-span-7 bg-white rounded-2xl border border-slate-200 p-5 shadow-sm space-y-4">
          <h4 className="text-xs font-bold uppercase text-slate-400 tracking-wider">
            4.1 Daftar Seluruh Komoditas Wilayah
          </h4>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {filteredKomoditas.length > 0 ? (
              filteredKomoditas.map((k) => {
                const parentDesa = villages.find((v) => v.id === k.desaId);
                const isSelected = selectedKomoditas?.id === k.id;

                return (
                  <div
                    key={k.id}
                    onClick={() => setSelectedKomoditas(k)}
                    className={`p-3.5 rounded-xl border transition-all cursor-pointer flex flex-col justify-between ${
                      isSelected
                        ? "border-yellow-500 bg-yellow-500/[0.04] shadow-sm"
                        : "border-slate-100 hover:border-yellow-300 hover:bg-slate-50/50"
                    }`}
                  >
                    <div>
                      <div className="flex justify-between items-center mb-1.5">
                        <span className="text-[8px] font-bold uppercase tracking-wider text-yellow-800 bg-yellow-50 border border-yellow-200 px-2 py-0.5 rounded">
                          {k.kategori}
                        </span>
                        {k.statusUnggulan && (
                          <span className="text-[8px] font-black uppercase text-amber-800 bg-amber-100 px-1.5 py-0.5 rounded flex items-center gap-0.5">
                            ★ Unggulan (4.4)
                          </span>
                        )}
                      </div>
                      <h5 className="text-xs font-bold text-slate-800">{k.namaKomoditas}</h5>
                      <span className="text-[10px] text-slate-400">Asal: {parentDesa?.nama}</span>
                    </div>

                    <div className="border-t border-slate-100/60 mt-3 pt-2.5 flex justify-between items-center text-[10px] text-slate-500">
                      <span>Produksi: <strong className="text-slate-800">{k.estimasiProduksiTahunan}</strong></span>
                      {canEditKomoditas(k.desaId) && (
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            onDeleteKomoditas(k.id);
                          }}
                          className="text-rose-500 hover:text-white hover:bg-rose-600 p-1 rounded font-bold"
                          title="Hapus"
                        >
                          Hapus
                        </button>
                      )}
                    </div>
                  </div>
                );
              })
            ) : (
              <p className="col-span-2 text-center py-12 text-slate-400 text-xs">
                Tidak ada komoditas terdaftar yang cocok dengan kriteria filter.
              </p>
            )}
          </div>
        </div>

        {/* 4.3 Detail Komoditas Inspector & Sebaran */}
        <div className="lg:col-span-5">
          {selectedKomoditas ? (
            <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm space-y-4">
              <div className="relative rounded-xl overflow-hidden h-40 border border-slate-200">
                <img
                  referrerPolicy="no-referrer"
                  src={selectedKomoditas.fotoUrl}
                  alt={selectedKomoditas.namaKomoditas}
                  className="w-full h-full object-cover"
                />
                <div className="absolute top-2 right-2 bg-slate-900/80 text-white font-mono text-[9px] px-2 py-0.5 rounded">
                  {selectedKomoditas.kategori}
                </div>
              </div>

              <div>
                <h4 className="text-sm font-bold text-slate-400 uppercase tracking-wider text-[9px]">4.3 Detail Komoditas Desa</h4>
                <h3 className="text-base font-black text-slate-800 mt-1">{selectedKomoditas.namaKomoditas}</h3>
                <p className="text-xs text-slate-500 mt-1">
                  Desa Pemegang: <strong className="text-slate-700">{villages.find((v) => v.id === selectedKomoditas.desaId)?.nama}</strong>
                </p>
              </div>

              <div className="bg-slate-50 p-4 rounded-xl space-y-2.5 text-xs">
                <div className="flex justify-between items-center border-b border-slate-200/50 pb-1.5">
                  <span className="text-slate-500">Kapasitas Produksi:</span>
                  <span className="font-mono text-slate-800 font-bold">{selectedKomoditas.estimasiProduksiTahunan}</span>
                </div>
                <div className="flex justify-between items-center border-b border-slate-200/50 pb-1.5">
                  <span className="text-slate-500">Cakupan Area / Ukuran Usaha:</span>
                  <span className="font-mono text-slate-800 font-bold">{selectedKomoditas.luasLahanHektarOrUnit}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-slate-500">Siklus Pembuatan / Panen:</span>
                  <span className="font-mono text-slate-800 font-bold">{selectedKomoditas.periodeProduksi}</span>
                </div>
              </div>

              <div>
                <h5 className="text-xs font-bold text-slate-700 mb-1">Deskripsi & Potensi Ekonomi</h5>
                <p className="text-xs text-slate-600 leading-relaxed bg-yellow-50/40 p-3 rounded-lg border border-yellow-200/50">
                  {selectedKomoditas.keterangan}
                </p>
              </div>

              {/* Sebaran Komoditas di dalam detail */}
              <div className="border-t border-slate-100/80 pt-4 mt-3 space-y-2.5">
                <div className="flex justify-between items-center">
                  <h5 className="text-[10px] font-black uppercase tracking-wider text-slate-900 flex items-center gap-1">
                    <span className="w-1.5 h-3 bg-yellow-500 rounded-full inline-block" />
                    Sebaran Komoditas Sektor {selectedKomoditas.kategori}
                  </h5>
                  <span className="text-[9px] text-slate-400">Total Sejenis: {komoditas.filter(k => k.kategori === selectedKomoditas.kategori).length}</span>
                </div>
                <p className="text-[10px] text-slate-500 font-medium leading-relaxed">
                  Perbandingan estimasi produksi tahunan komoditas sejenis lintas desa di wilayah Belitang Mulya:
                </p>
                <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
                  {komoditas
                    .filter((k) => k.kategori === selectedKomoditas.kategori)
                    .map((item) => {
                      const villageObj = villages.find((v) => v.id === item.desaId);
                      const isCurrent = item.id === selectedKomoditas.id;
                      return (
                        <div 
                          key={item.id} 
                          className={`flex items-center justify-between text-xs p-2 rounded-xl transition-all ${
                            isCurrent 
                              ? 'bg-yellow-500/[0.06] border border-yellow-300 font-black text-slate-950' 
                              : 'bg-slate-50 hover:bg-slate-100 border border-transparent text-slate-600'
                          }`}
                        >
                          <div className="flex flex-col">
                            <span className="text-[11px] truncate">{item.namaKomoditas}</span>
                            <span className="text-[9px] text-slate-400 font-bold uppercase">{villageObj?.nama || "Sedang Dimuat"}</span>
                          </div>
                          <div className="text-right">
                            <span className="text-[10px] font-mono font-bold bg-[#0F172A] text-white px-2 py-0.5 rounded-lg">
                              {item.estimasiProduksiTahunan}
                            </span>
                          </div>
                        </div>
                      );
                    })}
                </div>
              </div>

              {/* Toggle Unggulan Suku Kecamatan */}
              {canEditKomoditas(selectedKomoditas.desaId) ? (
                <button
                  type="button"
                  onClick={() => onToggleUnggulan(selectedKomoditas.id)}
                  className={`w-full py-2.5 rounded-lg border text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
                    selectedKomoditas.statusUnggulan
                      ? "bg-amber-100 text-amber-800 border-amber-300 hover:bg-amber-200"
                      : "bg-yellow-50 text-yellow-900 border-yellow-250 hover:bg-yellow-100"
                  }`}
                >
                  <Award className="w-4 h-4" />
                  {selectedKomoditas.statusUnggulan
                    ? "Batalkan Status Unggulan Kecamatan"
                    : "Tandai Sebagai Komoditas Unggulan"
                  }
                </button>
              ) : (
                <div className="bg-slate-100 text-slate-500 p-2.5 rounded-lg text-[10px] text-center">
                  Masuk sebagai {activeRole}. Hanya operator {villages.find((v) => v.id === selectedKomoditas.desaId)?.nama} atau Camat yang boleh merubah status unggulan komoditas ini.
                </div>
              )}
            </div>
          ) : (
            <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm text-center text-slate-400 py-16 flex flex-col items-center">
              <Boxes className="w-10 h-10 text-slate-300 mb-2" />
              <p className="text-xs">Klik salah satu produk komoditas untuk menginspeksi rincian panen.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
