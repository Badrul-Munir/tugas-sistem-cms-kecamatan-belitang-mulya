/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from "react";
import {
  Globe,
  Plus,
  Eye,
  FileEdit,
  Send,
  HelpCircle,
  MapPin,
  Compass,
  ArrowRight
} from "lucide-react";
import { Desa, CatatKecamatan, UserRole } from "../types";

interface DataDesaModuleProps {
  villages: Desa[];
  catatanKecamatan: CatatKecamatan[];
  activeRole: UserRole;
  operatorVillageId: string | null;
  onAddCatatan: (desaId: string, catatan: string) => void;
  onUpdateWebStatus: (desaId: string, status: Desa["statusWeb"]) => void;
}

export default function DataDesaModule({
  villages,
  catatanKecamatan,
  activeRole,
  operatorVillageId,
  onAddCatatan,
  onUpdateWebStatus
}: DataDesaModuleProps) {
  const [selectedVillage, setSelectedVillage] = useState<Desa | null>(villages[0] || null);
  const [newCatatan, setNewCatatan] = useState("");
  const [searchQuery, setSearchQuery] = useState("");

  const filteredVillages = villages.filter(
    (v) =>
      v.nama.toLowerCase().includes(searchQuery.toLowerCase()) ||
      v.namaKepalaDesa.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Security check - is the current active role permitted to write notes or change web status?
  const canModifyVillage = (vId: string) => {
    if (activeRole === "Camat/Admin Kecamatan") return true;
    if (activeRole === "Operator Desa" && operatorVillageId === vId) return true;
    return false;
  };

  const handleSendCatatan = (desaId: string) => {
    if (!newCatatan.trim()) return;
    onAddCatatan(desaId, newCatatan.trim());
    setNewCatatan("");
  };

  return (
    <div className="grid grid-cols-1 xl:grid-cols-12 gap-6">
      {/* 2.1 Daftar Desa Registry List */}
      <div className="xl:col-span-7 bg-white rounded-2xl border border-slate-200 p-6 shadow-sm space-y-4">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-slate-900 border-l-2 border-yellow-500 px-2.5 py-0.5">
              2.1 Master Data Desa
            </span>
            <h3 className="text-lg font-bold text-slate-800 mt-1">
              Daftar Kelurahan & Desa Terdaftar
            </h3>
          </div>
          <input
            type="text"
            placeholder="Cari desa / kepala desa..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="text-xs border border-slate-200 rounded-lg px-3 py-1.5 focus:outline-none focus:border-yellow-500 w-full sm:w-48"
          />
        </div>

        <div className="overflow-x-auto border border-slate-100 rounded-xl">
          <table className="min-w-full divide-y divide-slate-100 text-left text-xs">
            <thead className="bg-slate-50 text-slate-500 font-semibold uppercase">
              <tr>
                <th className="px-4 py-3">Nama Desa</th>
                <th className="px-4 py-3">Kode Desa</th>
                <th className="px-4 py-3">Kepala Desa</th>
                <th className="px-4 py-3">Status Web</th>
                <th className="px-4 py-3 text-right">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {filteredVillages.map((v) => {
                const isSelected = selectedVillage?.id === v.id;
                const isRestricted = activeRole === "Operator Desa" && operatorVillageId !== v.id;

                return (
                  <tr
                    key={v.id}
                    className={`hover:bg-slate-50 transition-colors ${
                      isSelected ? "bg-yellow-500/[0.04] border-l-2 border-yellow-500" : ""
                    }`}
                  >
                    <td className="px-4 py-3.5 font-bold text-slate-800">{v.nama}</td>
                    <td className="px-4 py-3.5 font-mono text-slate-500">{v.kodeDesa}</td>
                    <td className="px-4 py-3.5">{v.namaKepalaDesa}</td>
                    <td className="px-4 py-3.5">
                      <select
                        disabled={!canModifyVillage(v.id)}
                        value={v.statusWeb}
                        onChange={(e) => onUpdateWebStatus(v.id, e.target.value as Desa["statusWeb"])}
                        className={`text-[10px] font-bold uppercase rounded px-2 py-0.5 border-0 focus:ring-1 focus:ring-yellow-500 cursor-pointer ${
                          v.statusWeb === "Aktif"
                            ? "bg-yellow-50 text-yellow-905 border border-yellow-250 font-bold"
                            : v.statusWeb === "Draft"
                            ? "bg-amber-100 text-amber-800"
                            : v.statusWeb === "Perlu Diperbarui"
                            ? "bg-rose-100 text-rose-800"
                            : v.statusWeb === "Menunggu Verifikasi"
                            ? "bg-blue-50 text-blue-800 border border-blue-200"
                            : "bg-slate-100 text-slate-700"
                        } disabled:opacity-75 disabled:cursor-not-allowed`}
                      >
                        <option value="Aktif">Aktif</option>
                        <option value="Draft">Draft</option>
                        <option value="Perlu Diperbarui">Perlu Diperbarui</option>
                        <option value="Menunggu Verifikasi">Menunggu Verifikasi</option>
                        <option value="Belum Aktif">Belum Aktif</option>
                      </select>
                    </td>
                    <td className="px-4 py-3.5 text-right space-x-1.5">
                      <button
                        onClick={() => setSelectedVillage(v)}
                        className="p-1 text-slate-500 hover:text-yellow-600 hover:bg-slate-100 rounded transition-colors"
                        title="Lihat Detail Profil"
                      >
                        <Eye className="w-4 h-4 inline" />
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* 2.2 Detail Profil Desa & 2.4 Catatan Kecamatan */}
      <div className="xl:col-span-5 space-y-6">
        {selectedVillage ? (
          <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm space-y-5">
            {/* Header Profil */}
            <div className="border-b border-slate-100 pb-4">
              <div className="flex gap-4 items-start">
                {selectedVillage.fotoKades && (
                  <img
                    referrerPolicy="no-referrer"
                    src={selectedVillage.fotoKades}
                    alt={selectedVillage.namaKepalaDesa}
                    className="w-14 h-14 rounded-full object-cover border-2 border-yellow-500 shadow-sm"
                  />
                )}
                <div className="space-y-1">
                  <div className="text-[10px] uppercase font-mono text-slate-400">DETAIL PROFIL DESA (2.2)</div>
                  <h4 className="text-base font-black text-slate-800">{selectedVillage.nama}</h4>
                  <p className="text-xs text-slate-600 font-medium">Kepala Desa: {selectedVillage.namaKepalaDesa}</p>
                </div>
              </div>
            </div>

            {/* Content Tab Details */}
            <div className="space-y-4 text-xs">
              <div>
                <h5 className="font-bold text-slate-700 mb-1 flex items-center gap-1.5">
                  <Globe className="w-3.5 h-3.5 text-amber-600" />
                  Sejarah Singkat & Asal Usul
                </h5>
                <p className="text-slate-600 leading-relaxed text-[11px] bg-slate-50 p-2.5 rounded-lg italic">
                  &ldquo;{selectedVillage.sejarahSingkat}&rdquo;
                </p>
              </div>

              <div className="grid grid-cols-2 gap-3.5">
                <div className="border border-slate-100 p-2.5 rounded-lg">
                  <h6 className="font-bold text-[10px] uppercase text-slate-400 mb-1 flex items-center gap-1">
                    <MapPin className="w-3 h-3 text-amber-600" /> Luas Area
                  </h6>
                  <p className="font-mono text-sm font-bold text-slate-800">{selectedVillage.luasWilayahHektar} Hektar</p>
                </div>
                <div className="border border-slate-100 p-2.5 rounded-lg">
                  <h6 className="font-bold text-[10px] uppercase text-slate-400 mb-1 flex items-center gap-1">
                    <Compass className="w-3 h-3 text-amber-600" /> Kontak Kantor
                  </h6>
                  <p className="font-mono text-sm font-bold text-slate-800">{selectedVillage.kontakKantor}</p>
                </div>
              </div>

              <div>
                <h5 className="font-bold text-slate-700 mb-1">Visi Desa</h5>
                <p className="text-slate-600 text-xs bg-slate-50 p-2.5 rounded-lg font-medium border-l-2 border-yellow-500">
                  {selectedVillage.visi}
                </p>
              </div>

              <div>
                <h5 className="font-bold text-slate-700 mb-1.5">Misi Operasional Desa</h5>
                <ul className="list-disc list-inside space-y-1 text-slate-600 pl-1 text-[11px]">
                  {selectedVillage.misi.map((m, idx) => (
                    <li key={idx} className="leading-relaxed">{m}</li>
                  ))}
                </ul>
              </div>
            </div>

            {/* Operator to Admin Submission Workflow Block */}
            <div className="border-t border-slate-100 pt-4 space-y-3">
              <h5 className="font-bold text-slate-800 text-xs flex items-center gap-1.5">
                <Send className="w-3.5 h-3.5 text-amber-600" />
                Alur Verifikasi Data (Operator ➔ Admin)
              </h5>
              
              {selectedVillage.statusWeb === "Menunggu Verifikasi" ? (
                <div className="bg-blue-50 border border-blue-200 p-3 rounded-xl space-y-2 text-xs">
                  <div className="flex items-center gap-2 text-blue-900 font-bold">
                    <span className="w-2 h-2 bg-blue-500 rounded-full animate-ping shrink-0" />
                    Menunggu Verifikasi dari Camat / Admin
                  </div>
                  <p className="text-[11px] text-blue-700 leading-relaxed font-medium">
                    Operator desa ini telah melakukan penginputan data rill dan saat ini sedang menunggu verifikasi/approval dari Camat agar dipublikasikan ke Publik.
                  </p>
                  
                  {activeRole === "Camat/Admin Kecamatan" && (
                    <button
                      type="button"
                      onClick={() => onUpdateWebStatus(selectedVillage.id, "Aktif")}
                      className="w-full bg-[#0F172A] hover:bg-[#1E293B] text-white text-[11px] font-bold py-2 rounded-lg transition-all shadow-sm"
                    >
                      ✓ SETUJUI & AKTIFKAN DATA SEKARANG
                    </button>
                  )}
                </div>
              ) : (
                <div className="bg-slate-50 border border-slate-100 p-3 rounded-xl space-y-2 text-xs">
                  <div className="flex justify-between items-center text-slate-700 font-medium pb-1">
                    <span>Status Publikasi Desa:</span>
                    <span className={`font-mono font-bold uppercase px-2 py-0.5 rounded text-[10px] ${
                      selectedVillage.statusWeb === 'Aktif' ? 'bg-yellow-100 text-yellow-900 border border-yellow-300' : 'bg-slate-200/60 text-slate-900'
                    }`}>
                      {selectedVillage.statusWeb}
                    </span>
                  </div>
                  
                  {activeRole === "Operator Desa" && operatorVillageId === selectedVillage.id && (
                    <button
                      type="button"
                      onClick={() => onUpdateWebStatus(selectedVillage.id, "Menunggu Verifikasi")}
                      className="w-full bg-yellow-500 hover:bg-yellow-600 text-slate-950 text-[11px] font-black py-2 rounded-lg transition-all shadow-sm uppercase tracking-wider text-center"
                    >
                      Kirim Pemutakhiran Data ke Camat (Operator To Admin)
                    </button>
                  )}
                  {activeRole === "Operator Desa" && operatorVillageId !== selectedVillage.id && (
                    <p className="text-[9px] text-slate-400 italic">
                      Anda masuk sebagai operator desa lain. Hanya operator desa {selectedVillage.nama} yang bisa mengirim data verifikasi.
                    </p>
                  )}
                  {activeRole === "Camat/Admin Kecamatan" && (
                    <p className="text-[10px] text-slate-500 font-medium">
                      Status data saat ini stabil. Belum ada pengajuan pemutakhiran data gres dari Operator {selectedVillage.nama}.
                    </p>
                  )}
                </div>
              )}
            </div>

            {/* 2.4 Catatan Kecamatan Input Panel */}
            <div className="border-t border-slate-100 pt-4 space-y-3">
              <h5 className="font-bold text-slate-800 text-xs">
                Kirim Catatan Koreksi Camat / Kecamatan
              </h5>
              <p className="text-[10px] text-slate-500">
                Berikan instruksi koreksi data kepada operator desa jika monografi belum akurat.
              </p>

              {canModifyVillage(selectedVillage.id) ? (
                <div className="flex gap-2">
                  <input
                    type="text"
                    placeholder="Contoh: Lampirkan foto kades terbaru..."
                    value={newCatatan}
                    onChange={(e) => setNewCatatan(e.target.value)}
                    className="flex-1 text-xs border border-slate-200 rounded-lg px-3 py-2 focus:outline-none focus:border-yellow-500"
                  />
                  <button
                    onClick={() => handleSendCatatan(selectedVillage.id)}
                    className="bg-[#0F172A] hover:bg-[#1E293B] text-white rounded-lg p-2.5 transition-all text-xs font-bold shrink-0 flex items-center gap-1"
                  >
                    <Send className="w-3.5 h-3.5" />
                  </button>
                </div>
              ) : (
                <div className="bg-slate-100 text-slate-500 p-2.5 rounded-lg text-[10px] flex items-center gap-2">
                  <HelpCircle className="w-4 h-4 text-slate-400 shrink-0" />
                  <span>
                    Anda masuk sebagai <strong>{activeRole}</strong>. Pengiriman arahan koreksi hanya diizinkan untuk Admin Kecamatan atau operator desa terpilih.
                  </span>
                </div>
              )}

              {/* History of notes for this village */}
              <div className="space-y-2 mt-3 p-3 bg-slate-50 rounded-xl max-h-48 overflow-y-auto">
                <span className="text-[9px] font-bold uppercase text-slate-400 tracking-wider">Histori Memo</span>
                {catatanKecamatan.filter((c) => c.desaId === selectedVillage.id).length > 0 ? (
                  catatanKecamatan
                    .filter((c) => c.desaId === selectedVillage.id)
                    .map((item) => (
                      <div key={item.id} className="bg-white p-2.5 rounded-lg border border-slate-100 shadow-sm text-[11px] space-y-1">
                        <div className="flex justify-between items-center text-[9px] text-slate-400">
                          <span className="font-bold text-slate-500">{item.pengirim}</span>
                          <span className="font-mono">{item.tanggal}</span>
                        </div>
                        <p className="text-slate-700 font-serif leading-relaxed italic text-xs">&ldquo;{item.catatan}&rdquo;</p>
                      </div>
                    ))
                ) : (
                  <p className="text-[10px] text-slate-400 text-center py-2">Belum ada catatan koreksi untuk wilayah {selectedVillage.nama}.</p>
                )}
              </div>
            </div>
          </div>
        ) : (
          <div className="bg-white rounded-2xl border border-slate-200 p-8 text-center text-slate-400 flex flex-col items-center justify-center">
            <Globe className="w-12 h-12 text-slate-300 mb-2 animate-pulse" />
            <p className="text-xs">Pilih salah satu desa untuk melihat detail visi misi dan menu catatan.</p>
          </div>
        )}
      </div>
    </div>
  );
}
