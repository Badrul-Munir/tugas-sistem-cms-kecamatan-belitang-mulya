/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from "react";
import {
  GitFork,
  UserCheck,
  ShieldCheck,
  Phone,
  MapPin,
  Clock,
  Briefcase,
  Layers,
  ArrowRight
} from "lucide-react";
import { PerangkatDesa, Desa } from "../types";

interface PerangkatModuleProps {
  perangkat: PerangkatDesa[];
  villages: Desa[];
  selectedVillageId: string | null;
  onSelectVillage: (id: string | null) => void;
}

export default function PerangkatModule({
  perangkat,
  villages,
  selectedVillageId,
  onSelectVillage
}: PerangkatModuleProps) {
  const [activeVillageId, setActiveVillageId] = useState<string>(selectedVillageId || villages[0]?.id || "");
  const [selectedStaff, setSelectedStaff] = useState<PerangkatDesa | null>(null);

  // Sync with main app's selected village
  useEffect(() => {
    if (selectedVillageId) {
      setActiveVillageId(selectedVillageId);
    }
  }, [selectedVillageId]);

  const activeVillage = villages.find((v) => v.id === activeVillageId);
  const villageStaff = perangkat.filter((p) => p.desaId === activeVillageId);

  // Separate staff to construct the visual structure/hierarchy
  const kepalaDesa = villageStaff.find((s) => s.jabatan === "Kepala Desa");
  const sekdes = villageStaff.find((s) => s.jabatan === "Sekretaris Desa");
  const kasiList = villageStaff.filter((s) => s.jabatan.startsWith("Kasi"));
  const kaurList = villageStaff.filter((s) => s.jabatan.startsWith("Kaur"));
  const dusunList = villageStaff.filter((s) => s.jabatan === "Kepala Dusun" || s.jabatan === "Ketua RT" || s.jabatan === "Ketua RW");

  const getStatusColor = (status: PerangkatDesa["statusAktif"]) => {
    switch (status) {
      case "Aktif":
        return "bg-yellow-100 text-yellow-900 border-yellow-200";
      case "Pindah":
      case "Habis Masa Jabatan":
        return "bg-amber-100 text-amber-800 border-amber-300";
      default:
        return "bg-slate-100 text-slate-700 border-slate-300";
    }
  };

  return (
    <div className="space-y-6">
      {/* 5.1 & 5.3 Filter Village Picker */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <span className="text-xs font-bold uppercase tracking-wider text-slate-900 border-l-2 border-yellow-500 px-2.5 py-0.5">
            5.0 Administrasi Pemerintahan
          </span>
          <h3 className="text-lg font-bold text-slate-800 mt-1">
            Visual Struktur Organisasi & Aparatur Desa
          </h3>
          <p className="text-xs text-slate-500">
            Daftar lengkap perwakilan aparat pemerintahan desa dari Kades hingga RT/RW.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <label className="text-xs font-semibold text-slate-400 uppercase">Pilih Desa:</label>
          <select
            value={activeVillageId}
            onChange={(e) => {
              const val = e.target.value;
              setActiveVillageId(val);
              onSelectVillage(val);
              setSelectedStaff(null);
            }}
            className="text-xs font-bold text-slate-800 border border-slate-200 rounded-lg bg-slate-50 px-3 py-1.5 focus:outline-none focus:border-yellow-500 cursor-pointer"
          >
            {villages.map((v) => (
              <option key={v.id} value={v.id}>
                {v.nama}
              </option>
            ))}
          </select>
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-12 gap-6">
        {/* Visual Org Tree Map Left */}
        <div className="xl:col-span-8 bg-white rounded-2xl border border-slate-200 p-6 shadow-sm space-y-6">
          <div className="flex justify-between items-center">
            <h4 className="text-xs font-bold uppercase text-slate-400 tracking-wider flex items-center gap-1.5">
              <GitFork className="w-4 h-4 text-amber-600" />
              Hierarki Struktur Pemerintahan {activeVillage?.nama} (5.1)
            </h4>
            <span className="text-[10px] font-mono text-slate-400 font-bold">Bagan Atasan-Bawahan</span>
          </div>

          {/* Org Tree Visualization Canvas */}
          <div className="p-4 bg-slate-50 rounded-xl border border-slate-100 overflow-x-auto flex flex-col items-center select-none">
            <div className="min-w-[500px] space-y-6 text-center">
              {/* Level 1: Kepala Desa */}
              <div className="flex justify-center">
                {kepalaDesa ? (
                  <div
                    onClick={() => setSelectedStaff(kepalaDesa)}
                    className={`p-3 bg-slate-900 text-white rounded-xl shadow-md cursor-pointer transition-all hover:-translate-y-0.5 border-2 ${
                      selectedStaff?.id === kepalaDesa.id ? "border-yellow-500 ring-2 ring-yellow-500/20" : "border-transparent"
                    } w-48`}
                  >
                    <div className="text-[10px] uppercase font-bold text-yellow-400">Kepala Desa</div>
                    <div className="text-xs font-extrabold mt-1 line-clamp-1">{kepalaDesa.nama}</div>
                    <span className="text-[9px] bg-yellow-500/30 px-1.5 py-0.2 rounded mt-1.5 inline-block text-yellow-300 font-bold border border-yellow-500/20">
                      Masa Jab: {kepalaDesa.masaJabatan}
                    </span>
                  </div>
                ) : (
                  <div className="p-3 bg-rose-50 border border-rose-100 text-rose-800 rounded-xl text-xs w-48 italic">
                    Kades belum didata
                  </div>
                )}
              </div>

              {/* Lini Aliran Down */}
              <div className="w-0.5 h-6 bg-slate-300 mx-auto" />

              {/* Level 2: Sekretaris Desa */}
              <div className="flex justify-center">
                {sekdes ? (
                  <div
                    onClick={() => setSelectedStaff(sekdes)}
                    className={`p-3 bg-white border rounded-xl shadow-sm cursor-pointer transition-all hover:-translate-y-0.5 ${
                      selectedStaff?.id === sekdes.id ? "border-yellow-500 bg-yellow-50/10 ring-2 ring-yellow-105" : "border-slate-200"
                    } w-44`}
                  >
                    <div className="text-[9px] uppercase font-bold text-slate-400">Sekretaris Desa</div>
                    <div className="text-xs font-bold text-slate-800 mt-1 line-clamp-1">{sekdes.nama}</div>
                    <span className="text-[9px] text-slate-500 font-mono mt-0.5 block">{sekdes.kontak}</span>
                  </div>
                ) : (
                  <div className="p-2.5 bg-slate-100 border border-slate-200 text-slate-400 rounded-xl text-[10px] w-44 italic">
                    Sekdes kosong
                  </div>
                )}
              </div>

              {/* Lini Aliran Down splits to Kasi/Kaur */}
              <div className="w-0.5 h-4 bg-slate-300 mx-auto" />
              <div className="w-[300px] h-0.5 bg-slate-300 mx-auto" />
              <div className="flex justify-center gap-10">
                <div className="w-0.5 h-4 bg-slate-300" />
                <div className="w-0.5 h-4 bg-slate-300" />
              </div>

              {/* Level 3: Dual Columns of Kasi & Kaur */}
              <div className="grid grid-cols-2 gap-6 max-w-xl mx-auto text-left">
                {/* Kasi Column (Seksi Pelayanan dll) */}
                <div className="space-y-3">
                  <div className="text-[9px] font-bold text-slate-400 text-center uppercase tracking-wider mb-2">
                    Lini Kepala Seksi (KASI)
                  </div>
                  {kasiList.length > 0 ? (
                    kasiList.map((st) => (
                      <div
                        key={st.id}
                        onClick={() => setSelectedStaff(st)}
                        className={`p-2.5 bg-white border rounded-lg shadow-sm cursor-pointer transition-colors ${
                          selectedStaff?.id === st.id ? "border-yellow-500 bg-yellow-50/10" : "border-slate-200 hover:border-slate-300"
                        }`}
                      >
                        <div className="text-[8px] font-bold text-amber-700 uppercase">{st.jabatan}</div>
                        <div className="text-[11px] font-bold text-slate-800 mt-0.5 truncate">{st.nama}</div>
                      </div>
                    ))
                  ) : (
                    <p className="text-[10px] text-slate-400 italic text-center py-2 bg-slate-100 rounded">Absen Kasi</p>
                  )}
                </div>

                {/* Kaur Column (Seksi Administrasi dll) */}
                <div className="space-y-3">
                  <div className="text-[9px] font-bold text-slate-400 text-center uppercase tracking-wider mb-2">
                    Lini Kepala Urusan (KAUR)
                  </div>
                  {kaurList.length > 0 ? (
                    kaurList.map((st) => (
                      <div
                        key={st.id}
                        onClick={() => setSelectedStaff(st)}
                        className={`p-2.5 bg-white border rounded-lg shadow-sm cursor-pointer transition-colors ${
                          selectedStaff?.id === st.id ? "border-yellow-500 bg-yellow-50/10" : "border-slate-200 hover:border-slate-300"
                        }`}
                      >
                        <div className="text-[8px] font-bold text-indigo-700 uppercase">{st.jobDesk.startsWith("Membantu") ? "KAUR KEUANGAN" : st.jabatan}</div>
                        <div className="text-[11px] font-bold text-slate-800 mt-0.5 truncate">{st.nama}</div>
                      </div>
                    ))
                  ) : (
                    <p className="text-[10px] text-slate-400 italic text-center py-2 bg-slate-100 rounded">Absen Kaur</p>
                  )}
                </div>
              </div>

              {/* Level 4: RT/RW/Dusun */}
              {dusunList.length > 0 && (
                <div className="pt-4 border-t border-slate-200 mt-5">
                  <div className="text-[9px] font-bold text-slate-400 uppercase tracking-widest mb-3">Lembaga Daerah (Kadusun / RT / RW)</div>
                  <div className="flex flex-wrap justify-center gap-3">
                    {dusunList.map((st) => (
                      <div
                        key={st.id}
                        onClick={() => setSelectedStaff(st)}
                        className={`px-3 py-1.5 bg-slate-100 hover:bg-slate-200 rounded-full text-[10px] font-medium text-slate-700 cursor-pointer border transition-all ${
                          selectedStaff?.id === st.id ? "border-yellow-500 bg-yellow-50/10" : "border-slate-200"
                        }`}
                      >
                        {st.jabatan}: <strong className="text-slate-800">{st.nama}</strong>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Selected Staff Profile Card Right */}
        <div id="staff-profile-inspector" className="xl:col-span-4">
          {selectedStaff ? (
            <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm space-y-5">
              {/* Profile Card Header */}
              <div className="text-center space-y-2 border-b border-slate-100 pb-4">
                <img
                  referrerPolicy="no-referrer"
                  src={selectedStaff.foto}
                  alt={selectedStaff.nama}
                  className="w-16 h-16 rounded-full object-cover mx-auto border-2 border-yellow-500 shadow"
                />
                <div>
                  <h4 className="text-sm font-black text-slate-800">{selectedStaff.nama}</h4>
                  <p className="text-[10px] font-bold text-slate-900 border border-yellow-250 bg-yellow-50 px-2.5 py-0.5 rounded-full inline-block mt-1">
                    {selectedStaff.jabatan}
                  </p>
                </div>
                <div className="flex justify-center flex-wrap">
                  <span className={`text-[9px] font-bold border px-2 py-0.5 rounded-full uppercase ${getStatusColor(selectedStaff.statusAktif)}`}>
                    ● {selectedStaff.statusAktif} (5.4)
                  </span>
                </div>
              </div>

              {/* Rincian Profil 5.2 */}
              <div className="space-y-3.5 text-xs text-slate-700">
                <div className="flex items-center gap-2">
                  <Briefcase className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                  <span>Masa Jabatan: <strong className="text-slate-800">{selectedStaff.masaJabatan}</strong></span>
                </div>
                <div className="flex items-center gap-2">
                  <Phone className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                  <span>Call: <strong className="text-slate-800">{selectedStaff.kontak}</strong></span>
                </div>
                <div className="flex items-start gap-2">
                  <MapPin className="w-3.5 h-3.5 text-amber-600 shrink-0 mt-0.5" />
                  <span>Domisili: <span className="text-slate-600 font-medium">{selectedStaff.alamat}</span></span>
                </div>

                <div className="bg-slate-50 p-3 rounded-lg border border-slate-200/60 mt-2 space-y-1">
                  <div className="text-[9px] text-slate-400 font-bold uppercase flex items-center gap-1">
                    <ShieldCheck className="w-3 h-3 text-slate-500" /> Tugas Pokok & Fungsi (Job Desk 5.3)
                  </div>
                  <p className="text-[11px] text-slate-600 leading-relaxed font-sans">{selectedStaff.jobDesk}</p>
                </div>

                {/* History 5.5 */}
                <div className="space-y-1.5 pt-2">
                  <div className="text-[9px] text-slate-400 font-bold uppercase flex items-center gap-1">
                    <Clock className="w-3 h-3 text-slate-500" /> Riwayat Jabatan (5.5)
                  </div>
                  <ul className="text-[10px] text-slate-500 space-y-1 list-none pl-1">
                    {selectedStaff.riwayatJabatan.map((r, rIdx) => (
                      <li key={rIdx} className="flex gap-1.5 items-start">
                        <span className="text-yellow-500 font-bold">✓</span>
                        <span className="leading-tight">{r}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          ) : (
            <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm text-center py-16 flex flex-col items-center justify-center">
              <Layers className="w-10 h-10 text-slate-300 mb-2.5" />
              <h5 className="text-xs font-bold text-slate-700">Inspeksi detail aparatur</h5>
              <p className="text-[11px] text-slate-400 max-w-[200px] leading-relaxed mt-1">
                Klik salah satu kotak kotak jabatan di pohon struktur bagan sebelah kiri untuk melihat job-deskripsi dan rekap data kades kami.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
