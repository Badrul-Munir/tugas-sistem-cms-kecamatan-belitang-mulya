/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, useRef } from "react";
import { MapPin, Info, Compass, ShieldAlert, Layers } from "lucide-react";
import { Desa } from "../types";

interface VillageMapProps {
  villages: Desa[];
  selectedVillageId: string | null;
  onSelectVillage: (id: string | null) => void;
}

export default function VillageMap({
  villages,
  selectedVillageId,
  onSelectVillage,
}: VillageMapProps) {
  const [leafletLoaded, setLeafletLoaded] = useState(!!(window as any).L);
  const [mapType, setMapType] = useState<"hybrid" | "satellite" | "street">("hybrid");

  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<any>(null);
  const markersRef = useRef<{ [key: string]: any }>({});

  // Mean coordinate of Belitang Mulya for map default view center: -3.348, 104.624 (OKU Timur, Sumatera Selatan)
  const defaultCenter: [number, number] = [-3.348, 104.624];
  const defaultZoom = 13;

  // Poll for Leaflet CDN script loaded check
  useEffect(() => {
    if ((window as any).L) {
      setLeafletLoaded(true);
      return;
    }

    const interval = setInterval(() => {
      if ((window as any).L) {
        setLeafletLoaded(true);
        clearInterval(interval);
      }
    }, 100);

    return () => clearInterval(interval);
  }, []);

  // Initialize and clean up main Leaflet map instance
  useEffect(() => {
    const L = (window as any).L;
    if (!leafletLoaded || !L || !mapContainerRef.current) return;

    if (!mapInstanceRef.current) {
      // Create Map with explicit interaction options verified for panning
      const map = L.map(mapContainerRef.current, {
        center: defaultCenter,
        zoom: defaultZoom,
        zoomControl: false,
        attributionControl: true,
        dragging: true,
        touchZoom: true,
        doubleClickZoom: true,
        scrollWheelZoom: true,
        boxZoom: true,
        keyboard: true,
      });

      // Add a clean zoom control in bottom left
      L.control.zoom({ position: "bottomleft" }).addTo(map);

      mapInstanceRef.current = map;

      // Invalidate size once container settles
      setTimeout(() => {
        map.invalidateSize();
      }, 150);
    }

    return () => {
      // Clean up map instance on complete unmount to avoid re-initialization error
    };
  }, [leafletLoaded]);

  // Clean-up on complete unmount
  useEffect(() => {
    return () => {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove();
        mapInstanceRef.current = null;
      }
    };
  }, []);

  // Update Tile Layers when mapType or map instance is ready
  useEffect(() => {
    if (!mapInstanceRef.current) return;
    const map = mapInstanceRef.current;
    const L = (window as any).L;
    if (!L) return;

    // Remove existing tile layers to reload
    map.eachLayer((layer: any) => {
      if (layer instanceof L.TileLayer) {
        map.removeLayer(layer);
      }
    });

    if (mapType === "street") {
      // Standard OSM Streets View
      L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank">OpenStreetMap</a> contributors',
        maxZoom: 19,
      }).addTo(map);
    } else {
      // Esri High-Res Satellite Base Layer
      L.tileLayer(
        "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}",
        {
          attribution: "Tiles &copy; Esri, USDA, USGS, AeroGRID, and the GIS User Community",
          maxZoom: 19,
        }
      ).addTo(map);

      // Add Hybrid labels if mapType is hybrid
      if (mapType === "hybrid") {
        L.tileLayer(
          "https://server.arcgisonline.com/ArcGIS/rest/services/Reference/World_Boundaries_and_Places/MapServer/tile/{z}/{y}/{x}",
          {
            attribution: "Labels &copy; Esri",
            maxZoom: 19,
          }
        ).addTo(map);
      }
    }
  }, [leafletLoaded, mapType]);

  // Re-render and bind village markers based on active status & selection
  useEffect(() => {
    if (!mapInstanceRef.current) return;
    const map = mapInstanceRef.current;
    const L = (window as any).L;
    if (!L) return;

    // Clear existing markers from map
    Object.values(markersRef.current).forEach((m) => {
      map.removeLayer(m);
    });
    markersRef.current = {};

    // Helper to generate a styled HTML DivIcon for markers
    const getCustomIcon = (nama: string, isSelected: boolean) => {
      return L.divIcon({
        className: "custom-leaflet-icon",
        html: `
          <div class="relative flex flex-col items-center select-none" style="transform: translate(-50%, -50%); outline: none;">
            ${isSelected ? `
              <span class="absolute h-9 w-9 rounded-full bg-yellow-400 opacity-25 animate-ping -top-1.5"></span>
              <span class="absolute h-7 w-7 rounded-full bg-yellow-400 opacity-45 animate-pulse -top-0.5"></span>
            ` : ""}
            <div class="flex items-center justify-center rounded-full ${
              isSelected 
                ? "h-6.5 w-6.5 bg-yellow-405 text-slate-900 border-2 border-white bg-yellow-500 scale-110" 
                : "h-5 w-5 bg-amber-500 text-white border border-amber-250 hover:bg-yellow-500"
            } shadow-md transition-all duration-300">
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" class="${isSelected ? "w-3.5 h-3.5" : "w-2.5 h-2.5"}">
                <path fill-rule="evenodd" d="M9.69 18.933l.003.001C9.89 19.02 10 19 10 19s.11.02.308-.066l.002-.001.006-.003.018-.009a12.442 12.442 0 001.081-.577c.872-.514 2.158-1.41 3.01-2.61.85-.1.196-2.585 2.196-4.512C16.618 7.04 13.65 4 10 4S3.381 7.04 3.381 11.23c0 1.927.753 3.415 1.6 4.513.852 1.2 2.138 2.096 3.01 2.61a12.44 12.44 0 001.081.577l.018.009.006.003zM10 13a3 3 0 100-6 3 3 0 000 6z" clip-rule="evenodd" />
              </svg>
            </div>
            <div class="pointer-events-none mt-1.5 whitespace-nowrap rounded px-2 py-0.5 text-[9px] font-bold leading-none select-none ${
              isSelected 
                ? "text-yellow-400 bg-slate-950 border border-yellow-500/40" 
                : "text-white bg-slate-900/90 border border-slate-700/60"
            } shadow-md backdrop-blur-sm">
              ${nama}
            </div>
          </div>
        `,
        iconSize: [0, 0],
        iconAnchor: [0, 0]
      });
    };

    // Render each village as lat/lng marker
    villages.forEach((v) => {
      const isSelected = selectedVillageId === v.id;
      const marker = L.marker([v.koordinatLat, v.koordinatLng], {
        icon: getCustomIcon(v.nama, isSelected),
        zIndexOffset: isSelected ? 1000 : 0
      });

      // Handle selection click
      marker.on("click", (e: any) => {
        L.DomEvent.stopPropagation(e);
        onSelectVillage(isSelected ? null : v.id);
      });

      marker.addTo(map);
      markersRef.current[v.id] = marker;
    });
  }, [leafletLoaded, villages, selectedVillageId]);

  // Handle zooming/centering panning based on selected village state
  useEffect(() => {
    if (!mapInstanceRef.current) return;
    const map = mapInstanceRef.current;

    if (selectedVillageId) {
      const selectedV = villages.find((v) => v.id === selectedVillageId);
      if (selectedV) {
        map.setView([selectedV.koordinatLat, selectedV.koordinatLng], 14, {
          animate: true,
          duration: 0.85,
        });
      }
    } else {
      map.setView(defaultCenter, defaultZoom, {
        animate: true,
        duration: 0.85,
      });
    }
  }, [selectedVillageId, villages]);

  // Handle automatic map size recalculation on window resize
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map) return;

    const handleResize = () => {
      map.invalidateSize();
    };

    window.addEventListener("resize", handleResize);
    return () => {
      window.removeEventListener("resize", handleResize);
    };
  }, [leafletLoaded]);

  const selectedVillage = villages.find((v) => v.id === selectedVillageId);

  return (
    <div id="village-map-container" className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm overflow-hidden transition-all duration-300 hover:shadow-md">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-5 gap-3">
        <div>
          <span className="text-xs font-bold uppercase tracking-wider text-slate-900 border-l-2 border-yellow-500 px-2.5 py-0.5">
            1.2 Monitoring Geografis
          </span>
          <h3 className="text-lg font-bold text-slate-800 mt-1.5 flex items-center gap-2">
            Peta Lokasi Desa & Koordinat Wilayah
          </h3>
          <p className="text-xs text-slate-500">
            Klik simpul desa untuk memfilter seluruh data operasional dashboard secara real-time
          </p>
        </div>
        <div className="flex items-center gap-1.5 text-xs text-slate-500">
          <Compass className="w-4 h-4 text-amber-500 animate-[spin_12s_linear_infinite]" />
          <span>Sektor Gambut & Darat</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Interactive Canvas - Satellite Map Container */}
        <div id="leaflet-map-canvas" className="lg:col-span-7 relative bg-slate-950 rounded-xl overflow-hidden shadow-inner border border-slate-800 aspect-[3/2] flex flex-col">
          {!leafletLoaded ? (
            <div className="w-full h-full flex flex-col items-center justify-center text-slate-400 font-sans gap-2 p-6 text-center">
              <div className="w-8 h-8 border-2 border-yellow-500/30 border-t-yellow-500 rounded-full animate-spin" />
              <span className="text-xs">Memuat Peta Satelit OKU Timur...</span>
            </div>
          ) : (
            <div 
              ref={mapContainerRef} 
              className="w-full h-full relative z-0 flex-1 outline-none cursor-grab active:cursor-grabbing"
              style={{ minHeight: "280px" }}
            />
          )}

          {/* Map Layer Selector UI */}
          <div className="absolute top-3 right-3 z-[1000] flex gap-1 bg-slate-950/95 p-1 rounded-lg border border-slate-700/80 shadow-lg text-[9px] sm:text-[10px] font-sans h-8 items-center backdrop-blur-sm">
            <button
              onClick={() => setMapType("hybrid")}
              className={`px-2 py-1 rounded transition-all cursor-pointer font-semibold ${
                mapType === "hybrid" 
                  ? "bg-yellow-500 text-slate-950 font-bold shadow-sm" 
                  : "text-slate-400 hover:text-white"
              }`}
            >
              Hibrida
            </button>
            <button
              onClick={() => setMapType("satellite")}
              className={`px-2 py-1 rounded transition-all cursor-pointer font-semibold ${
                mapType === "satellite" 
                  ? "bg-yellow-500 text-slate-950 font-bold shadow-sm" 
                  : "text-slate-400 hover:text-white"
              }`}
            >
              Satelit
            </button>
            <button
              onClick={() => setMapType("street")}
              className={`px-2 py-1 rounded transition-all cursor-pointer font-semibold ${
                mapType === "street" 
                  ? "bg-yellow-500 text-slate-950 font-bold shadow-sm" 
                  : "text-slate-400 hover:text-white"
              }`}
            >
              Peta Jalan
            </button>
          </div>

          {/* Map Compass Rose / Indicator */}
          <div className="absolute bottom-3 right-3 z-[1000] text-[9px] text-slate-300 font-mono bg-slate-950/90 border border-slate-800 px-2.5 py-1 rounded shadow-md flex items-center gap-1.5 backdrop-blur-sm pointer-events-none">
            <Layers className="w-3.5 h-3.5 text-yellow-400" />
            <span className="uppercase text-[8px] font-bold tracking-wide">PETA AKTIF</span>
          </div>
        </div>

        {/* Selected Village Info Panel */}
        <div id="selected-village-map-info" className="lg:col-span-5 flex flex-col justify-between bg-slate-50 rounded-xl p-4 border border-slate-200">
          {selectedVillage ? (
            <div className="space-y-4">
              <div className="flex justify-between items-start">
                <div>
                  <h4 className="text-sm font-bold text-slate-800">{selectedVillage.nama}</h4>
                  <p className="text-[10px] font-mono text-slate-500 mt-1 uppercase">
                    Kode Kel/Desa: {selectedVillage.kodeDesa}
                  </p>
                </div>
                <span className={`text-[10px] uppercase font-bold px-2 py-0.5 rounded ${
                  selectedVillage.statusWeb === "Aktif" 
                    ? "bg-yellow-50 text-yellow-900 border border-yellow-200"
                    : selectedVillage.statusWeb === "Draft"
                    ? "bg-amber-100 text-amber-900 border border-amber-200"
                    : "bg-rose-100 text-rose-800 border border-rose-200"
                }`}>
                  {selectedVillage.statusWeb}
                </span>
              </div>

              <div className="space-y-2.5">
                <div className="flex items-center gap-2 text-xs">
                  <MapPin className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                  <span className="text-slate-600 line-clamp-1">{selectedVillage.alamatKantor}</span>
                </div>
                <div className="bg-white p-2.5 rounded-lg border border-slate-200 space-y-1">
                  <div className="text-[10px] text-slate-400 uppercase font-semibold">Struktur Batas Geografis</div>
                  <p className="text-xs text-slate-600 font-mono">Utara: {selectedVillage.batasUtara}</p>
                  <p className="text-xs text-slate-600 font-mono">Selatan: {selectedVillage.batasSelatan}</p>
                </div>
                <div className="grid grid-cols-2 gap-2 text-center text-slate-700">
                  <div className="bg-white p-2 rounded-lg border border-slate-200">
                    <div className="text-[9px] text-slate-400 uppercase">Luas Wilayah</div>
                    <div className="text-xs font-bold font-mono text-slate-800">{selectedVillage.luasWilayahHektar} Ha</div>
                  </div>
                  <div className="bg-white p-2 rounded-lg border border-slate-200">
                    <div className="text-[9px] text-slate-400 uppercase">Garis Lintang</div>
                    <div className="text-xs font-bold font-mono text-slate-800">{selectedVillage.koordinatLat.toFixed(4)}</div>
                  </div>
                </div>
              </div>

              <button
                onClick={() => onSelectVillage(null)}
                className="w-full text-center py-2 px-3 text-xs bg-slate-200 hover:bg-slate-300 text-slate-700 font-medium rounded-lg transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
              >
                Reset Filter Wilayah
              </button>
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center text-center py-8 px-4 h-full">
              <div className="w-10 h-10 bg-yellow-50 rounded-full flex items-center justify-center text-amber-600 mb-2.5">
                <Info className="w-5 h-5 focus-ring" />
              </div>
              <h4 className="text-xs font-bold text-slate-700 mb-1">Mencakup Seluruh Kecamatan</h4>
              <p className="text-[11px] text-slate-500 max-w-[200px] leading-relaxed">
                Pilih pin koordinat desa di peta satelit sebelah kiri untuk memfilter detail administratif setiap desa secara fokus.
              </p>
            </div>
          )}

          {/* Sumatra Selatan Regional Note */}
          <div className="mt-4 pt-3 border-t border-slate-200/60 flex items-start gap-2 text-[10px] text-slate-500">
            <ShieldAlert className="w-3.5 h-3.5 text-amber-600 shrink-0 mt-0.5" />
            <p className="leading-tight animate-pulse" style={{ animationDuration: "3s" }}>
              <strong>Kecamatan Belitang Mulya</strong>, OKU Timur terkenal dengan keaslian bidang pertanian mandiri, hortikultura buah-buahan, dan komoditas sawit Sumsel.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
